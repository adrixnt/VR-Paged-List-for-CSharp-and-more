
	install using "setup.exe"

	un-install using Control-Panel :: Add/Remove Applications







	have fun				Adrix.NT
