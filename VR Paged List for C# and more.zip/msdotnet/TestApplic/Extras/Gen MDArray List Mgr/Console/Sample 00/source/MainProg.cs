
using System;

using System.Collections.Generic;

using VRAdrixNT.GenMDArrayListMgr;

using VRAdrixNT.Utils.StrFmt.IndexesArray;


namespace VRMDArrayLMgrSampleApplic00 {

	class MainProg {

		public class TestProc<T> {

			public static void PrintOnConsole (VRMDArrayListMgr<T> aMDArrayLMgr)
			{
				int aCount = aMDArrayLMgr.Size;
				int aIndex = 0;
				while (aIndex < aCount) {
					T aValue = aMDArrayLMgr[aIndex];
					Console.WriteLine (
						"[" + aIndex + "]: " +
						VRIndexesArrayStrFmtUtils.FormatIndexesArray (
							aMDArrayLMgr.IndexesFromLinearIndex (aIndex),
							"{", "}", "[", "]", ","
						) + ": " +
						aValue
					);
					++ aIndex;
				}
			}

		}

		public static void Main (string[] args)
		{
			Console.WriteLine ("[Multi Dim Array List Manager Test]");

			List<string> aList = new List<string>();

			VRMDArrayListMgr<string> aMDArrayLMgr = new VRMDArrayListMgr<string>();

			aMDArrayLMgr.List = aList;

			aMDArrayLMgr.DefaultValue = "xxx";

			aMDArrayLMgr.SetDimensionsSizes ( new int[] { 3, 3, 3 } );

			Console.WriteLine("setting an item ...");
			aMDArrayLMgr.SetItem (new int[] { 1, 1, 1 }, "ornella.xxx");

			Console.WriteLine ("size: " + aMDArrayLMgr.Size);
			TestProc<string>.PrintOnConsole (aMDArrayLMgr);
			Console.WriteLine();

			Console.WriteLine ("inserting ...");
			aMDArrayLMgr.DefaultValue = "adrix.nt";
			aMDArrayLMgr.Insert (2, aMDArrayLMgr.GetDimSize (2));

			Console.WriteLine ("size: " + aMDArrayLMgr.Size);
			TestProc<string>.PrintOnConsole (aMDArrayLMgr);
			Console.WriteLine();

			Console.WriteLine("deleting ...");
			aMDArrayLMgr.Delete (2, aMDArrayLMgr.GetDimSize(2) - 1);

			Console.WriteLine ("size: " + aMDArrayLMgr.Size);
			TestProc<string>.PrintOnConsole (aMDArrayLMgr);
			Console.WriteLine();

			Console.WriteLine ("ok");
		}

	}

}