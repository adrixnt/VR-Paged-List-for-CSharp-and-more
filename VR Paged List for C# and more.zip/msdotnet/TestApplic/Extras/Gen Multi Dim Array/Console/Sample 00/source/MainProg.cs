
using System;

using System.IO;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using VRAdrixNT.GenericMultiDimArray;

using VRAdrixNT.Utils.StrFmt.IndexesArray;

namespace VRMDArraySampleApplic00 {

	class MainProg {

		public class TestProc<T> {

			public static void PrintOnConsole (VRMultiDimArray<T> aMDArray)
			{
				int aCount = aMDArray.Size;
				int aIndex = 0;
				while (aIndex < aCount) {
					T aValue = aMDArray[aIndex];
					Console.WriteLine (
						"[" + aIndex + "]: " +
						VRIndexesArrayStrFmtUtils.FormatIndexesArray (
							aMDArray.IndexesFromLinearIndex (aIndex),
							"{", "}", "[", "]", ","
						) + ": " +
						aValue
					);
					++ aIndex;
				}
			}

		}

		public static void PrintOnConsole (VRMultiDimArray<string> aMDArray)
		{
			int aCount = aMDArray.Size;
			int aIndex = 0;
			while (aIndex < aCount) {
				string aValue = aMDArray[aIndex];
				Console.WriteLine ("[" + aIndex + "]: " + aValue);
				++ aIndex;
			}
		}

		public static void MainTest00()
		{
			Console.WriteLine ("[Multi Dim Array Test 00]");

			VRMultiDimArray<string> aMDArray = new VRMultiDimArray<string>();

			aMDArray.DefaultValue = "darkside";

			aMDArray.SetDimensionsSizes(new int[] { 0, 0, 0 });
			aMDArray.AddAtEnd(0, 2);
			aMDArray.AddAtEnd(1, 2);
			aMDArray.AddAtEnd(2, 3);

			aMDArray[0] = "adrix.nt";

			PrintOnConsole (aMDArray);

			TestProc<string>.PrintOnConsole (aMDArray);

			{
				Console.WriteLine ("indexes -> index test ...");
				int aIndex = aMDArray.LinearIndexFromIndexes (new int[] { 1, 1, 2 });
				Console.WriteLine ("index: " + aIndex);
			}

			{
				Console.WriteLine ("serialization test ...");
				IFormatter aFormatter = new BinaryFormatter();
				FileStream aFileStm = new FileStream ("MDArray.dat", FileMode.Create);
				try {
					aFormatter.Serialize(aFileStm, aMDArray);
					Console.WriteLine ("done!");
				} finally {
					aFileStm.Close();
				}
			}

			{
				Console.WriteLine ("deserialization test ...");
				IFormatter aFormatter = new BinaryFormatter();
				FileStream aFileStm = new FileStream ("MDArray.dat", FileMode.Open);
				try {
					VRMultiDimArray<string> aMDArrayCopy =
						(VRMultiDimArray<string>) aFormatter.Deserialize(aFileStm);
					TestProc<string>.PrintOnConsole(aMDArrayCopy);
					Console.WriteLine ("done!");
				} finally {
					aFileStm.Close();
				}
			}

			Console.WriteLine("done");
		}

		public static void MainTest01()
		{
			Console.WriteLine ("[Multi Dim Array Test 01]");

			VRMultiDimArray<int> aMDArray = new VRMultiDimArray<int>();

			aMDArray.DefaultValue = 123;

			aMDArray.SetDimensionsSizes(new int[] { 2, 3, 3 });

			TestProc<int>.PrintOnConsole (aMDArray);

			Console.WriteLine("done");
		}

		public static void Main (string[] args)
		{
			Console.WriteLine ("[Multi Dim Array Test]");

			MainTest00();

			MainTest01();

			Console.Write ("press enter to close ... ");
			Console.ReadLine();
		}

	}

}