
using System;

using System.IO;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using VRAdrixNT.GenericMultiDimArray;

using VRAdrixNT.Utils.StrFmt.IndexesArray;

namespace VRMDArraySampleApplic00 {

	class MainProg {

		public class TestProc<T> {

			public static void PrintOnConsole (VRMultiDimArray<T> aMDArray)
			{
				int aCount = aMDArray.Size;
				int aIndex = 0;
				while (aIndex < aCount) {
					T aValue = aMDArray[aIndex];
					Console.WriteLine (
						"[" + aIndex + "]: " +
						VRIndexesArrayStrFmtUtils.FormatIndexesArray (
							aMDArray.IndexesFromLinearIndex (aIndex),
							"{", "}", "[", "]", ","
						) + ": " +
						aValue
					);
					++ aIndex;
				}
			}

			// print a SubView

			public static void PrintOnConsole (VRMultiDimArray<T>.SubView aSubMDArray)
			{
				int aCount = aSubMDArray.Size;
				int aIndex = 0;
				while (aIndex < aCount) {
					T aValue = aSubMDArray [aIndex];
					Console.WriteLine (
						"[" + aIndex + "]: " +
						VRIndexesArrayStrFmtUtils.FormatIndexesArray (
							aSubMDArray.IndexesFromLinearIndex (aIndex),
							"{", "}", "[", "]", ","
						) + ": " +
						aValue
					);
					++ aIndex;
				}

			}

		}

		public static void PrintOnConsole (VRMultiDimArray<string> aMDArray)
		{
			int aCount = aMDArray.Size;
			int aIndex = 0;
			while (aIndex < aCount) {
				string aValue = aMDArray[aIndex];
				Console.WriteLine ("[" + aIndex + "]: " + aValue);
				++ aIndex;
			}
		}

		public static void MainTest00()
		{
			Console.WriteLine ("[Multi Dim Array Test 00]");

			VRMultiDimArray<string> aMDArray = new VRMultiDimArray<string>();

			aMDArray.DefaultValue = "darkside";

			aMDArray.SetDimensionsSizes(new int[] { 0, 0, 0 });
			aMDArray.AddAtEnd(0, 2);
			aMDArray.AddAtEnd(1, 2);
			aMDArray.AddAtEnd(2, 3);

			aMDArray[0] = "adrix.nt";

			PrintOnConsole (aMDArray);

			TestProc<string>.PrintOnConsole (aMDArray);

			{
				Console.WriteLine ("indexes -> index test ...");
				int aIndex = aMDArray.LinearIndexFromIndexes (new int[] { 1, 1, 2 });
				Console.WriteLine ("index: " + aIndex);
			}

			{
				Console.WriteLine ("serialization test ...");
				IFormatter aFormatter = new BinaryFormatter();
				FileStream aFileStm = new FileStream ("MDArray.dat", FileMode.Create);
				try {
					aFormatter.Serialize(aFileStm, aMDArray);
					Console.WriteLine ("done!");
				} finally {
					aFileStm.Close();
				}
			}

			{
				Console.WriteLine ("deserialization test ...");
				IFormatter aFormatter = new BinaryFormatter();
				FileStream aFileStm = new FileStream ("MDArray.dat", FileMode.Open);
				try {
					VRMultiDimArray<string> aMDArrayCopy =
						(VRMultiDimArray<string>) aFormatter.Deserialize(aFileStm);
					TestProc<string>.PrintOnConsole(aMDArrayCopy);
					Console.WriteLine ("done!");
				} finally {
					aFileStm.Close();
				}
			}

			Console.WriteLine("done");
		}

		public static void MainTest01()
		{
			Console.WriteLine ("[Multi Dim Array Test 01]");

			VRMultiDimArray<int> aMDArray = new VRMultiDimArray<int>();

			aMDArray.DefaultValue = 123;

			aMDArray.SetDimensionsSizes(new int[] { 2, 3, 3 });

			TestProc<int>.PrintOnConsole (aMDArray);

			Console.WriteLine("done");
		}

		public static void MainTest02()
		{
			Console.WriteLine("[Multi Dim Array Test 02]");

			Console.WriteLine ("[Multi Dim Array Sub View Test]");

			VRMultiDimArray<string> aMDArray = new VRMultiDimArray<string>();

			aMDArray.DefaultValue = "darkside";

			aMDArray.SetDimensionsSizes ( new int[] { 0, 0, 0 } );
			aMDArray.AddAtEnd(0, 2);
			aMDArray.AddAtEnd(1, 2);
			aMDArray.AddAtEnd(2, 3);

			aMDArray[2] = "adrix.nt";
			aMDArray[3] = "dario";

			Console.WriteLine ("the MDArray ...");
			TestProc<string>.PrintOnConsole (aMDArray);
			Console.WriteLine ("");

			// create sub view
			VRMultiDimArray<string>.SubView aSubMDArray = new VRMultiDimArray<string>.SubView();
			aSubMDArray.MDArray = aMDArray;
			aSubMDArray.MasterIndexes = new int[] { 1 };

			Console.WriteLine ("the MDArray Sub View ...");
			TestProc<string>.PrintOnConsole (aSubMDArray);
			Console.WriteLine ("");

			Console.WriteLine ("done");
		}

		public static void MainTest03()
		{
			Console.WriteLine("[Multi Dim Array Test 03]");

			VRMultiDimArray<string> aMDArray = new VRMultiDimArray<string>();
			aMDArray.DefaultValue = "darkside test";
			aMDArray.Dimensions = (2);

			// aMDArray.AddAtEnd (0, 3);
			// aMDArray.AddAtEnd (1, 3);
			aMDArray.Insert (0, 0);
			aMDArray.Insert (1, 0);
			aMDArray.Insert (0, 1);
			aMDArray.Insert (1, 1);
			aMDArray.Insert (0, 2);
			aMDArray.Insert (1, 2);

			aMDArray.SetItem (new int[] { 0, 1 } , "adrix");
			aMDArray.SetItem (new int[] { 1, 0 } , "dario");
			aMDArray[8] = "porco";

			Console.WriteLine("the MDArray ...");
			TestProc<string>.PrintOnConsole(aMDArray);
			Console.WriteLine("");
		}


		public static void Main (string[] args)
		{
			Console.WriteLine ("[Multi Dim Array Test]");

			MainTest00();

			MainTest01();

			MainTest02();

			MainTest03();

			Console.Write ("press enter to close ... ");
			Console.ReadLine();
		}

	}

}