using System;

using System.IO;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using VRAdrixNT.GenAdjMatrixGraph;

namespace VRAxGenALGraphSampleConApplic00 {


	class MainProg {

		// binary serialization

		// write

		public static void BinaryWriteOnFile (VRGraph<string, int> aGraph)
		{
			Console.WriteLine("[binary serialization]");
			Console.WriteLine("writing ...");
			IFormatter aFormatter = new BinaryFormatter();
			FileStream aFileStm = new FileStream("Graph.bin", FileMode.Create);
			try
			{
				aFormatter.Serialize(aFileStm, aGraph);
				Console.WriteLine("done!");
			}
			finally
			{
				aFileStm.Close();
			}
		}

		// read

		public static VRGraph<string, int> BinaryReadFromFile()
		{
			VRGraph<string, int> aGraph = null;
			Console.WriteLine("[binary serialization]");
			Console.WriteLine("reading ...");
			IFormatter aFormatter = new BinaryFormatter();
			FileStream aFileStm = new FileStream("Graph.bin", FileMode.Open);
			try
			{
				aGraph = (VRGraph<string, int>)
					aFormatter.Deserialize(aFileStm);
				Console.WriteLine("done!");
			}
			finally
			{
				aFileStm.Close();
			}
			return aGraph;
		}


		// print details on std out

		public static void PrintNodeDetailsOnStdOut (
			VRGraph<string, int> aGraph,
			int aSrcIndex
		) {
			int aCount = aGraph.Size;
			int aIndex = 0;
			while (aIndex < aCount) {
				int aDstIndex = aIndex;
				if (aGraph.Linked(aSrcIndex, aDstIndex)) {
					Console.WriteLine("\t" + "- [" + aDstIndex + "] " +
						aGraph[aDstIndex] + " : " +
						"(" + aGraph.GetLinkValue(aSrcIndex, aDstIndex) + ")"
					);
				}
				++ aIndex;
			}
		}

		public static void PrintDetailsOnStdOut (VRGraph<string, int> aGraph)
		{
			Console.WriteLine("{Graph}");
			int aCount = aGraph.Size;
			Console.WriteLine("size: " + aCount);
			int aIndex = 0;
			while (aIndex < aCount) {
				Console.WriteLine("[" + aIndex + "] : " + aGraph[aIndex]);
				// also print details
				PrintNodeDetailsOnStdOut(aGraph, aIndex);
				// end
				++ aIndex;
			}
			Console.WriteLine("ok");
		}


		// test link

		public static void TestLink (
			VRGraph<string, int> aGraph,
			int aSrcIndex, int aDstIndex
		) {
			Console.WriteLine ("nodes: [" + aGraph[aSrcIndex] + "] and [" + aGraph[aDstIndex] + "]");
			if (aGraph.Linked(aSrcIndex, aDstIndex))
				Console.WriteLine("are linked :: " +
					"value (" + aGraph.GetLinkValue(aSrcIndex, aDstIndex) + ")"
				);
			else
				Console.WriteLine("are not linked");
		}

		// main

		public static void Main (string[] args)
		{
			Console.WriteLine ("{Adj Matrix Graph Demo}");
			Console.WriteLine ("");

			VRGraph<string, int> aGraph = new VRGraph<string, int>();

			Console.WriteLine ("inserting some items ...");
			aGraph.Add ("un cazzo");
			aGraph.Add ("una minchia");
			aGraph.Add ("un pacchio");
			aGraph.Add ("adrix");
			aGraph.Insert (0, "dario");
			Console.WriteLine ("");

			// aGraph.DEBUG_Matrix_ListMatrixOnConsole();
			// Console.WriteLine("");

			Console.WriteLine ("linking some items ...");
			aGraph.Link (0, 2, 123);
			aGraph.Link (2, 1, 456);
			Console.WriteLine ("");

			Console.WriteLine ("testing links ...");
			TestLink (aGraph, 0, 2);
			Console.WriteLine ("");
			TestLink (aGraph, 0, 1);
			Console.WriteLine ("");

			PrintDetailsOnStdOut (aGraph);
			Console.WriteLine ("");

			// aGraph.DEBUG_Matrix_ListMatrixOnConsole();
			// Console.WriteLine("");

			Console.WriteLine("binary serialization test");
			Console.WriteLine("writing ...");
			BinaryWriteOnFile (aGraph);
			Console.WriteLine("ok");

			Console.WriteLine("reading ...");
			aGraph = BinaryReadFromFile();
			Console.WriteLine("ok");

			Console.WriteLine("");

			Console.WriteLine("testing links ...");
			TestLink (aGraph, 0, 2);
			Console.WriteLine("");
			TestLink (aGraph, 0, 1);
			Console.WriteLine("");

			PrintDetailsOnStdOut (aGraph);
			Console.WriteLine ("");

			Console.WriteLine ("ok");
			Console.Write ("press enter to close ... ");
			Console.ReadLine();
		} // Main proc

	} // MainProg

}