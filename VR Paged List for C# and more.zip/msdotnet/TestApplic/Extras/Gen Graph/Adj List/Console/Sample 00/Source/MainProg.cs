using System;

using System.IO;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using VRAdrixNT.GenAdjListGraph;

using System.Collections.Generic;

namespace VRAxGenALGraphSampleConApplic00 {

	[Serializable]
	public class VRSampleItem {

		private string theName;

		public VRSampleItem (string aName)
		{
			this.Name = aName;
		}

		public string Name {
			get { return this.theName; }
			set { this.theName = value; }
		}

	}

	[Serializable]
	public class VRSampleValue {

		private int theValue;

		public VRSampleValue (int aValue)
		{
			this.Value = aValue;
		}

		public int Value {
			get { return this.theValue; }
			set { this.theValue = value; }
		}

	}


//========================================================================================

	class MainProg {

		public static int ReadIntLineFromConsole()
		{
			var aStr = Console.ReadLine();
			var aValue = Convert.ToInt32(aStr);
			return aValue;
		}

		// binary serialization

		// write

		public static void BinaryWriteOnFile (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine ("[binary serialization]");
			Console.WriteLine ("writing ...");
			IFormatter aFormatter = new BinaryFormatter();
			FileStream aFileStm = new FileStream("Graph.bin", FileMode.Create);
			try {
				aFormatter.Serialize(aFileStm, aGraph);
				Console.WriteLine("done!");
			} finally {
				aFileStm.Close();
			}
		}

		// read

		public static VRGraph<VRSampleItem, VRSampleValue> BinaryReadFromFile()
		{
			VRGraph<VRSampleItem, VRSampleValue> aGraph = null;
			Console.WriteLine("[binary serialization]");
			Console.WriteLine("reading ...");
			IFormatter aFormatter = new BinaryFormatter();
			FileStream aFileStm = new FileStream("Graph.bin", FileMode.Open);
			try {
				aGraph = (VRGraph<VRSampleItem, VRSampleValue>) 
					aFormatter.Deserialize(aFileStm);
				Console.WriteLine("done!");
			} finally {
				aFileStm.Close();
			}
			return aGraph;
		}


		// list

		public static void ListOnConsole (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine ("");
			Console.WriteLine ("{Graph}");
			int aCount = aGraph.Size;
			int aIndex = 0;
			while (aIndex < aCount) {
				Console.WriteLine ("[" + aIndex + "] : " + aGraph[aIndex].Name);
				++ aIndex;
			}
			Console.WriteLine ("size: (" + aCount + ")");
			Console.WriteLine ("");
		}

		// print details on std out

		public static void PrintNodeDetailsOnStdOut (
			VRGraph<VRSampleItem, VRSampleValue> aGraph,
			int aSrcIndex
		) {
			int aCount = aGraph.Size;
			int aIndex = 0;
			while (aIndex < aCount) {
				int aDstIndex = aIndex;
				if (aGraph.Linked (aSrcIndex, aDstIndex)) {
					Console.WriteLine ("\t" + "- [" + aDstIndex + "] " +
						aGraph[aDstIndex].Name + " : " +
						"(" + aGraph.GetLinkValue(aSrcIndex, aDstIndex).Value + ")"
					);
				}
				++ aIndex;
			}
		}

		public static void PrintDetailsOnStdOut (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine ("{Graph}");
			int aCount = aGraph.Size;
			Console.WriteLine ("size: " + aCount);
			int aIndex = 0;
			while (aIndex < aCount) {
				Console.WriteLine ("[" + aIndex + "] : " + aGraph[aIndex].Name);
				// also print details
				PrintNodeDetailsOnStdOut (aGraph, aIndex);
				// end
				++ aIndex;
			}
			Console.WriteLine ("ok");
		}

		// show paths

		public static void PrintPathOnConsole (
			VRGraph<VRSampleItem, VRSampleValue> aGraph,
			List<int> aPath
		) {
			int aSize = aPath.Count;
			int i = 0;
			while (i < aSize) {
				Console.Write (" > " + aGraph[aPath[i]].Name);
				++ i;
			}
		}

		public static void ShowPathsOnConsole (
			VRGraph<VRSampleItem, VRSampleValue> aGraph,
			int aSrcIndex,
			int aDstIndex
		) {
			Console.WriteLine (aGraph[aSrcIndex].Name + " ==> " + aGraph[aDstIndex].Name);

			List<List<int>> aPathsList =
				VRGraphProcs.FindPaths (aGraph, aSrcIndex, aDstIndex);

			if (aPathsList != null) {

				int aPathsCount = aPathsList.Count;
				int aPathIndex = 0;
				while (aPathIndex < aPathsCount) {

					List<int> aPath = aPathsList[aPathIndex];

					PrintPathOnConsole (aGraph, aPath);

					Console.WriteLine("");

					++ aPathIndex;
				}

			}
			else {
				Console.WriteLine ("no paths");
			}
			Console.WriteLine("");
		}

		// show paths among 2 nodes

		public static void ShowPathsAmongTwoNodes (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			try {
				Console.Write("source index: ");
				int aSrcIndex = ReadIntLineFromConsole();

				Console.Write("destination index: ");
				int aDstIndex = ReadIntLineFromConsole();

				ShowPathsOnConsole (aGraph, aSrcIndex, aDstIndex);
				Console.WriteLine ("ok");
			}
			catch (Exception aExcept) {
				Console.WriteLine (aExcept.Message);
			}
		}

		// show all paths

		public static void ShowAllPathsOnConsole (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			int aSize = aGraph.Size;

			int aSrcNodeIndex = 0;
			while (aSrcNodeIndex < aSize) {

				int aDstNodeIndex = 0;
				while (aDstNodeIndex < aSize) {

					ShowPathsOnConsole (aGraph, aSrcNodeIndex, aDstNodeIndex);

					++ aDstNodeIndex;
				}

				++ aSrcNodeIndex;
			}
		}


		// add

		public static void AddItem (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine ("[add]");
			try {
				Console.Write ("name: ");
				string aName = Console.ReadLine();
				aGraph.Add ( new VRSampleItem(aName) );
				Console.WriteLine ("ok");
			} catch (Exception aExcept) {
				Console.WriteLine (aExcept.Message);
			}
		}

		// insert

		public static void InsertItem (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine("[insert]");
			try {
				Console.Write ("index: ");
				int aIndex = ReadIntLineFromConsole();
				Console.Write ("name: ");
				string aName = Console.ReadLine();
				aGraph.Insert (aIndex, new VRSampleItem(aName));
				Console.WriteLine("ok");
			} catch (Exception aExcept) {
				Console.WriteLine(aExcept.Message);
			}
		}

		// delete

		public static void DeleteItem (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine ("[delete]");
			try {
				Console.Write ("index: ");
				int aIndex = ReadIntLineFromConsole();
				aGraph.Remove (aIndex);
				Console.WriteLine ("ok");
			} catch (Exception aExcept) {
				Console.WriteLine (aExcept.Message);
			}
		}

		// clear

		public static void Clear (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine("[clear]");
			aGraph.Clear();
			Console.WriteLine("done");
		}


		// test nodes link

		public static void TestNodesLink (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine ("[test link]");
			try {
				Console.Write ("source index: ");
				int aSrcIndex = ReadIntLineFromConsole();

				Console.Write ("destination index: ");
				int aDstIndex = ReadIntLineFromConsole();

				Console.WriteLine ("nodes: " +
					"[" + aGraph[aSrcIndex].Name + "] and " +
					"[" + aGraph[aDstIndex].Name + "]"
				);

				if (aGraph.Linked(aSrcIndex, aDstIndex)) {
					// src & dst are linked
					Console.WriteLine ("are linked -- " +
						"value: (" + aGraph.GetLinkValue(aSrcIndex, aDstIndex).Value + ")"
					);
				} else {
					Console.WriteLine ("are not linked");
				}
				Console.WriteLine ("ok");

			} catch (Exception aExcept) {
				Console.WriteLine (aExcept.Message);
			}

		}

		// link nodes

		public static void LinkNodes (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine ("[link]");
			try {
				Console.Write ("source index: ");
				int aSrcIndex = ReadIntLineFromConsole();

				Console.Write ("destination index: ");
				int aDstIndex = ReadIntLineFromConsole();

				if (aGraph.Linked(aSrcIndex, aDstIndex)) {
					Console.WriteLine ("nodes are linked");
					Console.WriteLine ("changing the link value");
				}
				Console.Write ("value: ");
				int aValue = ReadIntLineFromConsole();

				aGraph.Link (aSrcIndex, aDstIndex, new VRSampleValue (aValue));
				Console.WriteLine ("ok");

			} catch (Exception aExcept) {
				Console.WriteLine (aExcept.Message);
			}

		}

		// unlink nodes

		public static void UnlinkNodes (VRGraph<VRSampleItem, VRSampleValue> aGraph)
		{
			Console.WriteLine ("[unlink]");
			try {
				Console.Write ("source index: ");
				int aSrcIndex = ReadIntLineFromConsole();

				Console.Write ("destination index: ");
				int aDstIndex = ReadIntLineFromConsole();

				if (aGraph.Linked (aSrcIndex, aDstIndex)) {
					Console.WriteLine ("nodes are linked");
					Console.WriteLine ("unlinking nodes ...");
					aGraph.Unlink (aSrcIndex, aDstIndex);
					Console.WriteLine ("ok");
				} else {
					Console.WriteLine ("nodes are not linked");
				}

			}
			catch (Exception aExcept) {
				Console.WriteLine (aExcept.Message);
			}

		}


		// main

		public static void Main (string[] args)
		{
			VRGraph<VRSampleItem, VRSampleValue> aGraph =
				new VRGraph<VRSampleItem, VRSampleValue>();

			while (true) {
				Console.WriteLine ("[menu]");
				Console.WriteLine ("[l] list [+] add [++] insert [-] delete [clr] clear");
				Console.WriteLine ("[ld] list details [tk] test link [k] link [u] unlink");
				Console.WriteLine ("{show paths} [p2] among 2 nodes [sap] all nodes");
				Console.WriteLine("{binary serialization} [br] read [bw] write");
				Console.Write ("[q] quit > ");

				var aStr = Console.ReadLine();

				if (aStr == "l") {
					ListOnConsole(aGraph);
				}
				else if (aStr == "ld") {
					PrintDetailsOnStdOut (aGraph);
				}
				else if (aStr == "+") {
					AddItem (aGraph);
				}
				else if (aStr == "++") {
					InsertItem (aGraph);
				}
				else if (aStr == "-") {
					DeleteItem (aGraph);
				}
				else if (aStr == "clr") {
					Clear (aGraph);
				}
				else if (aStr == "tk") {
					TestNodesLink (aGraph);
				}
				else if (aStr == "k") {
					LinkNodes (aGraph);
				}
				else if (aStr == "u") {
					UnlinkNodes (aGraph);
				}
				else if (aStr == "p2") {
					ShowPathsAmongTwoNodes (aGraph);
				}
				else if (aStr == "sap") {
					ShowAllPathsOnConsole (aGraph);
				}
				else if (aStr == "bw") {
					BinaryWriteOnFile (aGraph);
				}
				else if (aStr == "br") {
					aGraph = BinaryReadFromFile();
				}
				else if (aStr == "q") {
					break;
				}
				else {
					Console.WriteLine("???");
				}

			} // repeat

		} // Main proc

	} // MainProg

}