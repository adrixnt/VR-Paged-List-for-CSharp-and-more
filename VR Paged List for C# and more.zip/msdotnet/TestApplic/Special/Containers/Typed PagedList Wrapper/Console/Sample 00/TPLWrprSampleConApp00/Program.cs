﻿using System;

namespace TPLWrprSampleConApp00
{
	class Program
	{
		static void Main (string[] args)
		{
			Console.WriteLine("starting ...");
			MainProg.Main();
		}
	}
}
