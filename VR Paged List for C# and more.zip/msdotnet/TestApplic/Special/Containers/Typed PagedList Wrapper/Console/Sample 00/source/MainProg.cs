
using System;

using System.Collections.Generic;

using VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main;
using VRAdrixNT.Containers.PagedList.LongSized.Untyped.ItemsOrderUtils;

using VRAdrixNT.Collections.Generic;

namespace TPLWrprSampleConApp00 {

	class MainProg {

		public static void Print (IList<string> aList)
		{
			Console.WriteLine ("");
			foreach (string aStrItem in aList) {
				Console.WriteLine (aStrItem);
			}
			Console.WriteLine("");
		}

		public static void Add (IList<string> aList)
		{
			Console.WriteLine ("[add]");
			Console.Write ("value: ");
			var aStrItem = Console.ReadLine();
			aList.Add (aStrItem);
			Console.WriteLine ("ok");
		}

		public static void Insert (IList<string> aList)
		{
			Console.WriteLine ("[insert]");

			Console.Write("index: ");
			var aStrIndex = Console.ReadLine();
			var aIndex = Convert.ToInt32(aStrIndex);

			Console.Write("value: ");
			var aStrItem = Console.ReadLine();

			aList.Insert (aIndex, aStrItem);

			Console.WriteLine("ok");
		}

		public static void Delete (IList<string> aList)
		{
			Console.WriteLine("[delete]");

			Console.Write("index: ");
			var aStrIndex = Console.ReadLine();
			var aIndex = Convert.ToInt32(aStrIndex);

			aList.RemoveAt (aIndex);

			Console.WriteLine("ok");
		}

		public static void Main()
		{
			VRPagedList aPList = new VRPagedList();

			aPList.DataPageSize = 4;
			aPList.RefsPageSize = 4;

			VRPagedListTypedWrapper<string> aList = new VRPagedListTypedWrapper<string>();
			aList.List = aPList;

			while (true) {
				Console.WriteLine ("[menu]");
				Console.WriteLine ("[l] list [+] add [i] insert [-] delete [clr] clear");
				Console.Write ("[q] quit > ");

				var aStr = Console.ReadLine();

				if (aStr == "l") {
					Print (aList);
				}
				else if (aStr == "+") {
					Add (aList);
				}
				else if (aStr == "i") {
					Insert (aList);
				}
				else if (aStr == "-") {
					Delete (aList);
				}
				else if (aStr == "clr") {
					Console.WriteLine("[clear]");
					aList.Clear();
					Console.WriteLine("ok");
				}
				else if (aStr == "q") {
					break;
				}
				else {
					Console.WriteLine("???");
				}
			}
		}

	}

}