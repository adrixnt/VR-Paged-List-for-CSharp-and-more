using System;
using System.Windows.Forms;

namespace VRAx.PagedListMod.TestApplic
{
	class Program
	{
		/// <summary>
		/// Punto di ingresso principale dell'applicazione.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			//Application.SetCompatibleTextRenderingDefault (false);
			Application.Run (new MainTestForm()); /*Form1()*/
		}
	}

}
