using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

// VRAdrixNT
using VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main;
using VRAdrixNT.Containers.PagedList.LongSized.Untyped.ItemsOrderUtils;
//

// serialization support

using System.IO;

using System.Runtime.Serialization.Formatters.Binary;

//

namespace VRAx.PagedListMod.TestApplic
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainTestForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Button theCloseThisFormButton;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel13;
		private System.Windows.Forms.Panel panel14;
		private System.Windows.Forms.Panel panel15;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel16;
		private System.Windows.Forms.Panel panel17;
		private System.Windows.Forms.Panel panel18;
		private System.Windows.Forms.Panel panel19;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Panel panel20;
		private System.Windows.Forms.Panel panel21;
		private System.Windows.Forms.Panel panel22;
		private System.Windows.Forms.TextBox theItemStringTextBox;
		private System.Windows.Forms.Button theSetNewItemStringButton;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox theDataPageSizeTextBox;
		private System.Windows.Forms.TextBox theRefsPageSizeTextBox;
		private System.Windows.Forms.RadioButton theSetUnorderedListRadioButton;
		private System.Windows.Forms.RadioButton theSetAutoAscOrdListRadioButton;
		private System.Windows.Forms.RadioButton theSetAutoDesOrdListRadioButton;
		private System.Windows.Forms.RadioButton theSetIgnoreDuplicsRadioButton;
		private System.Windows.Forms.RadioButton theSetAllowDuplicsRadioButton;
		private System.Windows.Forms.RadioButton theSetDoNotAllowDuplicsRadioButton;
		private System.Windows.Forms.Button theChangeListPropsButton;
		private System.Windows.Forms.ListView theListView;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label theItemsCountLabel;
		private System.Windows.Forms.Label theSelIndexLabel;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Button theDeleteSelectedItemButton;
		private System.Windows.Forms.Button theClearListButton;
		private System.Windows.Forms.Button theInsNewItemBeforeSelButton;
		private System.Windows.Forms.Button theInsNewItemAfterSelButton;
		private System.Windows.Forms.Button theCycleSelItemUpButton;
		private System.Windows.Forms.Button theCycleSelItemDownButton;
		private System.Windows.Forms.Button theCompactListButton;
		private System.Windows.Forms.TextBox theKeyStringTextBox;
		private System.Windows.Forms.CheckBox theSearchReverseModeCheckBox;
		private System.Windows.Forms.CheckBox theFindNearestItemCheckBox;
		private System.Windows.Forms.Button theFindKeyButton;
		private System.Windows.Forms.Button theSerializeListButton;
		private System.Windows.Forms.Button theDeserializeListButton;
		private System.Windows.Forms.Button theReverseListButton;
		private System.Windows.Forms.Button theCheckListOrderButton;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Button theGoToIndexButton;
		private System.Windows.Forms.Button theSkipToPrevItemButton;
		private System.Windows.Forms.Button theSkipToNextItemButton;
		private System.Windows.Forms.Label theCurrentItemStringLabel;
		private System.Windows.Forms.Button theSetCurrentItemButton;
		private System.Windows.Forms.Button theInsertAtCurrentPosButton;
		private System.Windows.Forms.Button theDeleteCurrentItemButton;
		private System.Windows.Forms.TextBox theCurrentIndexTextBox;
		private System.Windows.Forms.CheckBox theUseAccurateBinSearchCheckBox;
		private System.Windows.Forms.MainMenu theMainMenu;
		private System.Windows.Forms.MenuItem theFileMenuItem;
		private System.Windows.Forms.MenuItem theCloseMenuItem;
		private System.Windows.Forms.Button theAddNewItemLastButton;
		private System.Windows.Forms.Button theAddNewItemFirstButton;
		private System.Windows.Forms.Button theSortAscButton;
		private System.Windows.Forms.Button theSortDesButton;
		private System.Windows.Forms.CheckBox theUseFastAccessCheckBox;
		private System.ComponentModel.IContainer components;

		public MainTestForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.InitializeThisForm();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (this.fTheList != null) {
					// clear the list !!
					this.fTheList.Clear();
				}
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainTestForm));
			this.panel2 = new System.Windows.Forms.Panel();
			this.theSortDesButton = new System.Windows.Forms.Button();
			this.theAddNewItemFirstButton = new System.Windows.Forms.Button();
			this.theCheckListOrderButton = new System.Windows.Forms.Button();
			this.theSortAscButton = new System.Windows.Forms.Button();
			this.theReverseListButton = new System.Windows.Forms.Button();
			this.theDeserializeListButton = new System.Windows.Forms.Button();
			this.theSerializeListButton = new System.Windows.Forms.Button();
			this.theCompactListButton = new System.Windows.Forms.Button();
			this.theCycleSelItemDownButton = new System.Windows.Forms.Button();
			this.theCycleSelItemUpButton = new System.Windows.Forms.Button();
			this.theInsNewItemAfterSelButton = new System.Windows.Forms.Button();
			this.theInsNewItemBeforeSelButton = new System.Windows.Forms.Button();
			this.theClearListButton = new System.Windows.Forms.Button();
			this.theDeleteSelectedItemButton = new System.Windows.Forms.Button();
			this.theAddNewItemLastButton = new System.Windows.Forms.Button();
			this.theCloseThisFormButton = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.theListView = new System.Windows.Forms.ListView();
			this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.panel12 = new System.Windows.Forms.Panel();
			this.panel11 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.panel9 = new System.Windows.Forms.Panel();
			this.theSelIndexLabel = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.theItemsCountLabel = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel15 = new System.Windows.Forms.Panel();
			this.theItemStringTextBox = new System.Windows.Forms.TextBox();
			this.panel17 = new System.Windows.Forms.Panel();
			this.panel16 = new System.Windows.Forms.Panel();
			this.panel14 = new System.Windows.Forms.Panel();
			this.theSetNewItemStringButton = new System.Windows.Forms.Button();
			this.panel13 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel20 = new System.Windows.Forms.Panel();
			this.theKeyStringTextBox = new System.Windows.Forms.TextBox();
			this.panel22 = new System.Windows.Forms.Panel();
			this.panel21 = new System.Windows.Forms.Panel();
			this.theSearchReverseModeCheckBox = new System.Windows.Forms.CheckBox();
			this.theFindNearestItemCheckBox = new System.Windows.Forms.CheckBox();
			this.panel19 = new System.Windows.Forms.Panel();
			this.theFindKeyButton = new System.Windows.Forms.Button();
			this.panel18 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.panel4 = new System.Windows.Forms.Panel();
			this.theDeleteCurrentItemButton = new System.Windows.Forms.Button();
			this.theInsertAtCurrentPosButton = new System.Windows.Forms.Button();
			this.theSetCurrentItemButton = new System.Windows.Forms.Button();
			this.theCurrentItemStringLabel = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.theSkipToNextItemButton = new System.Windows.Forms.Button();
			this.theSkipToPrevItemButton = new System.Windows.Forms.Button();
			this.theGoToIndexButton = new System.Windows.Forms.Button();
			this.theCurrentIndexTextBox = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.theUseFastAccessCheckBox = new System.Windows.Forms.CheckBox();
			this.theUseAccurateBinSearchCheckBox = new System.Windows.Forms.CheckBox();
			this.theChangeListPropsButton = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.theSetIgnoreDuplicsRadioButton = new System.Windows.Forms.RadioButton();
			this.theSetAllowDuplicsRadioButton = new System.Windows.Forms.RadioButton();
			this.theSetDoNotAllowDuplicsRadioButton = new System.Windows.Forms.RadioButton();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.theSetAutoDesOrdListRadioButton = new System.Windows.Forms.RadioButton();
			this.theSetAutoAscOrdListRadioButton = new System.Windows.Forms.RadioButton();
			this.theSetUnorderedListRadioButton = new System.Windows.Forms.RadioButton();
			this.theRefsPageSizeTextBox = new System.Windows.Forms.TextBox();
			this.theDataPageSizeTextBox = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.theMainMenu = new System.Windows.Forms.MainMenu(this.components);
			this.theFileMenuItem = new System.Windows.Forms.MenuItem();
			this.theCloseMenuItem = new System.Windows.Forms.MenuItem();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel15.SuspendLayout();
			this.panel14.SuspendLayout();
			this.panel13.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel20.SuspendLayout();
			this.panel21.SuspendLayout();
			this.panel19.SuspendLayout();
			this.panel18.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.theSortDesButton);
			this.panel2.Controls.Add(this.theAddNewItemFirstButton);
			this.panel2.Controls.Add(this.theCheckListOrderButton);
			this.panel2.Controls.Add(this.theSortAscButton);
			this.panel2.Controls.Add(this.theReverseListButton);
			this.panel2.Controls.Add(this.theDeserializeListButton);
			this.panel2.Controls.Add(this.theSerializeListButton);
			this.panel2.Controls.Add(this.theCompactListButton);
			this.panel2.Controls.Add(this.theCycleSelItemDownButton);
			this.panel2.Controls.Add(this.theCycleSelItemUpButton);
			this.panel2.Controls.Add(this.theInsNewItemAfterSelButton);
			this.panel2.Controls.Add(this.theInsNewItemBeforeSelButton);
			this.panel2.Controls.Add(this.theClearListButton);
			this.panel2.Controls.Add(this.theDeleteSelectedItemButton);
			this.panel2.Controls.Add(this.theAddNewItemLastButton);
			this.panel2.Controls.Add(this.theCloseThisFormButton);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel2.Location = new System.Drawing.Point(543, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(227, 704);
			this.panel2.TabIndex = 1;
			// 
			// theSortDesButton
			// 
			this.theSortDesButton.Location = new System.Drawing.Point(13, 478);
			this.theSortDesButton.Name = "theSortDesButton";
			this.theSortDesButton.Size = new System.Drawing.Size(67, 28);
			this.theSortDesButton.TabIndex = 16;
			this.theSortDesButton.Text = "Sort DES";
			this.theSortDesButton.Click += new System.EventHandler(this.theSortDesButton_Click);
			// 
			// theAddNewItemFirstButton
			// 
			this.theAddNewItemFirstButton.Image = ((System.Drawing.Image)(resources.GetObject("theAddNewItemFirstButton.Image")));
			this.theAddNewItemFirstButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theAddNewItemFirstButton.Location = new System.Drawing.Point(13, 55);
			this.theAddNewItemFirstButton.Name = "theAddNewItemFirstButton";
			this.theAddNewItemFirstButton.Size = new System.Drawing.Size(87, 28);
			this.theAddNewItemFirstButton.TabIndex = 15;
			this.theAddNewItemFirstButton.Text = "Add First";
			this.theAddNewItemFirstButton.Click += new System.EventHandler(this.theAddNewItemFirstButton_Click);
			// 
			// theCheckListOrderButton
			// 
			this.theCheckListOrderButton.Location = new System.Drawing.Point(13, 513);
			this.theCheckListOrderButton.Name = "theCheckListOrderButton";
			this.theCheckListOrderButton.Size = new System.Drawing.Size(87, 28);
			this.theCheckListOrderButton.TabIndex = 14;
			this.theCheckListOrderButton.Text = "Check Order";
			this.theCheckListOrderButton.Click += new System.EventHandler(this.theCheckListOrderButton_Click);
			// 
			// theSortAscButton
			// 
			this.theSortAscButton.Location = new System.Drawing.Point(13, 444);
			this.theSortAscButton.Name = "theSortAscButton";
			this.theSortAscButton.Size = new System.Drawing.Size(67, 27);
			this.theSortAscButton.TabIndex = 12;
			this.theSortAscButton.Text = "Sort ASC";
			this.theSortAscButton.Click += new System.EventHandler(this.theSortAscButton_Click);
			// 
			// theReverseListButton
			// 
			this.theReverseListButton.Location = new System.Drawing.Point(13, 409);
			this.theReverseListButton.Name = "theReverseListButton";
			this.theReverseListButton.Size = new System.Drawing.Size(67, 28);
			this.theReverseListButton.TabIndex = 11;
			this.theReverseListButton.Text = "Reverse";
			this.theReverseListButton.Click += new System.EventHandler(this.theReverseListButton_Click);
			// 
			// theDeserializeListButton
			// 
			this.theDeserializeListButton.Image = ((System.Drawing.Image)(resources.GetObject("theDeserializeListButton.Image")));
			this.theDeserializeListButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theDeserializeListButton.Location = new System.Drawing.Point(120, 49);
			this.theDeserializeListButton.Name = "theDeserializeListButton";
			this.theDeserializeListButton.Size = new System.Drawing.Size(87, 27);
			this.theDeserializeListButton.TabIndex = 10;
			this.theDeserializeListButton.Text = "Deserialize";
			this.theDeserializeListButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.theDeserializeListButton.Click += new System.EventHandler(this.theDeserializeListButton_Click);
			// 
			// theSerializeListButton
			// 
			this.theSerializeListButton.Image = ((System.Drawing.Image)(resources.GetObject("theSerializeListButton.Image")));
			this.theSerializeListButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theSerializeListButton.Location = new System.Drawing.Point(120, 14);
			this.theSerializeListButton.Name = "theSerializeListButton";
			this.theSerializeListButton.Size = new System.Drawing.Size(87, 28);
			this.theSerializeListButton.TabIndex = 9;
			this.theSerializeListButton.Text = "Serialize";
			this.theSerializeListButton.Click += new System.EventHandler(this.theSerializeListButton_Click);
			// 
			// theCompactListButton
			// 
			this.theCompactListButton.Image = ((System.Drawing.Image)(resources.GetObject("theCompactListButton.Image")));
			this.theCompactListButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theCompactListButton.Location = new System.Drawing.Point(13, 361);
			this.theCompactListButton.Name = "theCompactListButton";
			this.theCompactListButton.Size = new System.Drawing.Size(94, 27);
			this.theCompactListButton.TabIndex = 8;
			this.theCompactListButton.Text = "Compact";
			this.theCompactListButton.Click += new System.EventHandler(this.theCompactListButton_Click);
			// 
			// theCycleSelItemDownButton
			// 
			this.theCycleSelItemDownButton.Image = ((System.Drawing.Image)(resources.GetObject("theCycleSelItemDownButton.Image")));
			this.theCycleSelItemDownButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theCycleSelItemDownButton.Location = new System.Drawing.Point(13, 319);
			this.theCycleSelItemDownButton.Name = "theCycleSelItemDownButton";
			this.theCycleSelItemDownButton.Size = new System.Drawing.Size(94, 28);
			this.theCycleSelItemDownButton.TabIndex = 7;
			this.theCycleSelItemDownButton.Text = "Cycle d&own";
			this.theCycleSelItemDownButton.Click += new System.EventHandler(this.theCycleSelItemDownButton_Click);
			// 
			// theCycleSelItemUpButton
			// 
			this.theCycleSelItemUpButton.Image = ((System.Drawing.Image)(resources.GetObject("theCycleSelItemUpButton.Image")));
			this.theCycleSelItemUpButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theCycleSelItemUpButton.Location = new System.Drawing.Point(13, 284);
			this.theCycleSelItemUpButton.Name = "theCycleSelItemUpButton";
			this.theCycleSelItemUpButton.Size = new System.Drawing.Size(94, 28);
			this.theCycleSelItemUpButton.TabIndex = 6;
			this.theCycleSelItemUpButton.Text = "Cycle &up";
			this.theCycleSelItemUpButton.Click += new System.EventHandler(this.theCycleSelItemUpButton_Click);
			// 
			// theInsNewItemAfterSelButton
			// 
			this.theInsNewItemAfterSelButton.Image = ((System.Drawing.Image)(resources.GetObject("theInsNewItemAfterSelButton.Image")));
			this.theInsNewItemAfterSelButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theInsNewItemAfterSelButton.Location = new System.Drawing.Point(13, 166);
			this.theInsNewItemAfterSelButton.Name = "theInsNewItemAfterSelButton";
			this.theInsNewItemAfterSelButton.Size = new System.Drawing.Size(107, 28);
			this.theInsNewItemAfterSelButton.TabIndex = 3;
			this.theInsNewItemAfterSelButton.Text = "Insert A&fter";
			this.theInsNewItemAfterSelButton.Click += new System.EventHandler(this.theInsNewItemAfterSelButton_Click);
			// 
			// theInsNewItemBeforeSelButton
			// 
			this.theInsNewItemBeforeSelButton.Image = ((System.Drawing.Image)(resources.GetObject("theInsNewItemBeforeSelButton.Image")));
			this.theInsNewItemBeforeSelButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theInsNewItemBeforeSelButton.Location = new System.Drawing.Point(13, 132);
			this.theInsNewItemBeforeSelButton.Name = "theInsNewItemBeforeSelButton";
			this.theInsNewItemBeforeSelButton.Size = new System.Drawing.Size(107, 27);
			this.theInsNewItemBeforeSelButton.TabIndex = 2;
			this.theInsNewItemBeforeSelButton.Text = "Insert &Before";
			this.theInsNewItemBeforeSelButton.Click += new System.EventHandler(this.theInsNewItemBeforeSelButton_Click);
			// 
			// theClearListButton
			// 
			this.theClearListButton.Image = ((System.Drawing.Image)(resources.GetObject("theClearListButton.Image")));
			this.theClearListButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theClearListButton.Location = new System.Drawing.Point(13, 243);
			this.theClearListButton.Name = "theClearListButton";
			this.theClearListButton.Size = new System.Drawing.Size(80, 27);
			this.theClearListButton.TabIndex = 5;
			this.theClearListButton.Text = "Clear";
			this.theClearListButton.Click += new System.EventHandler(this.theClearListButton_Click);
			// 
			// theDeleteSelectedItemButton
			// 
			this.theDeleteSelectedItemButton.Image = ((System.Drawing.Image)(resources.GetObject("theDeleteSelectedItemButton.Image")));
			this.theDeleteSelectedItemButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theDeleteSelectedItemButton.Location = new System.Drawing.Point(13, 208);
			this.theDeleteSelectedItemButton.Name = "theDeleteSelectedItemButton";
			this.theDeleteSelectedItemButton.Size = new System.Drawing.Size(80, 28);
			this.theDeleteSelectedItemButton.TabIndex = 4;
			this.theDeleteSelectedItemButton.Text = "&Delete";
			this.theDeleteSelectedItemButton.Click += new System.EventHandler(this.theDeleteSelectedItemButton_Click);
			// 
			// theAddNewItemLastButton
			// 
			this.theAddNewItemLastButton.Image = ((System.Drawing.Image)(resources.GetObject("theAddNewItemLastButton.Image")));
			this.theAddNewItemLastButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theAddNewItemLastButton.Location = new System.Drawing.Point(13, 90);
			this.theAddNewItemLastButton.Name = "theAddNewItemLastButton";
			this.theAddNewItemLastButton.Size = new System.Drawing.Size(87, 28);
			this.theAddNewItemLastButton.TabIndex = 1;
			this.theAddNewItemLastButton.Text = "&Add Last";
			this.theAddNewItemLastButton.Click += new System.EventHandler(this.theAddNewItemLastButton_Click);
			// 
			// theCloseThisFormButton
			// 
			this.theCloseThisFormButton.Image = ((System.Drawing.Image)(resources.GetObject("theCloseThisFormButton.Image")));
			this.theCloseThisFormButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theCloseThisFormButton.Location = new System.Drawing.Point(13, 14);
			this.theCloseThisFormButton.Name = "theCloseThisFormButton";
			this.theCloseThisFormButton.Size = new System.Drawing.Size(74, 28);
			this.theCloseThisFormButton.TabIndex = 0;
			this.theCloseThisFormButton.Text = "Close";
			this.theCloseThisFormButton.Click += new System.EventHandler(this.theCloseThisFormButton_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.panel5);
			this.panel1.Controls.Add(this.panel4);
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(543, 704);
			this.panel1.TabIndex = 0;
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.panel8);
			this.panel5.Controls.Add(this.panel7);
			this.panel5.Controls.Add(this.panel6);
			this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel5.Location = new System.Drawing.Point(0, 132);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(543, 427);
			this.panel5.TabIndex = 1;
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.theListView);
			this.panel8.Controls.Add(this.panel12);
			this.panel8.Controls.Add(this.panel11);
			this.panel8.Controls.Add(this.panel10);
			this.panel8.Controls.Add(this.panel9);
			this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel8.Location = new System.Drawing.Point(0, 62);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(543, 323);
			this.panel8.TabIndex = 1;
			// 
			// theListView
			// 
			this.theListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
			this.theListView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.theListView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.theListView.FullRowSelect = true;
			this.theListView.HideSelection = false;
			this.theListView.LabelEdit = true;
			this.theListView.Location = new System.Drawing.Point(7, 28);
			this.theListView.MultiSelect = false;
			this.theListView.Name = "theListView";
			this.theListView.Size = new System.Drawing.Size(529, 288);
			this.theListView.TabIndex = 4;
			this.theListView.UseCompatibleStateImageBehavior = false;
			this.theListView.View = System.Windows.Forms.View.Details;
			this.theListView.AfterLabelEdit += new System.Windows.Forms.LabelEditEventHandler(this.theListView_AfterLabelEdit);
			this.theListView.SelectedIndexChanged += new System.EventHandler(this.theListView_SelectedIndexChanged);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Item Text String";
			this.columnHeader1.Width = 300;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Index";
			this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// panel12
			// 
			this.panel12.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel12.Location = new System.Drawing.Point(0, 28);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(7, 288);
			this.panel12.TabIndex = 3;
			// 
			// panel11
			// 
			this.panel11.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel11.Location = new System.Drawing.Point(536, 28);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(7, 288);
			this.panel11.TabIndex = 2;
			// 
			// panel10
			// 
			this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel10.Location = new System.Drawing.Point(0, 316);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(543, 7);
			this.panel10.TabIndex = 1;
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.theSelIndexLabel);
			this.panel9.Controls.Add(this.label9);
			this.panel9.Controls.Add(this.theItemsCountLabel);
			this.panel9.Controls.Add(this.label7);
			this.panel9.Controls.Add(this.label1);
			this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel9.Location = new System.Drawing.Point(0, 0);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(543, 28);
			this.panel9.TabIndex = 0;
			// 
			// theSelIndexLabel
			// 
			this.theSelIndexLabel.AutoSize = true;
			this.theSelIndexLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.theSelIndexLabel.Location = new System.Drawing.Point(287, 7);
			this.theSelIndexLabel.Name = "theSelIndexLabel";
			this.theSelIndexLabel.Size = new System.Drawing.Size(77, 13);
			this.theSelIndexLabel.TabIndex = 4;
			this.theSelIndexLabel.Text = "9999999999";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(233, 7);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(54, 13);
			this.label9.TabIndex = 3;
			this.label9.Text = "Sel.Index:";
			// 
			// theItemsCountLabel
			// 
			this.theItemsCountLabel.AutoSize = true;
			this.theItemsCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.theItemsCountLabel.Location = new System.Drawing.Point(140, 7);
			this.theItemsCountLabel.Name = "theItemsCountLabel";
			this.theItemsCountLabel.Size = new System.Drawing.Size(77, 13);
			this.theItemsCountLabel.TabIndex = 2;
			this.theItemsCountLabel.Text = "9999999999";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(67, 7);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(66, 13);
			this.label7.TabIndex = 1;
			this.label7.Text = "Items.Count:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(7, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(49, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "the &List";
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.panel15);
			this.panel7.Controls.Add(this.panel14);
			this.panel7.Controls.Add(this.panel13);
			this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel7.Location = new System.Drawing.Point(0, 385);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(543, 42);
			this.panel7.TabIndex = 1;
			// 
			// panel15
			// 
			this.panel15.Controls.Add(this.theItemStringTextBox);
			this.panel15.Controls.Add(this.panel17);
			this.panel15.Controls.Add(this.panel16);
			this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel15.Location = new System.Drawing.Point(47, 0);
			this.panel15.Name = "panel15";
			this.panel15.Size = new System.Drawing.Size(416, 42);
			this.panel15.TabIndex = 1;
			// 
			// theItemStringTextBox
			// 
			this.theItemStringTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.theItemStringTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.theItemStringTextBox.Location = new System.Drawing.Point(0, 7);
			this.theItemStringTextBox.Name = "theItemStringTextBox";
			this.theItemStringTextBox.Size = new System.Drawing.Size(416, 23);
			this.theItemStringTextBox.TabIndex = 2;
			// 
			// panel17
			// 
			this.panel17.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel17.Location = new System.Drawing.Point(0, 35);
			this.panel17.Name = "panel17";
			this.panel17.Size = new System.Drawing.Size(416, 7);
			this.panel17.TabIndex = 1;
			// 
			// panel16
			// 
			this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel16.Location = new System.Drawing.Point(0, 0);
			this.panel16.Name = "panel16";
			this.panel16.Size = new System.Drawing.Size(416, 7);
			this.panel16.TabIndex = 0;
			// 
			// panel14
			// 
			this.panel14.Controls.Add(this.theSetNewItemStringButton);
			this.panel14.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel14.Location = new System.Drawing.Point(463, 0);
			this.panel14.Name = "panel14";
			this.panel14.Size = new System.Drawing.Size(80, 42);
			this.panel14.TabIndex = 2;
			// 
			// theSetNewItemStringButton
			// 
			this.theSetNewItemStringButton.Image = ((System.Drawing.Image)(resources.GetObject("theSetNewItemStringButton.Image")));
			this.theSetNewItemStringButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.theSetNewItemStringButton.Location = new System.Drawing.Point(7, 7);
			this.theSetNewItemStringButton.Name = "theSetNewItemStringButton";
			this.theSetNewItemStringButton.Size = new System.Drawing.Size(62, 28);
			this.theSetNewItemStringButton.TabIndex = 0;
			this.theSetNewItemStringButton.Text = "Set";
			this.theSetNewItemStringButton.Click += new System.EventHandler(this.theSetNewItemStringButton_Click);
			// 
			// panel13
			// 
			this.panel13.Controls.Add(this.label2);
			this.panel13.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel13.Location = new System.Drawing.Point(0, 0);
			this.panel13.Name = "panel13";
			this.panel13.Size = new System.Drawing.Size(47, 42);
			this.panel13.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(7, 7);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(36, 13);
			this.label2.TabIndex = 0;
			this.label2.Text = "Text:";
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.panel20);
			this.panel6.Controls.Add(this.panel19);
			this.panel6.Controls.Add(this.panel18);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel6.Location = new System.Drawing.Point(0, 0);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(543, 62);
			this.panel6.TabIndex = 0;
			// 
			// panel20
			// 
			this.panel20.Controls.Add(this.theKeyStringTextBox);
			this.panel20.Controls.Add(this.panel22);
			this.panel20.Controls.Add(this.panel21);
			this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel20.Location = new System.Drawing.Point(40, 0);
			this.panel20.Name = "panel20";
			this.panel20.Size = new System.Drawing.Size(423, 62);
			this.panel20.TabIndex = 1;
			// 
			// theKeyStringTextBox
			// 
			this.theKeyStringTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.theKeyStringTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.theKeyStringTextBox.Location = new System.Drawing.Point(0, 7);
			this.theKeyStringTextBox.Name = "theKeyStringTextBox";
			this.theKeyStringTextBox.Size = new System.Drawing.Size(423, 21);
			this.theKeyStringTextBox.TabIndex = 2;
			// 
			// panel22
			// 
			this.panel22.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel22.Location = new System.Drawing.Point(0, 0);
			this.panel22.Name = "panel22";
			this.panel22.Size = new System.Drawing.Size(423, 7);
			this.panel22.TabIndex = 1;
			// 
			// panel21
			// 
			this.panel21.Controls.Add(this.theSearchReverseModeCheckBox);
			this.panel21.Controls.Add(this.theFindNearestItemCheckBox);
			this.panel21.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel21.Location = new System.Drawing.Point(0, 28);
			this.panel21.Name = "panel21";
			this.panel21.Size = new System.Drawing.Size(423, 34);
			this.panel21.TabIndex = 0;
			// 
			// theSearchReverseModeCheckBox
			// 
			this.theSearchReverseModeCheckBox.Location = new System.Drawing.Point(93, 7);
			this.theSearchReverseModeCheckBox.Name = "theSearchReverseModeCheckBox";
			this.theSearchReverseModeCheckBox.Size = new System.Drawing.Size(67, 21);
			this.theSearchReverseModeCheckBox.TabIndex = 1;
			this.theSearchReverseModeCheckBox.Text = "Reverse";
			// 
			// theFindNearestItemCheckBox
			// 
			this.theFindNearestItemCheckBox.Location = new System.Drawing.Point(13, 7);
			this.theFindNearestItemCheckBox.Name = "theFindNearestItemCheckBox";
			this.theFindNearestItemCheckBox.Size = new System.Drawing.Size(74, 21);
			this.theFindNearestItemCheckBox.TabIndex = 0;
			this.theFindNearestItemCheckBox.Text = "Nearest";
			// 
			// panel19
			// 
			this.panel19.Controls.Add(this.theFindKeyButton);
			this.panel19.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel19.Location = new System.Drawing.Point(463, 0);
			this.panel19.Name = "panel19";
			this.panel19.Size = new System.Drawing.Size(80, 62);
			this.panel19.TabIndex = 2;
			// 
			// theFindKeyButton
			// 
			this.theFindKeyButton.Image = ((System.Drawing.Image)(resources.GetObject("theFindKeyButton.Image")));
			this.theFindKeyButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theFindKeyButton.Location = new System.Drawing.Point(7, 7);
			this.theFindKeyButton.Name = "theFindKeyButton";
			this.theFindKeyButton.Size = new System.Drawing.Size(66, 28);
			this.theFindKeyButton.TabIndex = 0;
			this.theFindKeyButton.Text = "Find";
			this.theFindKeyButton.Click += new System.EventHandler(this.theFindKeyButton_Click);
			// 
			// panel18
			// 
			this.panel18.Controls.Add(this.label3);
			this.panel18.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel18.Location = new System.Drawing.Point(0, 0);
			this.panel18.Name = "panel18";
			this.panel18.Size = new System.Drawing.Size(40, 62);
			this.panel18.TabIndex = 0;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(7, 7);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(32, 13);
			this.label3.TabIndex = 0;
			this.label3.Text = "Key:";
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.theDeleteCurrentItemButton);
			this.panel4.Controls.Add(this.theInsertAtCurrentPosButton);
			this.panel4.Controls.Add(this.theSetCurrentItemButton);
			this.panel4.Controls.Add(this.theCurrentItemStringLabel);
			this.panel4.Controls.Add(this.label11);
			this.panel4.Controls.Add(this.theSkipToNextItemButton);
			this.panel4.Controls.Add(this.theSkipToPrevItemButton);
			this.panel4.Controls.Add(this.theGoToIndexButton);
			this.panel4.Controls.Add(this.theCurrentIndexTextBox);
			this.panel4.Controls.Add(this.label10);
			this.panel4.Controls.Add(this.label8);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel4.Location = new System.Drawing.Point(0, 559);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(543, 145);
			this.panel4.TabIndex = 2;
			// 
			// theDeleteCurrentItemButton
			// 
			this.theDeleteCurrentItemButton.Location = new System.Drawing.Point(153, 62);
			this.theDeleteCurrentItemButton.Name = "theDeleteCurrentItemButton";
			this.theDeleteCurrentItemButton.Size = new System.Drawing.Size(60, 21);
			this.theDeleteCurrentItemButton.TabIndex = 10;
			this.theDeleteCurrentItemButton.Text = "Delete";
			this.theDeleteCurrentItemButton.Click += new System.EventHandler(this.theDeleteCurrentItemButton_Click);
			// 
			// theInsertAtCurrentPosButton
			// 
			this.theInsertAtCurrentPosButton.Location = new System.Drawing.Point(87, 62);
			this.theInsertAtCurrentPosButton.Name = "theInsertAtCurrentPosButton";
			this.theInsertAtCurrentPosButton.Size = new System.Drawing.Size(60, 21);
			this.theInsertAtCurrentPosButton.TabIndex = 9;
			this.theInsertAtCurrentPosButton.Text = "Insert";
			this.theInsertAtCurrentPosButton.Click += new System.EventHandler(this.theInsertAtCurrentPosButton_Click);
			// 
			// theSetCurrentItemButton
			// 
			this.theSetCurrentItemButton.Location = new System.Drawing.Point(27, 62);
			this.theSetCurrentItemButton.Name = "theSetCurrentItemButton";
			this.theSetCurrentItemButton.Size = new System.Drawing.Size(53, 21);
			this.theSetCurrentItemButton.TabIndex = 8;
			this.theSetCurrentItemButton.Text = "Set";
			this.theSetCurrentItemButton.Click += new System.EventHandler(this.theSetCurrentItemButton_Click);
			// 
			// theCurrentItemStringLabel
			// 
			this.theCurrentItemStringLabel.AutoSize = true;
			this.theCurrentItemStringLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.theCurrentItemStringLabel.Location = new System.Drawing.Point(87, 42);
			this.theCurrentItemStringLabel.Name = "theCurrentItemStringLabel";
			this.theCurrentItemStringLabel.Size = new System.Drawing.Size(25, 15);
			this.theCurrentItemStringLabel.TabIndex = 7;
			this.theCurrentItemStringLabel.Text = "xxx";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(7, 42);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(80, 13);
			this.label11.TabIndex = 6;
			this.label11.Text = "Current Item:";
			// 
			// theSkipToNextItemButton
			// 
			this.theSkipToNextItemButton.Location = new System.Drawing.Point(320, 14);
			this.theSkipToNextItemButton.Name = "theSkipToNextItemButton";
			this.theSkipToNextItemButton.Size = new System.Drawing.Size(60, 21);
			this.theSkipToNextItemButton.TabIndex = 5;
			this.theSkipToNextItemButton.Text = "Next >>";
			this.theSkipToNextItemButton.Click += new System.EventHandler(this.theSkipToNextItemButton_Click);
			// 
			// theSkipToPrevItemButton
			// 
			this.theSkipToPrevItemButton.Location = new System.Drawing.Point(253, 14);
			this.theSkipToPrevItemButton.Name = "theSkipToPrevItemButton";
			this.theSkipToPrevItemButton.Size = new System.Drawing.Size(60, 21);
			this.theSkipToPrevItemButton.TabIndex = 4;
			this.theSkipToPrevItemButton.Text = "<< Prev";
			this.theSkipToPrevItemButton.Click += new System.EventHandler(this.theSkipToPrevItemButton_Click);
			// 
			// theGoToIndexButton
			// 
			this.theGoToIndexButton.Location = new System.Drawing.Point(200, 14);
			this.theGoToIndexButton.Name = "theGoToIndexButton";
			this.theGoToIndexButton.Size = new System.Drawing.Size(47, 21);
			this.theGoToIndexButton.TabIndex = 3;
			this.theGoToIndexButton.Text = "Go!";
			this.theGoToIndexButton.Click += new System.EventHandler(this.theGoToIndexButton_Click);
			// 
			// theCurrentIndexTextBox
			// 
			this.theCurrentIndexTextBox.Location = new System.Drawing.Point(120, 14);
			this.theCurrentIndexTextBox.Name = "theCurrentIndexTextBox";
			this.theCurrentIndexTextBox.Size = new System.Drawing.Size(73, 20);
			this.theCurrentIndexTextBox.TabIndex = 2;
			this.theCurrentIndexTextBox.Text = "000";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.Location = new System.Drawing.Point(80, 14);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(42, 13);
			this.label10.TabIndex = 1;
			this.label10.Text = "Index:";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(7, 7);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(77, 13);
			this.label8.TabIndex = 0;
			this.label8.Text = "Iterator Test";
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.theUseFastAccessCheckBox);
			this.panel3.Controls.Add(this.theUseAccurateBinSearchCheckBox);
			this.panel3.Controls.Add(this.theChangeListPropsButton);
			this.panel3.Controls.Add(this.groupBox2);
			this.panel3.Controls.Add(this.groupBox1);
			this.panel3.Controls.Add(this.theRefsPageSizeTextBox);
			this.panel3.Controls.Add(this.theDataPageSizeTextBox);
			this.panel3.Controls.Add(this.label6);
			this.panel3.Controls.Add(this.label5);
			this.panel3.Controls.Add(this.label4);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel3.Location = new System.Drawing.Point(0, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(543, 132);
			this.panel3.TabIndex = 0;
			// 
			// theUseFastAccessCheckBox
			// 
			this.theUseFastAccessCheckBox.Location = new System.Drawing.Point(293, 104);
			this.theUseFastAccessCheckBox.Name = "theUseFastAccessCheckBox";
			this.theUseFastAccessCheckBox.Size = new System.Drawing.Size(100, 21);
			this.theUseFastAccessCheckBox.TabIndex = 9;
			this.theUseFastAccessCheckBox.Text = "use fast access";
			this.theUseFastAccessCheckBox.Click += new System.EventHandler(this.theUseFastAccessCheckBox_Click);
			// 
			// theUseAccurateBinSearchCheckBox
			// 
			this.theUseAccurateBinSearchCheckBox.Location = new System.Drawing.Point(127, 104);
			this.theUseAccurateBinSearchCheckBox.Name = "theUseAccurateBinSearchCheckBox";
			this.theUseAccurateBinSearchCheckBox.Size = new System.Drawing.Size(146, 21);
			this.theUseAccurateBinSearchCheckBox.TabIndex = 7;
			this.theUseAccurateBinSearchCheckBox.Text = "accurate ordered search";
			// 
			// theChangeListPropsButton
			// 
			this.theChangeListPropsButton.Image = ((System.Drawing.Image)(resources.GetObject("theChangeListPropsButton.Image")));
			this.theChangeListPropsButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.theChangeListPropsButton.Location = new System.Drawing.Point(353, 14);
			this.theChangeListPropsButton.Name = "theChangeListPropsButton";
			this.theChangeListPropsButton.Size = new System.Drawing.Size(54, 28);
			this.theChangeListPropsButton.TabIndex = 8;
			this.theChangeListPropsButton.Text = "set";
			this.theChangeListPropsButton.Click += new System.EventHandler(this.theChangeListPropsButton_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.theSetIgnoreDuplicsRadioButton);
			this.groupBox2.Controls.Add(this.theSetAllowDuplicsRadioButton);
			this.groupBox2.Controls.Add(this.theSetDoNotAllowDuplicsRadioButton);
			this.groupBox2.Location = new System.Drawing.Point(233, 14);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(114, 90);
			this.groupBox2.TabIndex = 6;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Duplicates Mode";
			// 
			// theSetIgnoreDuplicsRadioButton
			// 
			this.theSetIgnoreDuplicsRadioButton.Location = new System.Drawing.Point(5, 61);
			this.theSetIgnoreDuplicsRadioButton.Name = "theSetIgnoreDuplicsRadioButton";
			this.theSetIgnoreDuplicsRadioButton.Size = new System.Drawing.Size(102, 17);
			this.theSetIgnoreDuplicsRadioButton.TabIndex = 2;
			this.theSetIgnoreDuplicsRadioButton.Text = "Ignore Duplics";
			// 
			// theSetAllowDuplicsRadioButton
			// 
			this.theSetAllowDuplicsRadioButton.Location = new System.Drawing.Point(5, 38);
			this.theSetAllowDuplicsRadioButton.Name = "theSetAllowDuplicsRadioButton";
			this.theSetAllowDuplicsRadioButton.Size = new System.Drawing.Size(102, 17);
			this.theSetAllowDuplicsRadioButton.TabIndex = 1;
			this.theSetAllowDuplicsRadioButton.Text = "Allow Duplics";
			// 
			// theSetDoNotAllowDuplicsRadioButton
			// 
			this.theSetDoNotAllowDuplicsRadioButton.Location = new System.Drawing.Point(5, 17);
			this.theSetDoNotAllowDuplicsRadioButton.Name = "theSetDoNotAllowDuplicsRadioButton";
			this.theSetDoNotAllowDuplicsRadioButton.Size = new System.Drawing.Size(102, 18);
			this.theSetDoNotAllowDuplicsRadioButton.TabIndex = 0;
			this.theSetDoNotAllowDuplicsRadioButton.Text = "do NOT Allow";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.theSetAutoDesOrdListRadioButton);
			this.groupBox1.Controls.Add(this.theSetAutoAscOrdListRadioButton);
			this.groupBox1.Controls.Add(this.theSetUnorderedListRadioButton);
			this.groupBox1.Location = new System.Drawing.Point(120, 14);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(107, 90);
			this.groupBox1.TabIndex = 5;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Auto Order Type";
			// 
			// theSetAutoDesOrdListRadioButton
			// 
			this.theSetAutoDesOrdListRadioButton.Location = new System.Drawing.Point(7, 62);
			this.theSetAutoDesOrdListRadioButton.Name = "theSetAutoDesOrdListRadioButton";
			this.theSetAutoDesOrdListRadioButton.Size = new System.Drawing.Size(86, 18);
			this.theSetAutoDesOrdListRadioButton.TabIndex = 2;
			this.theSetAutoDesOrdListRadioButton.Text = "Descending";
			// 
			// theSetAutoAscOrdListRadioButton
			// 
			this.theSetAutoAscOrdListRadioButton.Location = new System.Drawing.Point(7, 42);
			this.theSetAutoAscOrdListRadioButton.Name = "theSetAutoAscOrdListRadioButton";
			this.theSetAutoAscOrdListRadioButton.Size = new System.Drawing.Size(86, 17);
			this.theSetAutoAscOrdListRadioButton.TabIndex = 1;
			this.theSetAutoAscOrdListRadioButton.Text = "Ascending";
			// 
			// theSetUnorderedListRadioButton
			// 
			this.theSetUnorderedListRadioButton.Location = new System.Drawing.Point(7, 21);
			this.theSetUnorderedListRadioButton.Name = "theSetUnorderedListRadioButton";
			this.theSetUnorderedListRadioButton.Size = new System.Drawing.Size(86, 15);
			this.theSetUnorderedListRadioButton.TabIndex = 0;
			this.theSetUnorderedListRadioButton.Text = "Unordered";
			// 
			// theRefsPageSizeTextBox
			// 
			this.theRefsPageSizeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.theRefsPageSizeTextBox.Location = new System.Drawing.Point(47, 55);
			this.theRefsPageSizeTextBox.Name = "theRefsPageSizeTextBox";
			this.theRefsPageSizeTextBox.Size = new System.Drawing.Size(53, 23);
			this.theRefsPageSizeTextBox.TabIndex = 4;
			// 
			// theDataPageSizeTextBox
			// 
			this.theDataPageSizeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.theDataPageSizeTextBox.Location = new System.Drawing.Point(47, 28);
			this.theDataPageSizeTextBox.Name = "theDataPageSizeTextBox";
			this.theDataPageSizeTextBox.Size = new System.Drawing.Size(53, 23);
			this.theDataPageSizeTextBox.TabIndex = 3;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(13, 62);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(37, 13);
			this.label6.TabIndex = 2;
			this.label6.Text = "Refs:";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(13, 35);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(38, 13);
			this.label5.TabIndex = 1;
			this.label5.Text = "Data:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(7, 7);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(103, 13);
			this.label4.TabIndex = 0;
			this.label4.Text = "B+Tree Pages Sizes";
			// 
			// theMainMenu
			// 
			this.theMainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.theFileMenuItem});
			// 
			// theFileMenuItem
			// 
			this.theFileMenuItem.Index = 0;
			this.theFileMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.theCloseMenuItem});
			this.theFileMenuItem.Text = "&File";
			// 
			// theCloseMenuItem
			// 
			this.theCloseMenuItem.Index = 0;
			this.theCloseMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlQ;
			this.theCloseMenuItem.Text = "C&lose";
			this.theCloseMenuItem.Click += new System.EventHandler(this.theCloseTestApplicMenuItem_Click);
			// 
			// MainTestForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(770, 704);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.KeyPreview = true;
			this.Menu = this.theMainMenu;
			this.Name = "MainTestForm";
			this.Text = ">> VR Paged List Test Application";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainTestForm_KeyDown);
			this.panel2.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel9.PerformLayout();
			this.panel7.ResumeLayout(false);
			this.panel15.ResumeLayout(false);
			this.panel15.PerformLayout();
			this.panel14.ResumeLayout(false);
			this.panel13.ResumeLayout(false);
			this.panel13.PerformLayout();
			this.panel6.ResumeLayout(false);
			this.panel20.ResumeLayout(false);
			this.panel20.PerformLayout();
			this.panel21.ResumeLayout(false);
			this.panel19.ResumeLayout(false);
			this.panel18.ResumeLayout(false);
			this.panel18.PerformLayout();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		//[STAThread]
		//static void Main() 
		//{
			//Application.Run (new MainTestForm());
		//}

//=======================================================================================

	private VRPagedList fTheList = null;

	private VRPagedListIterator fTheListIterator = null;

//=======================================================================================

	private void InitializeThisForm()
	{
		// create the list
		this.fTheList = new VRPagedList();
		// init the list
		this.fTheList.DataPageSize = 4L;
		this.fTheList.RefsPageSize = 4L;
		this.fTheList.IteratorNearMoveThreshold = 8L;
		//
		//this.theUseFastAccessCheckBox.Checked = this.fTheList.UseFastAccess;
		//
		this.UpdateListPropsDisplay();
		//
		// create the list iterator
		this.fTheListIterator = new VRPagedListIterator (this.fTheList);
		//
		this.DoListContentsChanged (this.fTheList);
		this.fTheList.ListChangesListener += new VRPagedListChangesListener (this.DoListContentsChanged);
		//
	}

//=======================================================================================
// list serialization

	public void DoSerializeList()
	{
		try {
			FileStream fs = new FileStream ("ListFile.dat", FileMode.Create);
			try {
				BinaryFormatter formatter = new BinaryFormatter();
				// try to serialize the list
				try {
					formatter.Serialize (fs, this.fTheList);
				}
				catch (Exception x) {
					MessageBox.Show (x.Message, "Serialization Error!");
				}
				// done!
			} finally {
				fs.Close();
			}
		} catch (Exception x) {
			MessageBox.Show (x.Message);
		}
	}

//=======================================================================================
// list de-serialization

	public void DoDeserializeList()
	{
		try {
			FileStream fs = new FileStream ("ListFile.dat", FileMode.Open);
			try {
				BinaryFormatter formatter = new BinaryFormatter();
				// try to deserialize the list
				try {
					this.fTheList = (VRPagedList) formatter.Deserialize (fs);
					// ok!
					// have new list ...
					//
					this.UpdateListPropsDisplay();
					//
					// take care of open iterators ...
					this.fTheListIterator.IterateOn (this.fTheList);
					//
					// event handlers are NOT also serialized !!
					this.DoListContentsChanged (this.fTheList);
					this.fTheList.ListChangesListener += new VRPagedListChangesListener (this.DoListContentsChanged);
					// ok!
				} catch (Exception x) {
					MessageBox.Show (x.Message, "Deserialization Error!");
				}
				// done!
			} finally {
				fs.Close();
			}
		} catch (Exception x) {
			MessageBox.Show (x.Message);
		}
	}


//=======================================================================================
// List Properties

#region List Properties

	public void DoToggleUseFastAccess()
	{
		bool aValue = this.theUseFastAccessCheckBox.Checked;
		//this.fTheList.UseFastAccess = aValue;
		//if (this.fTheList.UseFastAccess)
			//MessageBox.Show ("using fast access", "Look at me");
		//end if
		this.theUseFastAccessCheckBox.Checked = false; //this.fTheList.UseFastAccess;
	}

	public void UpdateListPropsDisplay()
	{
		// the use fast access indicator
		//this.theUseFastAccessCheckBox.Checked = this.fTheList.UseFastAccess;

		// data/refs pages sizes
		this.theDataPageSizeTextBox.Text = this.fTheList.DataPageSize.ToString();
		this.theRefsPageSizeTextBox.Text = this.fTheList.RefsPageSize.ToString();
		//
		// auto order type prop
		int aOrdType = this.fTheList.AutoOrderType;
		if (aOrdType > 0)
			// ascending order
			this.theSetAutoAscOrdListRadioButton.Checked = true;
		else
		if (aOrdType < 0)
			// descending order
			this.theSetAutoDesOrdListRadioButton.Checked = true;
		else
			// unordered
			this.theSetUnorderedListRadioButton.Checked = true;
		//end if
		//
		// duplicates mode
		if (this.fTheList.IsDoNotAllowDuplicateItems())
			this.theSetDoNotAllowDuplicsRadioButton.Checked = true;
		else
		if (this.fTheList.IsAllowDuplicateItems())
			this.theSetAllowDuplicsRadioButton.Checked = true;
		else
			this.theSetIgnoreDuplicsRadioButton.Checked = true;
		//end if
		//
		this.theUseAccurateBinSearchCheckBox.Checked = this.fTheList.AccurateOrderedSearch;
		//
		//MessageBox.Show ("updated !!", "Ok");
	}

	public void ChangeListPropsFromControls()
	{
		try {
			// get values
			long aDataPageSize = long.Parse (this.theDataPageSizeTextBox.Text);
			long aRefsPageSize = long.Parse (this.theRefsPageSizeTextBox.Text);
			// set
			this.fTheList.DataPageSize = aDataPageSize;
			this.fTheList.RefsPageSize = aRefsPageSize;
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Warning!");
		}
		//
		this.fTheList.IteratorNearMoveThreshold = this.fTheList.DataPageSize * 3;
		//
		// auto order type prop
		int aOrdType = 0;
		if (this.theSetUnorderedListRadioButton.Checked)
			aOrdType = (0);
		else
		if (this.theSetAutoAscOrdListRadioButton.Checked)
			aOrdType = (+1);
		else
		if (this.theSetAutoDesOrdListRadioButton.Checked)
			aOrdType = (-1);
		//end if
		this.fTheList.AutoOrderType = aOrdType;
		//
		// duplicates mode
		if (this.theSetDoNotAllowDuplicsRadioButton.Checked)
			this.fTheList.SetDoNotAllowDuplicateItems();
		else
		if (this.theSetAllowDuplicsRadioButton.Checked)
			this.fTheList.SetAllowDuplicateItems();
		else
		if (this.theSetIgnoreDuplicsRadioButton.Checked)
			this.fTheList.SetIgnoreDuplicateItems();
		//end if
		//
		// accurate binary search mode
		this.fTheList.AccurateOrderedSearch = this.theUseAccurateBinSearchCheckBox.Checked;
		//
		// update display
		this.UpdateListPropsDisplay();
	}

#endregion

//=======================================================================================
// list changes

#region list changes

	public void DoListContentsChanged (VRPagedList aList)
	{
		bool anyList = (aList != null);
		long aItemsCount = 0L;
		if (anyList)
			aItemsCount = aList.ItemsCount;
		//end if
		bool isListEmpty = (aItemsCount <= 0);

		int aSelIndex = this.GetSelectedIndex();

		this.theListView.Items.Clear();
		if (anyList) {
			// fill the list view
			this.theListView.BeginUpdate();
			try {
				long aIndex = 0;
				foreach (object aItem in aList) {
					ListViewItem aLVItem = new ListViewItem();
					// init
					aLVItem.Text = aItem.ToString();
					aLVItem.SubItems.Add ("#" + aIndex);
					// add
					this.theListView.Items.Add (aLVItem);
					// next
					++ aIndex;
				}
			} finally {
				this.theListView.EndUpdate();
			}
		}

		this.SetSelectedIndex (aSelIndex);

		// display items.count
		this.theItemsCountLabel.Text = aItemsCount.ToString();
		this.theSelIndexLabel.Text = aSelIndex.ToString();

		// update the item text string
		if (anyList)
			if (aList.IsItemIndexValid (aSelIndex))
				this.theItemStringTextBox.Text = aList[aSelIndex].ToString();
			//end if
		//end if

		//
		this.DoListIteratorChanged();
	}

	public void DoListIteratorChanged()
	{
		long aIndex = this.fTheListIterator.Index;

		this.theCurrentIndexTextBox.Text = aIndex.ToString();

		if (this.fTheListIterator.IsItemIndexValid())
			// valid item index
			try {
				this.theCurrentItemStringLabel.Text = this.fTheListIterator.Item.ToString();
				this.theCurrentItemStringLabel.Enabled = true;
				// ok!
			} catch (Exception x) {
				// just in the case the current item is null !!
				this.theCurrentItemStringLabel.Text = x.Message;
				this.theCurrentItemStringLabel.Enabled = false;
			}
		else {
			// out-of-bounds iterator
			this.theCurrentItemStringLabel.Text = "<< Invalid Item Index >>";
			this.theCurrentItemStringLabel.Enabled = false;
		}//end if
	}

#endregion

//=======================================================================================

	public int GetSelectedIndex()
	{
		int aCount = this.theListView.SelectedIndices.Count;
		if (aCount > 0) {
			int aIndex = this.theListView.SelectedIndices[0];
			return aIndex;
		}
		return (-1);
	}

	public void SetSelectedIndex (int aIndex)
	{
		//if (aIndex < 0) {
			//this.theListView.SelectedIndices = null;
			//return;
		//}
		//this.theListView.SelectedIndices.Count = 1;
		if ((aIndex >= 0) && (aIndex < this.theListView.Items.Count))
			this.theListView.EnsureVisible (aIndex);
		//end if
	}

//=======================================================================================

	public void DoAddNewItem (bool wantAddAsFirst)
	{
		string aStringItem = this.theItemStringTextBox.Text;
		try {
			long aIndex = this.fTheList.GenericAddItem (aStringItem, wantAddAsFirst);
			// ok!
			this.SetSelectedIndex ((int) aIndex);
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Add Error!");
		}
	}

	public void DoAddNewItemFirst()
	{
		this.DoAddNewItem (true);
	}

	public void DoAddNewItemLast()
	{
		this.DoAddNewItem (false);
	}


	public void DoInsertNewItem (int aIndex)
	{
		string aStringItem = this.theItemStringTextBox.Text;
		try {
			this.fTheList.InsertItemAtIndex (aIndex, aStringItem);
			// ok!
			this.SetSelectedIndex (aIndex);
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Insert Error!");
		}
	}

	public void DoInsertNewItemBeforeSelection()
	{
		int aSelIndex = this.GetSelectedIndex();
		this.DoInsertNewItem (aSelIndex);
	}

	public void DoInsertNewItemAfterSelection()
	{
		int aSelIndex = this.GetSelectedIndex();
		this.DoInsertNewItem (aSelIndex + 1);
	}


//=======================================================================================

	public void DoReplaceSelectedItem()
	{
		try {
			int aSelIndex = this.GetSelectedIndex();
			string aStringItem = this.theItemStringTextBox.Text;
			this.fTheList [aSelIndex] = aStringItem;
			// ok!
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Replace Error!");
		}
	}

//=======================================================================================

	public void DoDeleteSelectedItem()
	{
		int aSelIndex = this.GetSelectedIndex();
		try {
			this.fTheList.DeleteItemAtIndex (aSelIndex);
			if (aSelIndex >= this.fTheList.ItemsCount)
				aSelIndex -= (1);
			this.SetSelectedIndex (aSelIndex);
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Delete Error!");
		}
	}

	public void DoClearList()
	{
		// lock changes notifications
		this.fTheList.LockListChangedEvent();
		try {
			// clear
			this.fTheList.DeleteAllItems();
			//this.fTheList.Clear();
		} finally {
			// unlock changes notifications
			this.fTheList.UnlockListChangedEvent();
		}
	}

//=======================================================================================

	public void DoCycleItem (bool wantCycleUp)
	{
		try {
			int aSelIndex = this.GetSelectedIndex();
			this.fTheList.LockListChangedEvent();
			try {
				if (wantCycleUp)
					// up
					aSelIndex = (int) this.fTheList.CycleItemUp (aSelIndex);
					//aSelIndex = (int) this.fTheList.BubbleCycleItem (aSelIndex, -1L);
					//aSelIndex = (int) this.fTheList.BubbleMoveItem (aSelIndex, -1L);
					//aSelIndex = (int) this.fTheList.BubbleCycleItems (aSelIndex, /*/count:/*/2L, -1L);
					//aSelIndex = (int) this.fTheList.BubbleMoveItems (aSelIndex, /*/count:/*/2L, -1L);
				else
					// down
					aSelIndex = (int) this.fTheList.CycleItemDown (aSelIndex);
					//aSelIndex = (int) this.fTheList.BubbleCycleItem (aSelIndex, +1L);
					//aSelIndex = (int) this.fTheList.BubbleMoveItem (aSelIndex, +1L);
					//aSelIndex = (int) this.fTheList.BubbleCycleItems (aSelIndex, /*/count:/*/2L, +1L);
					//aSelIndex = (int) this.fTheList.BubbleMoveItems (aSelIndex, /*/count:/*/2L, +1L);
				//end if
				this.SetSelectedIndex (aSelIndex);
				// ok!
			} finally {
				this.fTheList.UnlockListChangedEvent();
			}
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Relocate Error!");
		}
	}

//=======================================================================================

	public void DoFindItemIndexByKey()
	{
		long aIndex = (-1L);
		string aKeyStr = this.theKeyStringTextBox.Text;
		bool isDirectMode = ! this.theSearchReverseModeCheckBox.Checked;
		bool isExact = ! this.theFindNearestItemCheckBox.Checked;
		try {
			if (isExact)
				// find item
				if (isDirectMode)
					// Direct
					aIndex = this.fTheList.FindFirstOrderedItemIndexKey (aKeyStr);
				else
					// Reverse
					aIndex = this.fTheList.FindLastOrderedItemIndexKey (aKeyStr);
				//end if
			else
				// find nearest item
				if (isDirectMode)
					// Direct
					aIndex = this.fTheList.FindFirstNearestOrderedItemIndexKey (aKeyStr);
				else
					// Reverse
					aIndex = this.fTheList.FindLastNearestOrderedItemIndexKey (aKeyStr);
				//end if
			//end if
			// show
			this.SetSelectedIndex ((int) aIndex);
			bool found = this.fTheList.IsItemIndexValid (aIndex);
			MessageBox.Show (
				"item index: (" + aIndex + ").\n" + ((found) ? "Ok, Found." : "Sorry, NOT Found!"),
				"Find Key"
			);
			// ok!
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Find Error!");
		}
	}

//=======================================================================================

	public void DoCompactList()
	{
		this.fTheList.Compact();
		MessageBox.Show ("Compact: done!");
		Console.WriteLine ("Compact: done!");
	}

//=======================================================================================

	public void DoReverseList()
	{
		this.fTheList.LockListChangedEvent();
		try {
			VRPListItemsOrdUtils.Reverse (this.fTheList);
		} finally {
			this.fTheList.UnlockListChangedEvent();
		}
	}

	public void DoSortList (int aOrderType)
	{
		//bool wantSortInAscOrd = ! this.theSortDescendingCheckBox.Checked;
		this.fTheList.LockListChangedEvent();
		try {
			VRPListItemsOrdUtils.QuickSort (this.fTheList, aOrderType);
		} finally {
			this.fTheList.UnlockListChangedEvent();
		}
	}

	public void DoSortListAsc()
	{
		this.DoSortList (+1);
	}

	public void DoSortListDes()
	{
		this.DoSortList (-1);
	}


	public void DoCheckListItemsOrder()
	{
		int aOrdCode = VRPListItemsOrdUtils.ComputeOrderType (this.fTheList, null);
		// test order type
		string aOrdCodeStr = null; // "unordered";
		if (aOrdCode > 0)
			aOrdCodeStr = "Ascending Ordered";
		else
		if (aOrdCode < 0)
			aOrdCodeStr = "Descending Ordered";
		else
			aOrdCodeStr = "unordered"; //aOrdCodeStr = aOrdCodeStr;
		//end if
		MessageBox.Show ("the list is " + aOrdCodeStr + ".");
		// done!
	}

//=======================================================================================
// list iterator operations

	public void DoSkipToPrevItem()
	{
		this.fTheListIterator.Prev();
		// update!
		this.DoListIteratorChanged();
	}

	public void DoSkipToNextItem()
	{
		this.fTheListIterator.Next();
		// update!
		this.DoListIteratorChanged();
	}

	public void DoGoToIndex()
	{
		try {
			long aIndex = long.Parse(this.theCurrentIndexTextBox.Text);
			this.fTheListIterator.GoTo (aIndex);
			// update!
			this.DoListIteratorChanged();
			// ok!
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Go To Error!");
		}
	}

	public void DoSetCurrentItem()
	{
		try {
			string aItemStr = this.theItemStringTextBox.Text;
			// set!
			this.fTheListIterator.Item = aItemStr;
			// done!
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Set Current Item Error!");
		}
	}

	public void DoInsertAtCurrentPosition()
	{
		try {
			string aItemStr = this.theItemStringTextBox.Text;
			// insert!
			this.fTheListIterator.InsertItem (aItemStr);
			// done!
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Insert at current position Error!");
		}
	}

	public void DoDeleteCurrentItem()
	{
		try {
			// delete!
			this.fTheListIterator.DeleteItem();
			// done!
		} catch (Exception x) {
			MessageBox.Show (x.Message, "Delete current item Error!");
		}
	}

//=======================================================================================

		private void theCloseThisFormButton_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void theUseFastAccessCheckBox_Click(object sender, System.EventArgs e)
		{
			this.DoToggleUseFastAccess();
		}

		private void theChangeListPropsButton_Click(object sender, System.EventArgs e)
		{
			this.ChangeListPropsFromControls();
		}

		/*/
		private void theAddNewItemButton_Click(object sender, System.EventArgs e)
		{
			this.DoAddNewItem();
		}
		/*/

		private void theAddNewItemFirstButton_Click(object sender, System.EventArgs e)
		{
			this.DoAddNewItemFirst();
		}

		private void theAddNewItemLastButton_Click(object sender, System.EventArgs e)
		{
			this.DoAddNewItemLast();
		}

		private void theDeleteSelectedItemButton_Click(object sender, System.EventArgs e)
		{
			this.DoDeleteSelectedItem();
		}

		private void theClearListButton_Click(object sender, System.EventArgs e)
		{
			this.DoClearList();
		}

		private void theInsNewItemBeforeSelButton_Click(object sender, System.EventArgs e)
		{
			this.DoInsertNewItemBeforeSelection();
		}

		private void theInsNewItemAfterSelButton_Click(object sender, System.EventArgs e)
		{
			this.DoInsertNewItemAfterSelection();
		}

		private void theSetNewItemStringButton_Click(object sender, System.EventArgs e)
		{
			this.DoReplaceSelectedItem();
		}

		private void theListView_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int aSelIndex = this.GetSelectedIndex();
			if (this.fTheList.IsItemIndexValid (aSelIndex))
				this.theItemStringTextBox.Text = this.fTheList[aSelIndex].ToString();
			//end if
			this.theSelIndexLabel.Text = aSelIndex.ToString();
		}

		private void theListView_AfterLabelEdit(object sender, System.Windows.Forms.LabelEditEventArgs e)
		{
			if (e.Label == null) return;
			string aNewString = e.Label;
			int aIndex = e.Item;
			if (this.fTheList.IsItemIndexValid (aIndex))
				// note: the following will raise a list changed event
				// so causing a repaint of the list !!
				try {
					this.fTheList[aIndex] = aNewString;
				} catch (Exception x) {
					MessageBox.Show (x.Message, "Replace Error!");
					e.CancelEdit = true;
				}
			//end if
		}

		private void theCycleSelItemUpButton_Click(object sender, System.EventArgs e)
		{
			this.DoCycleItem (true);
		}

		private void theCycleSelItemDownButton_Click(object sender, System.EventArgs e)
		{
			this.DoCycleItem (false);
		}

		private void theCompactListButton_Click(object sender, System.EventArgs e)
		{
			this.DoCompactList();
		}

		private void theFindKeyButton_Click(object sender, System.EventArgs e)
		{
			this.DoFindItemIndexByKey();
		}

		private void theSerializeListButton_Click(object sender, System.EventArgs e)
		{
			this.DoSerializeList();
		}

		private void theDeserializeListButton_Click(object sender, System.EventArgs e)
		{
			this.DoDeserializeList();
		}

		private void theReverseListButton_Click(object sender, System.EventArgs e)
		{
			this.DoReverseList();
		}

		/*/
		private void button1_Click(object sender, System.EventArgs e)
		{
			this.DoSortList();
		}
		/*/

		private void theSortAscButton_Click(object sender, System.EventArgs e)
		{
			this.DoSortListAsc();
		}

		private void theSortDesButton_Click(object sender, System.EventArgs e)
		{
			this.DoSortListDes();
		}

		private void theCheckListOrderButton_Click(object sender, System.EventArgs e)
		{
			this.DoCheckListItemsOrder();
		}

		private void theSkipToPrevItemButton_Click(object sender, System.EventArgs e)
		{
			this.DoSkipToPrevItem();
		}

		private void theSkipToNextItemButton_Click(object sender, System.EventArgs e)
		{
			this.DoSkipToNextItem();
		}

		private void theGoToIndexButton_Click(object sender, System.EventArgs e)
		{
			this.DoGoToIndex();
		}

		private void theSetCurrentItemButton_Click(object sender, System.EventArgs e)
		{
			this.DoSetCurrentItem();
		}

		private void theInsertAtCurrentPosButton_Click(object sender, System.EventArgs e)
		{
			this.DoInsertAtCurrentPosition();
		}

		private void theDeleteCurrentItemButton_Click(object sender, System.EventArgs e)
		{
			this.DoDeleteCurrentItem();
		}

		/*/
		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
		/*/

		private void theCloseTestApplicMenuItem_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void MainTestForm_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Escape) {
				e.Handled = true;
				this.Close();
			}
		}


	}
}
