
using System;

using System.IO;

using System.Runtime.Serialization.Formatters.Binary;

//

// using VRAdrixNT.Containers.PagedList.Main;
// using VRAdrixNT.Containers.PagedList.ItemsOrderUtils;
//

// VRAdrixNT
using VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main;
using VRAdrixNT.Containers.PagedList.LongSized.Untyped.ItemsOrderUtils;
//


public class SampleApp
{

	public static void Print (VRPagedList aList)
	{
		VRPagedListIterator aIter = new VRPagedListIterator (aList, 0L);
		while (aIter.IsItemIndexValid()) {
			object aItem = aIter.Item;
			Console.WriteLine ("(" + aIter.Index + ") : " + aItem);
			++ aIter;
		}
		Console.WriteLine ("items.count: (" + aList.ItemsCount + ")");
	}

	public static void Main()
	{
		VRPagedList aList = new VRPagedList();

		aList.DataPageSize = 4;
		aList.RefsPageSize = 4;

		Console.WriteLine ("testing an unordered list ...");
		Console.WriteLine ("");

		Console.WriteLine ("inserting some items ...");

		aList.InsertItemLast ("adrix");
		aList.InsertItemLast ("dario");
		aList.InsertItemLast ("ornella");
		aList.InsertItemLast ("zarko");
		aList.InsertItemLast ("sandra");
		aList.InsertItemLast ("didina");
		aList.InsertItemLast ("donatella");

		try {
			aList.InsertItemAtIndex (-1, "cazzo!");
		} catch (Exception x) {
			Console.WriteLine (x.Message);
		}

		Console.WriteLine ("the list");
		Print (aList);
		Console.WriteLine ("");

		Console.WriteLine ("deleting item #2");
		aList.DeleteItemAtIndex (2);
		Console.WriteLine ("");

		Console.WriteLine ("compacting the list ...");
		aList.Compact();
		Console.WriteLine ("");

		Console.WriteLine ("foreach loop on the list ...");
		foreach (string aStrItem in aList) 
		{
			Console.WriteLine ( aStrItem );
		}
		Console.WriteLine ("");

		Console.WriteLine ("the list");
		Print (aList);
		Console.WriteLine ("");

		Console.WriteLine ("clearing the list ...");
		aList.Clear();

		Console.WriteLine ("the list");
		Print (aList);
		Console.WriteLine ("");

		Console.WriteLine ("press enter to continue ...");
		Console.ReadLine();

		Console.WriteLine ("=============================================================================");

		Console.WriteLine ("testing an ordered list ...");
		Console.WriteLine ("");

		aList.SetAutoAscendingOrder();

		aList.InsertOrderedItemLast ("ornella");
		aList.InsertOrderedItemLast ("adrix");
		aList.InsertOrderedItemLast ("dario");
		aList.InsertOrderedItemLast ("zarko");
		aList.InsertOrderedItemLast ("sandra");

		Console.WriteLine ("the list");
		Print (aList);
		Console.WriteLine ("");

		Console.WriteLine ("clearing the list ...");
		aList.Clear();

		Console.WriteLine ("press enter to continue ...");
		Console.ReadLine();

		Console.WriteLine ("=============================================================================");

		Console.WriteLine ("testing an insert iterator on the list ...");
		Console.WriteLine ("");

		aList.SetUnordered();
		{
			VRPagedListIterator aIter = new VRPagedListIterator (aList, 0);
			while (true) {
				Console.WriteLine ("the list");
				Print (aList);
				Console.WriteLine ("");

				Console.Write ("value (enter a null string to stop): ");
				string aString = Console.ReadLine();

				if (aString == "") break;

				aIter.InsertItem (aString);
			}
			Console.WriteLine ("done!");

			Console.WriteLine ("the list");
			Print (aList);
			Console.WriteLine ("");
		}

		Console.WriteLine ("clearing the list ...");
		aList.Clear();

		Console.WriteLine ("press enter to continue ...");
		Console.ReadLine();

		Console.WriteLine ("=============================================================================");

		Console.WriteLine ("serialization test ...");
		Console.WriteLine ("");

		{
			Console.WriteLine ("filling the list ...");
			aList.InsertItemLast ("adrix");
			aList.InsertItemLast ("dario");
			aList.InsertItemLast ("ornella");
			aList.InsertItemLast ("zarko");
			aList.InsertItemLast ("sandra");
			aList.InsertItemLast ("didina");
			aList.InsertItemLast ("donatella");

			Console.WriteLine ("the list");
			Print (aList);
			Console.WriteLine ("");
		}

		{
			Console.WriteLine ("serialization ...");

			FileStream fs = new FileStream ("ListFile.dat", FileMode.Create);
			try {
				BinaryFormatter formatter = new BinaryFormatter();

				try {
					formatter.Serialize(fs, aList);
				}
				catch (Exception x) {
					Console.WriteLine (x.Message);
				}

			} finally {
				fs.Close();
			}
			Console.WriteLine ("done!");
			Console.WriteLine ("");
		}

		{
			Console.WriteLine ("de-serialization ...");

			FileStream fs = new FileStream ("ListFile.dat", FileMode.Open);
			try {
				BinaryFormatter formatter = new BinaryFormatter();

				try {
					aList = (VRPagedList) formatter.Deserialize (fs);
				} 
				catch (Exception x) 
				{
					Console.WriteLine (x.Message);
				}

			}
			finally {
				fs.Close();
			}

			Console.WriteLine ("the list");
			Print (aList);
			Console.WriteLine ("");
		}

		Console.WriteLine ("clearing the list ...");
		aList.Clear();

		Console.WriteLine ("press enter to continue ...");
		Console.ReadLine();

		Console.WriteLine ("items order utils demo ... ");
		{
			Console.WriteLine ("filling the list ...");
			aList.InsertItemLast ("ornella");
			aList.InsertItemLast ("sandra");
			aList.InsertItemLast ("adrix");
			aList.InsertItemLast ("dario");
			aList.InsertItemLast ("zarko");
			aList.InsertItemLast ("didina");
			aList.InsertItemLast ("donatella");
			aList.InsertItemLast ("mamma");

			Console.WriteLine ("the list");
			Print (aList);
			Console.WriteLine ("");

			Console.WriteLine ("reversing the list");
			VRPListItemsOrdUtils.Reverse (aList);
			Console.WriteLine ("done!");

			Console.WriteLine ("the list");
			Print (aList);
			Console.WriteLine ("");

			Console.WriteLine ("testing items order ...");
			{
				int aOrderCode = VRPListItemsOrdUtils.ComputeOrderType (aList, null);
				Console.WriteLine ("order code: (" + aOrderCode + ")");
				Console.WriteLine ("");
			}

			Console.WriteLine ("sorting the list in ascending order ...");
			VRPListItemsOrdUtils.AscendingOrderQuickSort (aList);
			Console.WriteLine ("done!");

			Console.WriteLine ("the list");
			Print (aList);
			Console.WriteLine ("");

			Console.WriteLine ("testing items order ...");
			{
				int aOrderCode = VRPListItemsOrdUtils.ComputeOrderType (aList, null);
				Console.WriteLine ("order code: (" + aOrderCode + ")");
				Console.WriteLine ("");
			}

		}

		Console.WriteLine ("clearing the list ...");
		aList.Clear();

		Console.WriteLine ("press enter to continue ...");
		Console.ReadLine();

		// done!
	}

}

// that's all folks ...