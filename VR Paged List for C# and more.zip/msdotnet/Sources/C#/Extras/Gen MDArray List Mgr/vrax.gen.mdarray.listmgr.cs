using System;

using System.Collections.Generic;

using VRAdrixNT.Utils.RangeCheck;

using VRAdrixNT.BasicUtils.IntArray;

namespace VRAdrixNT.GenMDArrayListMgr
{

	public interface /*/ abstract class /*/ IVRMDArrayLMgrAbstNewDefaultValueProvider<T>
	{
		// public VRMDArrayAbstNewDefaultValueProvider() {}

		/*/public abstract/*/ T GetNewDefaultValue();
	}

	// MDArray List Manager <T>

	public class VRMDArrayListMgr<T>
	{

		// init

		public VRMDArrayListMgr()
		{

		}


		// the default value

		private T theDefaultValue;

		public T DefaultValue {
			get { return this.theDefaultValue; }
			set { this.theDefaultValue = value; }
		}

		// the default value provider

		private IVRMDArrayLMgrAbstNewDefaultValueProvider<T> theNewDefaultValueProvider = null;

		public IVRMDArrayLMgrAbstNewDefaultValueProvider<T> NewDefaultValueProvider
		{
			get { return this.theNewDefaultValueProvider; }
			set { this.theNewDefaultValueProvider = value; }
		}

		// get new default value

		private T GetNewDefaultValue()
		{
			IVRMDArrayLMgrAbstNewDefaultValueProvider<T> aProvider = this.NewDefaultValueProvider;
			if (aProvider != null)
				return aProvider.GetNewDefaultValue();
			// end if
			return this.DefaultValue;
		}

		// the abstract list

		private IList<T> theList = null;

		public IList<T> List {
			get { return this.theList; }
			set { this.theList = value; }
		}

		// list basic procs

		// list size

		private int ListSize { get { return this.List.Count; } }

		// insert value into list

		private void InsertValueIntoList (int aIndex, T aValue)
		{
			this.List.Insert (aIndex, aValue);
		}

		// delete value from list

		private void DeleteValueFromList (int aIndex)
		{
			this.List.RemoveAt (aIndex);
		}

		// get / set value at index

		private T GetListValue (int aIndex)
		{
			return this.List [aIndex];
		}

		private void SetListValue (int aIndex, T aValue)
		{
			this.List [aIndex] = aValue;
		}

		// other list procs

		// add default value to list

		private void AddDefaultValueToList()
		{
			int aInsIndex = this.ListSize;
			T aDefaultValue = this.GetNewDefaultValue();
			this.InsertValueIntoList (aInsIndex, aDefaultValue);
		}

		// delete items range from list

		private void DeleteItemsRangeFromList (int aDelIndex, int aDelCount)
		{
			int aCount = aDelCount;
			while (aCount > 0) {
				this.DeleteValueFromList (aDelIndex);
				-- aCount;
			} // repeat
		}

		// expand the list as needed

		private void ExpandListAsNeeded (int aNewListSize)
		{
			int aInsIndex = this.ListSize;

			int aInsertedCount = 0;

			try {

				while (this.ListSize < aNewListSize) {

					// add default value
					this.AddDefaultValueToList();

					++ aInsertedCount;

				} // repeat

			} catch (Exception aExcept) {

				// rollback
				this.DeleteItemsRangeFromList (aInsIndex, aInsertedCount);

				throw aExcept; // raise again

			}
			// ok
		}

		// move right list items

		private void MoveListItemsRight (int aDstIndex, int aSrcIndex, int aMoveCount)
		{
			int aIndex = aMoveCount - 1; // start moving from the end, the last item
			while (aIndex >= 0) {
				// copy source item to dest item from the end
				// aArray [aDstIndex + aIndex] = aArray [aSrcIndex + aIndex]
				this.SetListValue (aDstIndex + aIndex, this.GetListValue(aSrcIndex + aIndex));
				-- aIndex;
			}
		}

		// move left list items

		private void MoveListItemsLeft (int aDstIndex, int aSrcIndex, int aMoveCount)
		{
			int aIndex = 0; // start moving from the begin, the first item
			while (aIndex < aMoveCount) {
				// copy source item to dest item from the start
				// aArray [aDstIndex + aIndex] = aArray [aSrcIndex + aIndex]
				this.SetListValue (aDstIndex + aIndex, this.GetListValue(aSrcIndex + aIndex));
				++ aIndex;
			}
		}

		// fill list range with default value

		private void FillListRangeWithDefaultValue (int aFillIndex, int aFillCount)
		{
			int aIndex = 0;
			while (aIndex < aFillCount) {
				this.SetListValue (aFillIndex + aIndex, this.GetNewDefaultValue());
				++ aIndex;
			}
		}


		// level sizes

		private int[] theLevelsSizes = null;


		private int MaxLevel {
			get { return this.GetDimensions() - 1; } // { return this.theLevelsSizes.Length - 1; }
		}

		private int DataLevel {
			get { return this.MaxLevel; }
		}

		private bool IsDataLevel (int aLevel)
		{
			return (aLevel == this.DataLevel);
		}

		private void PrivSetLevelSize (int aLevel, int aSize)
		{
			this.theLevelsSizes[aLevel] = aSize;
		}

		private int GetLevelSize (int aLevel)
		{
			return this.theLevelsSizes[aLevel];
		}

		// restore dimensions

		public void RestoreDimSize (int aDimIndex, int aDimSize)
		{
			this.PrivSetLevelSize (aDimIndex, aDimSize);
		}

		public void RestoreDimensionsSizes (int[] aDimsSizes)
		{
			int aDimsCount = aDimsSizes.Length;
			this.theLevelsSizes = new int [aDimsCount];
			Array.Copy (
				aDimsSizes, 0, // source
				this.theLevelsSizes, 0, // dest
				aDimsCount
			);
		}

		// to get dimensions count

		public int GetDimensions()
		{
			if (this.theLevelsSizes != null)
				return this.theLevelsSizes.Length;
			// end if
			return (0);
		}

		// mandatory !!

		public void SetDimensions (int aDimsCount)
		{
			// clear !!
			this.Clear();

			this.theLevelsSizes = new int [aDimsCount];
			int i = 0;
			while (i < aDimsCount) {
				this.PrivSetLevelSize (i, 0);
				++i;
			}
		}

		public int Dimensions {
			get { return this.GetDimensions(); }
			set { this.SetDimensions (value); }
		}

		// get dim size

		public int GetDimensionSize (int aDimIndex)
		{
			return this.GetLevelSize (aDimIndex);
		}

		// size - alias

		public int GetDimSize (int aDimIndex)
		{
			return this.GetLevelSize (aDimIndex);
		}

		// range check

		public bool IsDimItemIndexValid (int aDimIndex, int aIndex)
		{
			return VRIntRangeCheck.IsItemIndexValid (aIndex, 0, this.GetDimensionSize(aDimIndex));
		}

		public bool IsDimInsertIndexValid (int aDimIndex, int aIndex)
		{
			return VRIntRangeCheck.IsInsertIndexValid (aIndex, 0, this.GetDimensionSize(aDimIndex));
		}

		public void CheckValidDimItemIndex (int aDimIndex, int aIndex)
		{
			VRIntRangeCheck.CheckValidItemIndex (aIndex, 0, this.GetDimensionSize(aDimIndex));
		}

		public void CheckValidDimInsertIndex (int aDimIndex, int aIndex)
		{
			VRIntRangeCheck.CheckValidInsertIndex(aIndex, 0, this.GetDimensionSize(aDimIndex));
		}

		// more range check

		public bool IsDimItemsRangeValid (int aDimIndex, int aIndex, int aCount)
		{
			return VRIntRangeCheck.IsItemsRangeValid(aIndex, aCount, 0, this.GetDimensionSize(aDimIndex));
		}

		public bool IsDimInsertRangeValid (int aDimIndex, int aIndex, int aCount)
		{
			return VRIntRangeCheck.IsInsertRangeValid(aIndex, aCount, 0, this.GetDimensionSize(aDimIndex));
		}

		public void CheckValidDimItemsRange (int aDimIndex, int aIndex, int aCount)
		{
			VRIntRangeCheck.CheckValidItemsRange (aIndex, aCount, 0, this.GetDimensionSize(aDimIndex));
		}

		public void CheckValidDimInsertRange (int aDimIndex, int aIndex, int aCount)
		{
			VRIntRangeCheck.CheckValidInsertRange (aIndex, aCount, 0, this.GetDimensionSize(aDimIndex));
		}


		// operation times for a dim

		private int ComputeDimOperationTimes (int aDestDimIndex)
		{
			int aOperTimes = (1); // !!!

			int aCurrDimIndex = 0;
			while (aCurrDimIndex < aDestDimIndex) {

				aOperTimes = aOperTimes * this.GetDimSize (aCurrDimIndex);

				++ aCurrDimIndex;
			}

			return aOperTimes;
		}

		// operation size for a dim

		private int ComputeDimOperationSize (int aDestDimIndex)
		{
			if (this.IsDataLevel (aDestDimIndex))

				// data level

				return (1); // !!!

			else {
				// intermediate level

				int aOperSize = (1); // !!!

				int aDimsCount = this.GetDimensions();

				int aCurrDimIndex = aDestDimIndex + 1;

				while (aCurrDimIndex < aDimsCount) {

					aOperSize = aOperSize * this.GetDimSize (aCurrDimIndex);

					++ aCurrDimIndex;
				}

				return aOperSize;
			}

		}

		// compute the total number of items for a level

		private int ComputeLevelTotalItems (int aSrcLevel)
		{
			int aTotalCount = (0); // !!!

			int aLevelsCount = this.GetDimensions();
			if (aLevelsCount > 0) {
				aTotalCount = (1); // !!!
				int aLevel = aSrcLevel;
				while (aLevel < aLevelsCount) {

					aTotalCount = aTotalCount * this.GetDimSize (aLevel);

					++ aLevel;
				}
			}
			return aTotalCount;
		}

		// compute total size

		private int ComputeTotalSize()
		{
			return this.ComputeLevelTotalItems (0); // ( this.GetDimensions() - 1 );
		}

		// compute actual level size

		private int ComputeActualLevelSize (int aSrcLevel)
		{
			int aActualLevelSize = (0); // !!!

			int aLevelsCount = this.GetDimensions();
			if (aLevelsCount > 0) {
				aActualLevelSize = (1); // !!!
				int aLevel = aSrcLevel;
				while (aLevel < aLevelsCount) {

					aActualLevelSize = aActualLevelSize * this.GetDimSize (aLevel);

					++ aLevel;
				}
			}
			return aActualLevelSize;
		}

		// compute level size

		private int ComputeLevelSize (int aSrcLevel)
		{
			return this.ComputeActualLevelSize (aSrcLevel);
		}

		// check upper levels sizes

		private void CheckUpperLevelSizes (int aStartingDimIndex)
		{
			int aDimIndex = aStartingDimIndex;
			while (aDimIndex >= 0) {
				if (this.GetDimSize (aDimIndex) <= 0)
					// raise !!
					throw new Exception ("level (" + aDimIndex + ") is empty");
				// ok
				-- aDimIndex;
			}
			// ok
		}


		// size

		public int GetSize()
		{
			return this.ComputeTotalSize();
		}

		public int Size { get { return this.GetSize(); } }

		// sub size

		public int GetSubSize (int aLevel)
		{
			return this.ComputeLevelSize (aLevel);
		}

		// range check

		public bool IsItemIndexValid (int aIndex)
		{
			return VRIntRangeCheck.IsItemIndexValid (aIndex, 0, this.Size);
		}

		public void CheckValidItemIndex (int aIndex)
		{
			VRIntRangeCheck.CheckValidItemIndex (aIndex, 0, this.Size);
		}

		public bool IsItemsRangeValid (int aIndex, int aCount)
		{
			return VRIntRangeCheck.IsItemsRangeValid (aIndex, aCount, 0, this.Size);
		}

		public void CheckValidItemsRange (int aIndex, int aCount)
		{
			VRIntRangeCheck.CheckValidItemsRange (aIndex, aCount, 0, this.Size);
		}


		// aIndexes[] -> aIndex

		public int LinearIndexFromIndexes (int[] aIndexes)
		{
			int aLinearIndexResult = 0;

			// (aRowIndex * aColsSize) + aColIndex
			int aDimsCount = this.GetDimensions();

			int aTotalItemsCountBefore = 0;

			int aLevelsCount = aDimsCount - 1;
			int aDimIndex = 0;
			while (aDimIndex < aLevelsCount) {
				int aLocalIndex = aIndexes[aDimIndex];
				// compute cols size at level aDimIndex
				int aSubLevelSize = this.ComputeLevelSize (aDimIndex + 1);
				// count items before
				int aLocalSize = aSubLevelSize * aLocalIndex;
				// count items before
				aTotalItemsCountBefore = aTotalItemsCountBefore + aLocalSize;
				// next
				++ aDimIndex;
			}

			{
				int aLocalIndex = aIndexes[aDimIndex];
				aLinearIndexResult = aTotalItemsCountBefore + aLocalIndex;
			}

			return aLinearIndexResult;
		}

		// aIndex -> aIndexes[]

		public int[] IndexesFromLinearIndex(int aStartingLinearIndex)
		{
			int aDimsCount = this.GetDimensions();

			int[] aIndexesResult = new int[aDimsCount];

			int aRemainingItemsCount = aStartingLinearIndex;

			int aLevelsCount = aDimsCount - 1;
			int aDimIndex = 0;

			while (aDimIndex < aLevelsCount) {

				int aSubLevelSize = this.ComputeLevelSize (aDimIndex + 1);

				int aCurrentLevelIndex = aRemainingItemsCount / aSubLevelSize;

				aIndexesResult[aDimIndex] = aCurrentLevelIndex;

				aRemainingItemsCount = aRemainingItemsCount - (aCurrentLevelIndex * aSubLevelSize);

				++ aDimIndex;
			}

			aIndexesResult[aDimIndex] = aRemainingItemsCount;

			return aIndexesResult;
		}



		// insert
	
		/*/
			- always increase dim size !!
		/*/

		public void Insert (int aDimIndex, int aDimInsIndex)
		{
			// insert range check
			this.CheckValidDimInsertIndex (aDimIndex, aDimInsIndex);

			// check upper levels sizes
			this.CheckUpperLevelSizes (aDimIndex - 1);

			int aInsOperTimes = this.ComputeDimOperationTimes (aDimIndex);

			int aInsOperSize = this.ComputeDimOperationSize (aDimIndex);

			if ( (aInsOperTimes > 0) && (aInsOperSize > 0) ) {

				// compute the total operation size

				int aTotalOperationSize = aInsOperSize * aInsOperTimes;

				// resize the list to make room for [aTotalOperationSize] more items

				// [*] Resize List as needed

				int aOldPhysListSize = this.ListSize;
	
				int aNewPhysListSize = aOldPhysListSize + aTotalOperationSize;
	
				// expand list
				this.ExpandListAsNeeded (aNewPhysListSize);
				// ok

				// compute the local index
	
				int aLocalLevelSize;
	
				int aLocalInsIndex;
	
				if (this.IsDataLevel (aDimIndex)) {
	
					// insert at data level
	
					aLocalLevelSize = this.GetDimSize (aDimIndex);

					aLocalInsIndex = aDimInsIndex;
	
				} else {
	
					// insert at intermediate level
	
					aLocalLevelSize = this.ComputeActualLevelSize (aDimIndex + 1);

					aLocalInsIndex = aDimInsIndex * aLocalLevelSize;
	
				} // end if
	
				int aVirtTotalSize = this.ComputeTotalSize();

				// compute the starting physical insert index into the list
	
				int aStartingPhysIndex;
	
				int aTotalLevelSize = this.ComputeActualLevelSize (aDimIndex);

				if (aLocalInsIndex >= aTotalLevelSize)
	
					// we are adding at end
	
					aStartingPhysIndex = aVirtTotalSize;
	
				else
	
					// we are adding at [0 .. (aLocalLevelSize - 1)]
	
					// aStartingPhysIndex = aVirtTotalSize - aLocalLevelSize + aLocalInsIndex;
					aStartingPhysIndex = aVirtTotalSize - aTotalLevelSize + aLocalInsIndex;

				// end if
	
				// move items ...

				int aMoveHighPartSize = aTotalLevelSize - aLocalInsIndex;

				int aMoveLowPartSize = aLocalInsIndex;
	
				// repeat (n) times ...

				int aPhysIndexOffset = aInsOperSize * this.GetDimSize (aDimIndex);
	
				int aCurrentMoveDistance = aTotalOperationSize;
	
				int aSourcePhysIndex = aStartingPhysIndex;
	
				int aTimesToRepeat = aInsOperTimes;
	
				while (aTimesToRepeat > 0) {
	
					// compute the move dest index
	
					// also determine the move size
	
					int aMoveSize;
					
					int aSrcPhIndex;
	
					int aDestPhysIndex;
					
					if (aStartingPhysIndex >= aVirtTotalSize) {
						
						// we are adding at end
						
						aSrcPhIndex = aSourcePhysIndex - aMoveLowPartSize;
	
						aDestPhysIndex = aSrcPhIndex + aCurrentMoveDistance - aInsOperSize;
						
						if (aSrcPhIndex <= 0)
							
							aMoveSize = 0;
						
						else
							
							aMoveSize = aMoveLowPartSize;
						
					} else {
						
						// inserting
						
						aSrcPhIndex = aSourcePhysIndex;
						
						aDestPhysIndex = aSourcePhysIndex + aCurrentMoveDistance;

						bool aIsOutOfHighBound =
							(aSourcePhysIndex + aMoveLowPartSize + aMoveHighPartSize) >= aVirtTotalSize;
	
						if (aIsOutOfHighBound)
							
							aMoveSize = aMoveHighPartSize;
						
						else
							
							aMoveSize = aMoveLowPartSize + aMoveHighPartSize;
					}
	
					// move right items into the list

					this.MoveListItemsRight (
						aDestPhysIndex, // dest index
						aSrcPhIndex, // source index
						aMoveSize // count
					);
	
					// step done
	
					// next step
	
					aSourcePhysIndex = aSourcePhysIndex - aPhysIndexOffset;
	
					aCurrentMoveDistance = aCurrentMoveDistance - aInsOperSize;
	
					-- aTimesToRepeat;
	
				} // repeat
	
			} // if

			// always increase dim size !!

			this.PrivSetLevelSize (aDimIndex, this.GetDimSize (aDimIndex) + 1);

			// fill newly inserted items with a default value
	
			if ( (aInsOperTimes > 0) && (aInsOperSize > 0) ) {
	
				int aLocalLevelSize;
	
				int aLocalFillIndex;
	
				if (this.IsDataLevel (aDimIndex)) {

					// fill at data level
	
					aLocalLevelSize = this.GetDimSize (aDimIndex);

					aLocalFillIndex = aDimInsIndex;
	
				} else {
	
					// fill at intermediate level
	
					aLocalLevelSize = this.ComputeActualLevelSize (aDimIndex + 1);

					aLocalFillIndex = aDimInsIndex * aLocalLevelSize;
	
				} // end if
	
				int aStartingFillPhysIndex = aLocalFillIndex;
	
				int aDestFillPhysIndex = aStartingFillPhysIndex;
	
				int aFillPhysOffset = this.ComputeActualLevelSize (aDimIndex);
	
				int aTimesToRepeat = aInsOperTimes;
	
				while (aTimesToRepeat > 0) {
	
					// fill range with a default value

					this.FillListRangeWithDefaultValue (
						aDestFillPhysIndex, // fill index
						aInsOperSize // fill count
					);
	
					// next
	
					aDestFillPhysIndex = aDestFillPhysIndex + aFillPhysOffset;
	
					-- aTimesToRepeat;
	
				} // repeat
	
			}
	
			// done
		}


		// delete
	
		/*/
			- always decrease dim size !!
		/*/

		public void Delete (int aDimIndex, int aDimDelIndex)
		{
			// delete item range check
			this.CheckValidDimItemIndex (aDimIndex, aDimDelIndex);

			// check upper levels sizes
			this.CheckUpperLevelSizes (aDimIndex - 1);

			int aDelOperTimes = this.ComputeDimOperationTimes (aDimIndex);

			int aDelOperSize = this.ComputeDimOperationSize (aDimIndex);

			if ( (aDelOperTimes > 0) && (aDelOperSize > 0) ) {

				// compute the local index

				int aLocalLevelSize;

				int aLocalDelIndex;

				if (this.IsDataLevel (aDimIndex)) {
	
					// delete at data level
	
					aLocalLevelSize = this.GetDimSize (aDimIndex);

					aLocalDelIndex = aDimDelIndex;
	
				} else {
	
					// delete at intermediate level
	
					aLocalLevelSize = this.ComputeActualLevelSize (aDimIndex + 1);
	
					aLocalDelIndex = aDimDelIndex * aLocalLevelSize;

				} // end if
	
				int aVirtTotalSize = this.ComputeTotalSize();

				// compute the starting physical delete index into the list
	
				int aStartingPhysIndex = aLocalDelIndex + aDelOperSize;
	
				int aTotalLevelSize = this.ComputeActualLevelSize (aDimIndex);

				// move items ...

				int aMoveHighPartSize = aTotalLevelSize - (aLocalDelIndex + aDelOperSize);

				int aMoveLowPartSize = aLocalDelIndex;
	
				// repeat (n) times ...
	
				int aPhysIndexOffset = aDelOperSize * this.GetDimSize (aDimIndex);

				int aCurrentMoveDistance = aDelOperSize;
	
				int aSourcePhysIndex = aStartingPhysIndex;
	
				int aTimesToRepeat = aDelOperTimes;
	
				while (aTimesToRepeat > 0) {
	
					// compute the move dest index

					int aDestPhysIndex = aSourcePhysIndex - aCurrentMoveDistance;
	
					// determine the move size
	
					int aMoveSize;
	
					if (aSourcePhysIndex >= (aVirtTotalSize))
	
						aMoveSize = (0);
	
					else if ( (aSourcePhysIndex + aMoveHighPartSize) >= (aVirtTotalSize) )
	
						aMoveSize = aMoveHighPartSize;
	
					else
	
						aMoveSize = aMoveLowPartSize + aMoveHighPartSize;
	
					// end if
	
					// move left items into the list

					this.MoveListItemsLeft (
						aDestPhysIndex, // dest index
						aSourcePhysIndex, // source index
						aMoveSize // count
					);
	
					// step done
	
					// next step
	
					aSourcePhysIndex = aSourcePhysIndex + aPhysIndexOffset;
	
					aCurrentMoveDistance = aCurrentMoveDistance + aDelOperSize;
	
					-- aTimesToRepeat;
	
				} // repeat
	
				// [*] Resize List as needed
	
				// compute the total operation size

				int aTotalOperationSize = aDelOperSize * aDelOperTimes;

				// local aOldPhysListSize = this.ListSize
	
				// remove (aTotalOperationSize) items from list starting from (aVirtTotalSize - aTotalOperationSize)

				this.DeleteItemsRangeFromList (
					aVirtTotalSize - aTotalOperationSize, // index
					aTotalOperationSize // count
				);

				// done

			} // if

			// always decrease dim size !!

			this.PrivSetLevelSize (aDimIndex, this.GetDimSize (aDimIndex) - 1);

			// set also upper dims to (0) if it is (0) !!
			if (this.GetDimSize (aDimIndex) <= 0) {
				int aLimit = this.GetDimensions();
				int aLevelIndex = aDimIndex + 1;
				while (aLevelIndex < aLimit) {
					this.PrivSetLevelSize (aLevelIndex, 0);
					++ aLevelIndex;
				}
			}

			// done
		}



		// clear

		public void Clear()
		{
			if (this.GetDimensions() > 0)
				// clear
				while (this.GetDimSize(0) > 0)
					// delete
					this.Delete (
						0, // root dim
						0 // first index
					);
				// repeat
			// end if
		}


		// add

		public void Add (int aDimIndex)
		{
			int aInsIndex = this.GetDimSize (aDimIndex);
			this.Insert (aDimIndex, aInsIndex);
		}

		// clear dim

		public void ClearDim (int aDimIndex)
		{
			while (this.GetDimSize(aDimIndex) > 0)
				this.Delete (aDimIndex, 0);
			// repeat
		}

		// delete count

		public void Delete (int aDimIndex, int aDelIndex, int aDelCount)
		{
			// range check
			this.CheckValidDimInsertRange (aDimIndex, aDelIndex, aDelCount);
			// ok
			int aCount = aDelCount;
			while (aCount > 0) {
				this.Delete (aDimIndex, aDelIndex);
				-- aCount;
			}
		}

		// insert count

		public void Insert (int aDimIndex, int aInsIndex, int aInsCount)
		{
			// range check
			this.CheckValidDimInsertIndex (aDimIndex, aInsIndex);
			// ok
			int aInsertedCount = 0;
			try {
				int aCount = aInsCount;
				while (aCount > 0) {
					this.Insert (aDimIndex, aInsIndex);
					++ aInsertedCount;
					-- aCount;
				}
				// ok
			}
			catch (Exception) {
				// on except
				// rollback
				this.Delete (aDimIndex, aInsIndex, aInsertedCount);
				// raise again
				throw;
			}
		}

		// add at end

		public void AddAtEnd (int aDimIndex, int aAddCount)
		{
			int aAddIndex = this.GetDimSize (aDimIndex);
			this.Insert (aDimIndex, aAddIndex, aAddCount);
		}

		// delete from end

		public void DeleteFromEnd (int aDimIndex, int aDelCount)
		{
			int aDimSize = this.GetDimSize(aDimIndex);
			int aDelIndex = aDimSize - aDelCount;
			this.Delete (aDimIndex, aDelIndex, aDelCount);
		}

		// set a dim size

		public void SetDimensionSize (int aDimIndex, int aDimSize)
		{
			this.ClearDim (aDimIndex);
			this.AddAtEnd (aDimIndex, aDimSize);
		}

		// get dims sizes

		public int[] GetDimensionsSizes()
		{
			int aDimsCount = this.GetDimensions();
			int[] aDimsArrayResult = new int[aDimsCount];
			int aDimIndex = 0;
			while (aDimIndex < aDimsCount) {
				int aDimSize = this.GetDimSize(aDimIndex);
				aDimsArrayResult[aDimIndex] = aDimSize;
				++ aDimIndex;
			}
			return aDimsArrayResult;
		}

		// set dims sizes

		public void SetDimensionsSizes (int[] aDimsSizes)
		{
			this.Clear();

			int aDimsCount = aDimsSizes.Length;

			// set new dimensions
			this.SetDimensions (aDimsCount);

			int aDimIndex = 0;
			while (aDimIndex < aDimsCount) {

				int aDimSize = aDimsSizes[aDimIndex];

				this.SetDimensionSize (aDimIndex, aDimSize);

				++ aDimIndex;
			}
			// ok
		}

		// dims sizes property

		public int[] DimensionsSizes
		{
			get { return this.GetDimensionsSizes(); }
			set { this.SetDimensionsSizes (value); }
		}

		// resize dim

		public void ResizeDim (int aDimIndex, int aNewDimSize)
		{
			int aOldDimSize = this.GetDimSize(aDimIndex);
			int aDiffSize = aNewDimSize - aOldDimSize;
			if (aDiffSize > 0)
				this.AddAtEnd (aDimIndex, aDiffSize);
			else if (aDiffSize < 0)
				this.DeleteFromEnd (aDimIndex, - aDiffSize);
			// end if
		}


		// item access

		// get item at index

		public T GetItem (int aIndex)
		{
			this.CheckValidItemIndex (aIndex);
			return this.GetListValue (aIndex);
		}

		// set item at index

		public void SetItem (int aIndex, T aValue)
		{
			this.CheckValidItemIndex (aIndex);
			this.SetListValue (aIndex, aValue);
		}

		// operator [index]

		public T this [int aIndex]
		{
			get {
				return this.GetItem (aIndex);
			}
			set {
				this.SetItem (aIndex, value);
			}
		}


		// get item

		public T GetItem (int[] aIndexes)
		{
			int aIndex = this.LinearIndexFromIndexes (aIndexes);
			return this.GetItem (aIndex);
		}

		// set item

		public void SetItem (int[] aIndexes, T aValue)
		{
			int aIndex = this.LinearIndexFromIndexes (aIndexes);
			this.SetItem (aIndex, aValue);
		}

		// done

		// Sub View

		public class SubView {

			// instance data

			private VRMDArrayListMgr<T> theMDArray = null;

			private int[] theMasterIndexes = null;

			// init

			public SubView() {}

			// accessors

			public VRMDArrayListMgr<T> GetMDArray() { return this.theMDArray; }

			public void SetMDArray (VRMDArrayListMgr<T> aMDArray) { this.theMDArray = aMDArray; }

			public VRMDArrayListMgr<T> MDArray {
				get { return this.GetMDArray();  }
				set { this.SetMDArray (value);  }
			}

			// master dims count

			public int GetMasterDimsCount() { return this.theMasterIndexes.Length;  }

			public void SetMasterDimsCount (int aCount) { this.theMasterIndexes = new int [aCount]; }

			public int MasterDimsCount {
				get { return this.GetMasterDimsCount(); }
				set { this.SetMasterDimsCount (value); }
			}

			// range check

			public bool IsMasterDimIndexValid (int aDimIndex)
			{
				return VRIntRangeCheck.IsItemIndexValid (aDimIndex, 0, this.MasterDimsCount);
			}

			public void CheckValidMasterDimIndex (int aDimIndex)
			{
				VRIntRangeCheck.CheckValidItemIndex (aDimIndex, 0, this.MasterDimsCount);
			}

			// master dim index

			public int GetMasterDimIndex (int aDimIndex)
			{
				return this.theMasterIndexes [aDimIndex];
			}

			public void SetMasterDimIndex (int aDimIndex, int aIndex)
			{
				this.theMasterIndexes [aDimIndex] = aIndex;
			}

			// master indexes

			public int[] GetMasterIndexes()
			{
				int aCount = this.MasterDimsCount;
				int[] aMasterIndexes = new int [aCount];
				// copy: this.theMasterIndexes --> aMasterIndexes
				Array.Copy (this.theMasterIndexes, 0, aMasterIndexes, 0, aCount);
				return aMasterIndexes;
			}

			public void SetMasterIndexes (int[] aIndexes)
			{
				int aCount = aIndexes.Length;
				this.MasterDimsCount = aCount;
				// copy: aIndexes --> this.theMasterIndexes
				Array.Copy (aIndexes, 0, this.theMasterIndexes, 0, aCount);
			}

			public int[] MasterIndexes {
				get { return this.GetMasterIndexes(); }
				set { this.SetMasterIndexes(value); }
			}

			// dimensions

			public int GetDimensions()
			{
				return this.MDArray.Dimensions - this.MasterDimsCount;
			}

			public int Dimensions { get { return this.GetDimensions(); } }

			// dimension size

			public int GetDimensionSize (int aSubDimIndex)
			{
				return this.MDArray.GetDimensionSize (aSubDimIndex + this.MasterDimsCount);
			}

			// range check

			public bool IsDimItemIndexValid (int aSubDimIndex, int aIndex)
			{
				return VRIntRangeCheck.IsItemIndexValid (aIndex, 0, this.GetDimensionSize(aSubDimIndex));
			}

			public void CheckValidDimItemIndex (int aSubDimIndex, int aIndex)
			{
				VRIntRangeCheck.CheckValidItemIndex (aIndex, 0, this.GetDimensionSize(aSubDimIndex));
			}

			public bool IsDimItemsRangeValid (int aSubDimIndex, int aIndex, int aCount)
			{
				return VRIntRangeCheck.IsItemsRangeValid (aIndex, aCount, 0, this.GetDimensionSize(aSubDimIndex));
			}

			public void CheckValidDimItemsRange (int aSubDimIndex, int aIndex, int aCount)
			{
				VRIntRangeCheck.CheckValidItemsRange (aIndex, aCount, 0, this.GetDimensionSize(aSubDimIndex));
			}

			// dimensions sizes

			public int[] GetDimensionsSizes()
			{
				int[] aSubDimsSizes = new int [this.Dimensions];
				Array.Copy (
					this.MDArray.GetDimensionsSizes(), this.MasterDimsCount, // source
					aSubDimsSizes, 0, // dest
					this.Dimensions
				);
				return aSubDimsSizes;
			}

			public int[] DimensionsSizes { get { return this.GetDimensionsSizes(); } }


			// size

			public int GetSize()
			{
				return this.MDArray.GetSubSize (this.MasterDimsCount);
			}

			public int Size { get { return this.GetSize();  } }

			// sub size

			public int GetSubSize (int aLevel)
			{
				return this.MDArray.GetSubSize (this.MasterDimsCount + aLevel);
			}

			// range check

			public bool IsItemIndexValid (int aIndex)
			{
				return VRIntRangeCheck.IsItemIndexValid (aIndex, 0, this.Size);
			}

			public void CheckValidItemIndex (int aIndex)
			{
				VRIntRangeCheck.CheckValidItemIndex (aIndex, 0, this.Size);
			}

			public bool IsItemsRangeValid (int aIndex, int aCount)
			{
				return VRIntRangeCheck.IsItemsRangeValid (aIndex, aCount, 0, this.Size);
			}
	
			public void CheckValidItemsRange (int aIndex, int aCount)
			{
				VRIntRangeCheck.CheckValidItemsRange (aIndex, aCount, 0, this.Size);
			}


			// item access

			// item at [indexes]

			public T GetItem (int[] aSubIndexes)
			{
				int[] aTotalIndexes = VRIntArrayUtils.Concat (
					this.theMasterIndexes, aSubIndexes
				);
				// get item
				return this.MDArray.GetItem (aTotalIndexes);
			}

			public void SetItem (int[] aSubIndexes, T aValue)
			{
				int[] aTotalIndexes = VRIntArrayUtils.Concat (
					this.theMasterIndexes, aSubIndexes
				);
				// set item
				this.MDArray.SetItem (aTotalIndexes, aValue);
			}


			// item at index

			// compute the starting linear index

			public int ComputeStartingLinearIndex()
			{
				int aMDArrayDimsCount = this.MDArray.Dimensions;

				int[] aStartingIndexes = new int [aMDArrayDimsCount];

				// copy master indexes
				Array.Copy (
					this.theMasterIndexes, 0, // source
					aStartingIndexes, 0, // dest
					this.MasterDimsCount // count
				);
				// set to (0) the rest
				VRIntArrayUtils.Fill (
					aStartingIndexes,
					this.MasterDimsCount, // index
					this.Dimensions, // count
					0 // zero value
				);

				return this.MDArray.LinearIndexFromIndexes (aStartingIndexes);
			}

			// item at index

			public T GetItem (int aSubLinearIndex)
			{
				return this.MDArray.GetItem (this.ComputeStartingLinearIndex() + aSubLinearIndex);
			}

			public void SetItem (int aSubLinearIndex, T aValue)
			{
				this.MDArray.SetItem (this.ComputeStartingLinearIndex() + aSubLinearIndex, aValue);
			}

			// operator [index]

			public T this [int aIndex] {
				get { return this.GetItem (aIndex); }
				set { this.SetItem (aIndex, value); }
			}


			// aIndexes[] -> aIndex

			public int LinearIndexFromIndexes (int[] aSubIndexes)
			{
				// build entire indexes path
				int[] aTotalIndexes = VRIntArrayUtils.Concat (
					this.theMasterIndexes, aSubIndexes
				);
				// global linear index from indexes
				int aGlobalIndex = this.MDArray.LinearIndexFromIndexes (aTotalIndexes);
				// subtract the starting linear index
				int aIndexResult = aGlobalIndex - this.ComputeStartingLinearIndex();
				return aIndexResult;
			}

			// aIndex -> aIndexes[]

			public int[] IndexesFromLinearIndex (int aStartingSubLinearIndex)
			{
				int aGlobalIndex = aStartingSubLinearIndex + this.ComputeStartingLinearIndex();

				int[] aTotalIndexes = this.MDArray.IndexesFromLinearIndex (aGlobalIndex);

				// create sub indexes array result
				int[] aSubIndexesResult = new int [this.Dimensions];

				// copy sub indexes only
				Array.Copy (
					aTotalIndexes, this.MasterDimsCount, // source
					aSubIndexesResult, 0, // dest
					this.Dimensions
				);
				return aSubIndexesResult;
			}


		} // SubView


	} // class


} // namespace