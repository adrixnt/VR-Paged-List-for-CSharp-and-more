using System;

using System.Runtime.Serialization;

//using System.Collections.Generic;
using System.Collections;

using VRAdrixNT.Utils.RangeCheck;

using VRAdrixNT.BasicUtils.IntArray;

namespace VRAdrixNT.GenericMultiDimArray
{

	public interface /*/ abstract class /*/ IVRMDArrayAbstNewDefaultValueProvider<T>
	{
		// public VRMDArrayAbstNewDefaultValueProvider() {}

		/*/public abstract/*/ T GetNewDefaultValue();
	}

	// Multi Dim Array <T>

	[Serializable]
	public class VRMultiDimArray<T> : ICloneable, ISerializable
	{

		public class SubView {

			// instance data

			private VRMultiDimArray<T> theMDArray = null;

			private int[] theMasterIndexes = null;

			// init

			public SubView() {}

			// accessors

			public VRMultiDimArray<T> GetMDArray() { return this.theMDArray; }

			public void SetMDArray (VRMultiDimArray<T> aMDArray) { this.theMDArray = aMDArray; }

			public VRMultiDimArray<T> MDArray {
				get { return this.GetMDArray();  }
				set { this.SetMDArray (value);  }
			}

			// master dims count

			public int GetMasterDimsCount() { return this.theMasterIndexes.Length;  }

			public void SetMasterDimsCount (int aCount) { this.theMasterIndexes = new int [aCount]; }

			public int MasterDimsCount {
				get { return this.GetMasterDimsCount(); }
				set { this.SetMasterDimsCount (value); }
			}

			// range check

			public bool IsMasterDimIndexValid (int aDimIndex)
			{
				return VRIntRangeCheck.IsItemIndexValid (aDimIndex, 0, this.MasterDimsCount);
			}

			public void CheckValidMasterDimIndex (int aDimIndex)
			{
				VRIntRangeCheck.CheckValidItemIndex (aDimIndex, 0, this.MasterDimsCount);
			}

			// master dim index

			public int GetMasterDimIndex (int aDimIndex)
			{
				return this.theMasterIndexes [aDimIndex];
			}

			public void SetMasterDimIndex (int aDimIndex, int aIndex)
			{
				this.theMasterIndexes [aDimIndex] = aIndex;
			}

			// master indexes

			public int[] GetMasterIndexes()
			{
				int aCount = this.MasterDimsCount;
				int[] aMasterIndexes = new int [aCount];
				// copy: this.theMasterIndexes --> aMasterIndexes
				Array.Copy (this.theMasterIndexes, 0, aMasterIndexes, 0, aCount);
				return aMasterIndexes;
			}

			public void SetMasterIndexes (int[] aIndexes)
			{
				int aCount = aIndexes.Length;
				this.MasterDimsCount = aCount;
				// copy: aIndexes --> this.theMasterIndexes
				Array.Copy (aIndexes, 0, this.theMasterIndexes, 0, aCount);
			}

			public int[] MasterIndexes {
				get { return this.GetMasterIndexes(); }
				set { this.SetMasterIndexes(value); }
			}

			// dimensions

			public int GetDimensions()
			{
				return this.MDArray.Dimensions - this.MasterDimsCount;
			}

			public int Dimensions { get { return this.GetDimensions(); } }

			// dimension size

			public int GetDimensionSize (int aSubDimIndex)
			{
				return this.MDArray.GetDimensionSize (aSubDimIndex + this.MasterDimsCount);
			}

			// range check

			public bool IsDimItemIndexValid (int aSubDimIndex, int aIndex)
			{
				return VRIntRangeCheck.IsItemIndexValid (aIndex, 0, this.GetDimensionSize(aSubDimIndex));
			}

			public void CheckValidDimItemIndex (int aSubDimIndex, int aIndex)
			{
				VRIntRangeCheck.CheckValidItemIndex (aIndex, 0, this.GetDimensionSize(aSubDimIndex));
			}

			public bool IsDimItemsRangeValid (int aSubDimIndex, int aIndex, int aCount)
			{
				return VRIntRangeCheck.IsItemsRangeValid (aIndex, aCount, 0, this.GetDimensionSize(aSubDimIndex));
			}

			public void CheckValidDimItemsRange (int aSubDimIndex, int aIndex, int aCount)
			{
				VRIntRangeCheck.CheckValidItemsRange (aIndex, aCount, 0, this.GetDimensionSize(aSubDimIndex));
			}

			// dimensions sizes

			public int[] GetDimensionsSizes()
			{
				int[] aSubDimsSizes = new int [this.Dimensions];
				Array.Copy (
					this.MDArray.GetDimensionsSizes(), this.MasterDimsCount, // source
					aSubDimsSizes, 0, // dest
					this.Dimensions
				);
				return aSubDimsSizes;
			}

			public int[] DimensionsSizes { get { return this.GetDimensionsSizes(); } }

			// size

			public int GetSize()
			{
				return this.MDArray.GetSubSize (this.MasterDimsCount);
			}

			public int Size { get { return this.GetSize();  } }

			// sub size

			public int GetSubSize (int aLevel)
			{
				return this.MDArray.GetSubSize (this.MasterDimsCount + aLevel);
			}

			// range check

			public bool IsItemIndexValid (int aIndex)
			{
				return VRIntRangeCheck.IsItemIndexValid (aIndex, 0, this.Size);
			}
	
			public void CheckValidItemIndex (int aIndex)
			{
				VRIntRangeCheck.CheckValidItemIndex (aIndex, 0, this.Size);
			}
	
			public bool IsItemsRangeValid (int aIndex, int aCount)
			{
				return VRIntRangeCheck.IsItemsRangeValid (aIndex, aCount, 0, this.Size);
			}
	
			public void CheckValidItemsRange (int aIndex, int aCount)
			{
				VRIntRangeCheck.CheckValidItemsRange (aIndex, aCount, 0, this.Size);
			}


			// item access

			// item at [indexes]

			public T GetItem (int[] aSubIndexes)
			{
				int[] aTotalIndexes = VRIntArrayUtils.Concat (
					this.theMasterIndexes, aSubIndexes
				);
				// get item
				return this.MDArray.GetItem (aTotalIndexes);
			}

			public void SetItem (int[] aSubIndexes, T aValue)
			{
				int[] aTotalIndexes = VRIntArrayUtils.Concat (
					this.theMasterIndexes, aSubIndexes
				);
				// set item
				this.MDArray.SetItem (aTotalIndexes, aValue);
			}

			// item at index

			// compute the starting linear index

			public int ComputeStartingLinearIndex()
			{
				int aMDArrayDimsCount = this.MDArray.Dimensions;

				int[] aStartingIndexes = new int [aMDArrayDimsCount];

				// copy master indexes
				Array.Copy (
					this.theMasterIndexes, 0, // source
					aStartingIndexes, 0, // dest
					this.MasterDimsCount // count
				);
				// set to (0) the rest
				VRIntArrayUtils.Fill (
					aStartingIndexes,
					this.MasterDimsCount, // index
					this.Dimensions, // count
					0 // zero value
				);

				return this.MDArray.LinearIndexFromIndexes (aStartingIndexes);
			}

			// item at index

			public T GetItem (int aSubLinearIndex)
			{
				return this.MDArray.GetItem (this.ComputeStartingLinearIndex() + aSubLinearIndex);
			}

			public void SetItem (int aSubLinearIndex, T aValue)
			{
				this.MDArray.SetItem (this.ComputeStartingLinearIndex() + aSubLinearIndex, aValue);
			}

			// operator [index]

			public T this [int aIndex] {
				get { return this.GetItem (aIndex); }
				set { this.SetItem (aIndex, value); }
			}

			// aIndexes[] -> aIndex

			public int LinearIndexFromIndexes (int[] aSubIndexes)
			{
				// build entire indexes path
				int[] aTotalIndexes = VRIntArrayUtils.Concat (
					this.theMasterIndexes, aSubIndexes
				);
				// global linear index from indexes
				int aGlobalIndex = this.MDArray.LinearIndexFromIndexes (aTotalIndexes);
				// subtract the starting linear index
				int aIndexResult = aGlobalIndex - this.ComputeStartingLinearIndex();
				return aIndexResult;
			}

			// aIndex -> aIndexes[]

			public int[] IndexesFromLinearIndex (int aStartingSubLinearIndex)
			{
				int aGlobalIndex = aStartingSubLinearIndex + this.ComputeStartingLinearIndex();

				int[] aTotalIndexes = this.MDArray.IndexesFromLinearIndex (aGlobalIndex);

				// create sub indexes array result
				int[] aSubIndexesResult = new int [this.Dimensions];

				// copy sub indexes only
				Array.Copy (
					aTotalIndexes, this.MasterDimsCount, // source
					aSubIndexesResult, 0, // dest
					this.Dimensions
				);
				return aSubIndexesResult;
			}


		} // SubView

		// clone

		public object Clone()
		{
			VRMultiDimArray<T> that = new VRMultiDimArray<T>();

			that.DefaultValue = this.DefaultValue;

			that.NewDefaultValueProvider = this.NewDefaultValueProvider;

			int[] aDimSizes = this.GetDimensionsSizes();

			that.SetDimensionsSizes (aDimSizes);

			// copy data items from this to that
			int aCount = this.Size;
			int aIndex = 0;
			while (aIndex < aCount) {
				that[aIndex] = this[aIndex];
				++ aIndex;
			}
			return that;
		}

		// serialization / deserialization

		private void SerializeDataItems (SerializationInfo info)
		{
			int aSize = this.Size;
			info.AddValue ("Size", aSize);
			int i = 0;
			while (i < aSize) {
				// get value
				T aValue = this[i];
				info.AddValue ("Value[" + i + "]", aValue, aValue.GetType());
				++ i;
			}
		}

		private void DeserializeDataItems(SerializationInfo info)
		{
			int aSize = info.GetInt32("Size");
			int i = 0;
			while (i < aSize) {
				// get value
				T aValue = (T) info.GetValue ("Value[" + i + "]", typeof(T));
				this[i] = aValue;
				++ i;
			}
		}

		// serialization

		public void GetObjectData (SerializationInfo info, StreamingContext context)
		{
			info.AddValue ("DefaultValue", this.DefaultValue, typeof(T));

			info.AddValue ("NewDefaultValueProvider", this.NewDefaultValueProvider);

			int[] aDimSizes = this.GetDimensionsSizes();
			info.AddValue ("DimSizes", aDimSizes);

			this.SerializeDataItems (info);
		}

		// deserialization

		public VRMultiDimArray (SerializationInfo info, StreamingContext context)
		{
			this.DefaultValue = (T) info.GetValue ("DefaultValue", typeof(T));

			this.NewDefaultValueProvider = (IVRMDArrayAbstNewDefaultValueProvider<T>)
				info.GetValue("NewDefaultValueProvider", typeof(IVRMDArrayAbstNewDefaultValueProvider<T>));

			int[] aDimSizes = (int[]) info.GetValue("DimSizes", typeof(int[]));
			this.SetDimensionsSizes(aDimSizes);

			this.DeserializeDataItems (info);
		}



		// the default value

		private T theDefaultValue;

		public T DefaultValue {
			get { return this.theDefaultValue; }
			set { this.theDefaultValue = value; }
		}

		// the default value provider

		private IVRMDArrayAbstNewDefaultValueProvider<T> theNewDefaultValueProvider = null;

		public IVRMDArrayAbstNewDefaultValueProvider<T> NewDefaultValueProvider
		{
			get { return this.theNewDefaultValueProvider; }
			set { this.theNewDefaultValueProvider = value; }
		}

		// get new default value

		private T GetNewDefaultValue()
		{
			IVRMDArrayAbstNewDefaultValueProvider<T> aProvider = this.NewDefaultValueProvider;
			if (aProvider != null)
				return aProvider.GetNewDefaultValue();
			// end if
			return this.DefaultValue;
		}

		// level sizes

		private int[] theLevelsSizes = null;

		private int MaxLevel {
			get { return this.GetDimensions() - 1; } // { return this.theLevelsSizes.Length - 1; }
		}

		private int DataLevel {
			get { return this.MaxLevel; }
		}

		private bool IsDataLevel (int aLevel)
		{
			return (aLevel == this.DataLevel);
		}

		private void PrivSetLevelSize (int aLevel, int aSize)
		{
			this.theLevelsSizes[aLevel] = aSize;
		}

		private int GetLevelSize (int aLevel)
		{
			return this.theLevelsSizes[aLevel];
		}

		// to get dimensions count

		public int GetDimensions()
		{
			if (this.theLevelsSizes != null)
				return this.theLevelsSizes.Length;
			// end if
			return (0);
		}

		// mandatory !!

		public void SetDimensions (int aDimsCount)
		{
			// clear !!
			this.Clear();

			if (aDimsCount > 0) { 
				this.theLevelsSizes = new int [aDimsCount];
				int i = 0;
				while (i < aDimsCount) {
					this.PrivSetLevelSize (i, 0);
					++i;
				}
			}
		}

		public int Dimensions {
			get { return this.GetDimensions(); }
			set { this.SetDimensions (value); }
		}

		// get dim size

		public int GetDimensionSize (int aDimIndex)
		{
			return this.GetLevelSize (aDimIndex);
		}

		// size - alias

		public int GetDimSize (int aDimIndex)
		{
			return this.GetLevelSize (aDimIndex);
		}

		// the root list

		private object theRootList = null;

		private object RootList {
			get { return this.theRootList; }
			set { this.theRootList = value; }
		}

		// init

		public VRMultiDimArray()
		{

		}

//========================================================================================

		// range check

		public bool IsDimItemIndexValid (int aDimIndex, int aIndex)
		{
			return VRIntRangeCheck.IsItemIndexValid (aIndex, 0, this.GetDimensionSize(aDimIndex));
		}

		public bool IsDimInsertIndexValid (int aDimIndex, int aIndex)
		{
			return VRIntRangeCheck.IsInsertIndexValid (aIndex, 0, this.GetDimensionSize(aDimIndex));
		}

		public void CheckValidDimItemIndex (int aDimIndex, int aIndex)
		{
			VRIntRangeCheck.CheckValidItemIndex (aIndex, 0, this.GetDimensionSize(aDimIndex));
		}

		public void CheckValidDimInsertIndex (int aDimIndex, int aIndex)
		{
			VRIntRangeCheck.CheckValidInsertIndex (aIndex, 0, this.GetDimensionSize(aDimIndex));
		}

		// more range check

		public bool IsDimItemsRangeValid (int aDimIndex, int aIndex, int aCount)
		{
			return VRIntRangeCheck.IsItemsRangeValid (aIndex, aCount, 0, this.GetDimensionSize(aDimIndex));
		}

		public bool IsDimInsertRangeValid (int aDimIndex, int aIndex, int aCount)
		{
			return VRIntRangeCheck.IsInsertRangeValid (aIndex, aCount, 0, this.GetDimensionSize(aDimIndex));
		}

		public void CheckValidDimItemsRange (int aDimIndex, int aIndex, int aCount)
		{
			VRIntRangeCheck.CheckValidItemsRange (aIndex, aCount, 0, this.GetDimensionSize(aDimIndex));
		}

		public void CheckValidDimInsertRange (int aDimIndex, int aIndex, int aCount)
		{
			VRIntRangeCheck.CheckValidInsertRange (aIndex, aCount, 0, this.GetDimensionSize(aDimIndex));
		}


//========================================================================================


		// size -- items count

		public int GetSize()
		{
			int aCountResult = 0;
			int aDimsCount = this.GetDimensions();
			if (aDimsCount > 0) {
				aCountResult = 1; // !!!
				int aDimIndex = 0;
				while (aDimIndex < aDimsCount) {
					int aDimSize = this.GetDimSize (aDimIndex);
					aCountResult = aCountResult * aDimSize;
					++ aDimIndex;
				}
			}
			return aCountResult;
		}

		public int Size { get { return this.GetSize(); } }

		// sub size

		public int GetSubSize (int aLevel)
		{
			return this.ComputeLevelSize (aLevel);
		}

		// range check

		public bool IsItemIndexValid (int aIndex)
		{
			return VRIntRangeCheck.IsItemIndexValid (aIndex, 0, this.Size);
		}

		public void CheckValidItemIndex (int aIndex)
		{
			VRIntRangeCheck.CheckValidItemIndex (aIndex, 0, this.Size);
		}

		public bool IsItemsRangeValid (int aIndex, int aCount)
		{
			return VRIntRangeCheck.IsItemsRangeValid (aIndex, aCount, 0, this.Size);
		}

		public void CheckValidItemsRange (int aIndex, int aCount)
		{
			VRIntRangeCheck.CheckValidItemsRange (aIndex, aCount, 0, this.Size);
		}


		// to compute the size of a level

		private int ComputeLevelSize (int aStartingLevel)
		{
			int aSizeResult = 0;
			int aLevelsCount = this.GetDimensions();
			int aLevel = aStartingLevel;
			int aStartingLevelSize = this.GetDimSize (aStartingLevel);
			if (aStartingLevelSize > 0) {
				aSizeResult = (1);
				while (aLevel < aLevelsCount) {
					int aLevelSize = this.GetDimSize (aLevel);
					aSizeResult = aSizeResult * aLevelSize;
					++ aLevel;
				}
			}
			return aSizeResult;
		}

		// aIndexes[] -> aIndex

		public int LinearIndexFromIndexes (int[] aIndexes)
		{
			int aLinearIndexResult = 0;

			// (aRowIndex * aColsSize) + aColIndex
			int aDimsCount = this.GetDimensions();

			int aTotalItemsCountBefore = 0;

			int aLevelsCount = aDimsCount - 1;
			int aDimIndex = 0;
			while (aDimIndex < aLevelsCount) {
				int aLocalIndex = aIndexes[aDimIndex];
				// compute cols size at level aDimIndex
				int aSubLevelSize = this.ComputeLevelSize (aDimIndex + 1);
				// count items before
				int aLocalSize = aSubLevelSize * aLocalIndex;
				// count items before
				aTotalItemsCountBefore = aTotalItemsCountBefore + aLocalSize;
				// next
				++ aDimIndex;
			}

			{
				int aLocalIndex = aIndexes[aDimIndex];
				aLinearIndexResult = aTotalItemsCountBefore + aLocalIndex;
			}

			return aLinearIndexResult;
		}

		// aIndex -> aIndexes[]

		public int[] IndexesFromLinearIndex(int aStartingLinearIndex)
		{
			int aDimsCount = this.GetDimensions();

			int[] aIndexesResult = new int[aDimsCount];

			int aRemainingItemsCount = aStartingLinearIndex;

			int aLevelsCount = aDimsCount - 1;
			int aDimIndex = 0;

			while (aDimIndex < aLevelsCount) {

				int aSubLevelSize = this.ComputeLevelSize (aDimIndex + 1);

				int aCurrentLevelIndex = aRemainingItemsCount / aSubLevelSize;

				aIndexesResult[aDimIndex] = aCurrentLevelIndex;

				aRemainingItemsCount = aRemainingItemsCount - (aCurrentLevelIndex * aSubLevelSize);

				++ aDimIndex;
			}

			aIndexesResult[aDimIndex] = aRemainingItemsCount;

			return aIndexesResult;
		}

//========================================================================================

		// any list object size

		private int ListObjectSize (int aLevel, object aListObject)
		{
			if (this.IsDataLevel(aLevel)) {
				// return ((List<T>)aListObject).Count;
				return ((ArrayList)aListObject).Count;
			} else {
				//return ((List<object>)aListObject).Count;
				return ((ArrayList)aListObject).Count;
			}
		}

//========================================================================================

		// delete

		// delete item from list at level

		private void DeleteItemFromListAtLevel(
			int aLevel,
			object aListObject,
			int aDelIndex
		)
		{
			if (this.IsDataLevel(aLevel)) {

				// data level

				// List<T> aDataList = (List<T>)aListObject;
				ArrayList aDataList = (ArrayList) aListObject;

				// remove from a data list
				aDataList.RemoveAt(aDelIndex);

				// done

			} else {

				// intermediate level

				int aDownLevel = aLevel + 1;

				// aListObject is an intermediate list
				// List<object> aList = (List<object>)aListObject;
				ArrayList aList = (ArrayList) aListObject;

				// get list to destroy object
				object aListToDestroy = aList[aDelIndex];

				int aCount = this.ListObjectSize (aDownLevel, aListToDestroy);
				while (aCount > 0) {
					// delete item from list at level
					this.DeleteItemFromListAtLevel(
						aDownLevel,
						aListToDestroy,
						(0) // aIndex
					);
					-- aCount;
				}

				// delete sub list from aList
				aList.RemoveAt (aDelIndex);

				// done
			}
		}

		// delete at level

		private void DeleteOldItemAtLevel (
			int aLevel,
			int aCurrLevel,
			object aListObject,
			int aDelIndex
		)
		{
			if (aLevel == aCurrLevel)
				// level found
				// destroy item at (aDelIndex) at level (aCurrLevel) from (aListObject)
				this.DeleteItemFromListAtLevel (aLevel, aListObject, aDelIndex);
				// done
			else {

				// go down a level
				int aDownLevel = aCurrLevel + 1;

				// intermediate list
				// List<object> aList = (List<object>)aListObject;
				ArrayList aList = (ArrayList) aListObject;

				int aCount = aList.Count;
				int aIndex = 0;
				while (aIndex < aCount) {

					object aDownListObject = aList[aIndex];

					this.DeleteOldItemAtLevel(
						aLevel,
						aDownLevel,
						aDownListObject,
						aDelIndex
					);

					++ aIndex;
				}
			}
		}

		// clear sub levels sizes

		private void ClearSubLevelsSizes (int aStartingLevel)
		{
			int aLevelsCount = this.GetDimensions();
			int aLevel = aStartingLevel;
			while (aLevel < aLevelsCount) {
				this.PrivSetLevelSize (aLevel, 0);
				++ aLevel;
			}
		}

		// delete item at level

		private void DeleteItemAtLevel (
			int aLevel,
			int aDelIndex
		)
		{
			// range check
			this.CheckValidDimItemIndex (aLevel, aDelIndex);

			// get the root list object
			object aListObject = this.RootList;

			// delete
			this.DeleteOldItemAtLevel(
				aLevel,
				(0), // curr level
				aListObject,
				aDelIndex
			);

			// adjust level size
			this.PrivSetLevelSize (aLevel, this.GetLevelSize(aLevel) - 1);

			// for precaution clear all sub levels
			int aLevelSize = this.GetLevelSize(aLevel);
			if (aLevelSize == 0)
				this.ClearSubLevelsSizes (aLevel + 1);
			// end if

			// destroy the root list if it is empty
			int aCount = this.ListObjectSize (0, aListObject);
			if (aCount == 0) {
				// this->DestroyListAtLevel(0, aListObject); // aListObject.Free();
				this.RootList = (null);
			}
			// done
		}

//========================================================================================

		// insert

		// build tree of lists for a level

		private object BuildTreeOfListsForLevel (int aLevel)
		{
			object aListObject;

			int aLevelSize = this.GetLevelSize(aLevel);

			if (this.IsDataLevel(aLevel)) {

				// data level

				// List<T> aDataList = new List<T>();
				ArrayList aDataList = new ArrayList();

				int aIndex = 0;
				while (aIndex < aLevelSize) {

					int aInsIndex = aDataList.Count;

					// get default value
					T aDefaultValue = this.GetNewDefaultValue();

					// insert default value
					aDataList.Insert (aInsIndex, aDefaultValue);

					++ aIndex;
				}

				aListObject = aDataList;

				// done

			} else {

				// intermediate level

				// List<object> aList = new List<object>();
				ArrayList aList = new ArrayList();

				int aIndex = 0;
				while (aIndex < aLevelSize) {

					object aSubListObject = this.BuildTreeOfListsForLevel (aLevel + 1);

					aList.Add (aSubListObject);

					++ aIndex;
				}

				aListObject = aList;

				// done
			}

			return aListObject;
		}

		// insert at level

		private void InsertNewItemAtLevel (
			ref int aInsCount,
			int aLevel,
			int aCurrLevel,
			object aListObject,
			int aInsIndex
		) {
			if (aLevel == aCurrLevel) {

				// level found

				if (this.IsDataLevel(aLevel)) {

					// data level

					// insert a default value into aListObject at aInsIndex

					// List<T> aDataList = (List<T>) aListObject;
					ArrayList aDataList = (ArrayList) aListObject;

					// get default value
					T aDefaultValue = this.GetNewDefaultValue();

					aDataList.Insert (aInsIndex, aDefaultValue);

					// done

				} else {

					// intermediate level

					// List<object> aList = (List<object>) aListObject;
					ArrayList aList = (ArrayList) aListObject;

					object aDownListObject = this.BuildTreeOfListsForLevel (aLevel);

					aList.Insert (aInsIndex, aDownListObject);

					// done

				}

				// {@}
				aInsCount = aInsCount + 1;

			} else {

				// go down a level

				int aDownLevel = aCurrLevel + 1;

				// List<object> aList = (List<object>) aListObject;
				ArrayList aList = (ArrayList) aListObject;

				int aCount = aList.Count;
				int aIndex = 0;
				while (aIndex < aCount) {

					object aDownListObject = aList[aIndex];

					this.InsertNewItemAtLevel (
						ref aInsCount, // {@}
						aLevel,
						aDownLevel,
						aDownListObject,
						aInsIndex
					);

					++ aIndex;
				}

			}

		}

		// rollback insertion

		private int RollbackInsertionAtLevel(
			int aInsCount,
			int aLevel,
			int aCurrLevel,
			object aListObject,
			int aInsIndex
		)
		{
			int aRemDelCount = aInsCount;

			if (aInsCount > 0) {

				if (aLevel == aCurrLevel) {

					// level found

					// remove item at aInsIndex from aListObject
					this.DeleteItemFromListAtLevel (aLevel, aListObject, aInsIndex);

					aRemDelCount = aInsCount - 1;

					// done

				} else {

					// go down a level

					int aDownLevel = aCurrLevel + 1;

					// List<object> aList = (List<object>) aListObject;
					ArrayList aList = (ArrayList) aListObject;

					int aCount = aList.Count;
					int aIndex = 0;
					while (aIndex < aCount) {

						object aDownListObject = aList[aIndex];

						aRemDelCount = this.RollbackInsertionAtLevel(
							aInsCount,
							aLevel,
							aDownLevel,
							aDownListObject,
							aInsIndex
						);

						if (aRemDelCount <= 0) break;

						++ aIndex;

					}

				}

			}

			return aRemDelCount;
		}

		// insert

		private void InsertItemAtLevel (
			int aLevel,
			int aInsIndex
		)
		{
			// range check
			this.CheckValidDimInsertIndex (aLevel, aInsIndex);

			bool aNewListObject = false;

			object aListObject = this.RootList;
			if (aListObject == null) {
				// create root list
				if (this.GetDimensions() > 1)
					aListObject = new ArrayList(); // new List<object>();
				else
					aListObject = new ArrayList(); // new List<T>();
				// end if
				aNewListObject = true;
				// set root list
				this.RootList = (aListObject);
			}

			try {
				int aInsCount = 0;
				try {

					// insert at level

					this.InsertNewItemAtLevel(
						ref aInsCount, // {@}
						aLevel,
						(0), // current level
						aListObject,
						aInsIndex
					);

					// resize accordingly
					this.PrivSetLevelSize (aLevel, this.GetLevelSize(aLevel) + 1);
					// done

				}
				catch (Exception aExcept) {
					// on exception
					int aRemDelCount = this.RollbackInsertionAtLevel(
						aInsCount,
						aLevel,
						(0), // current level
						aListObject,
						aInsIndex
					);
					if (aRemDelCount > 0)
						throw new Exception ("error during rollback");
					// end if
					throw;
				}

			}
			catch (Exception aExcept) {
				// on exception
				if (aNewListObject)
					this.RootList = (null);
				// end if
				// raise again
				throw;
			}

			// ok
		}

//========================================================================================

		// get item

		private T GetItemAtIndexesAtLevel (
			int aLevel,
			object aListObject,
			int[] aIndexes,
			int aCurrentIndexLevel
		)
		{
			int aItemIndex = aIndexes[aCurrentIndexLevel];

			if (aLevel == 0) {

				// data level found

				// List<T> aDataList = (List<T>) aListObject;
				ArrayList aDataList = (ArrayList) aListObject;

				T aValueResult = (T) aDataList[aItemIndex];

				return aValueResult;

				// done

			} else {

				// go down a level

				int aDownLevel = aLevel - 1;

				int aLocalCurrentIndexLevel = aCurrentIndexLevel + 1;

				// List<object> aList = (List<object>) aListObject;
				ArrayList aList = (ArrayList) aListObject;

				object aDownListObject = aList[aItemIndex];

				T aValueResult = this.GetItemAtIndexesAtLevel (
					aDownLevel,
					aDownListObject,
					aIndexes,
					aLocalCurrentIndexLevel
				);

				return aValueResult;

			}

		}

		private T GetItemAtIndexes(int[] aIndexes)
		{
			object aListObject = this.RootList;
			int aLevel = this.MaxLevel;
			return this.GetItemAtIndexesAtLevel (
				aLevel,
				aListObject,
				aIndexes,
				(0) // start with the first level index
			);
		}

//========================================================================================

		// set item

		private void SetItemAtIndexesAtLevel (
			int aLevel,
			object aListObject,
			int[] aIndexes,
			int aCurrentIndexLevel,
			T aValue
		) {

			int aItemIndex = aIndexes[aCurrentIndexLevel];

			if (aLevel == 0) {

				// data level found

				// List<T> aDataList = (List<T>) aListObject;
				ArrayList aDataList = (ArrayList) aListObject;

				aDataList[aItemIndex] = aValue;

				// done

			}
			else {

				// go down a level

				int aDownLevel = aLevel - 1;

				int aLocalCurrentIndexLevel = aCurrentIndexLevel + 1;

				// List<object> aList = (List<object>) aListObject;
				ArrayList aList = (ArrayList) aListObject;

				object aDownListObject = aList[aItemIndex];

				this.SetItemAtIndexesAtLevel (
					aDownLevel,
					aDownListObject,
					aIndexes,
					aLocalCurrentIndexLevel,
					aValue
				);

			}

		}

		private void SetItemAtIndexes (int[] aIndexes, T aValue)
		{
			object aListObject = this.RootList;
			int aLevel = this.MaxLevel;
			this.SetItemAtIndexesAtLevel(
				aLevel,
				aListObject,
				aIndexes,
				(0), // start with the first level index
				aValue
			);
		}

//========================================================================================

		// insert

		public void Insert (int aDimIndex, int aInsIndex)
		{
			this.InsertItemAtLevel (aDimIndex, aInsIndex);
		}

		// add

		public void Add (int aDimIndex)
		{
			int aInsIndex = this.GetDimensionSize (aDimIndex);
			this.Insert (aDimIndex, aInsIndex);
		}

		// delete

		public void Delete (int aDimIndex, int aDelIndex)
		{
			this.DeleteItemAtLevel (aDimIndex, aDelIndex);
		}

		// clear dim

		public void ClearDim (int aDimIndex)
		{
			while (this.GetDimensionSize(aDimIndex) > 0)
				this.Delete (aDimIndex, 0);
			// repeat
		}

		// clear

		public void Clear()
		{
			if (this.GetDimensions() > 0) {

				// clear
				while (this.GetDimensionSize(0) > 0)
					this.Delete (0, 0);
				// repeat

				this.theLevelsSizes = null;

			}
		}

		// delete count

		public void Delete (int aDimIndex, int aDelIndex, int aDelCount)
		{
			// range check
			this.CheckValidDimInsertRange (aDimIndex, aDelIndex, aDelCount);
			// ok
			int aCount = aDelCount;
			while (aCount > 0) {
				this.Delete (aDimIndex, aDelIndex);
				-- aCount;
			}
		}

		// insert count

		public void Insert (int aDimIndex, int aInsIndex, int aInsCount)
		{
			// range check
			this.CheckValidDimInsertIndex (aDimIndex, aInsIndex);
			// ok
			int aInsertedCount = 0;
			try {
				int aCount = aInsCount;
				while (aCount > 0) {
					this.Insert (aDimIndex, aInsIndex);
					++ aInsertedCount;
					-- aCount;
				}
				// ok
			}
			catch (Exception) {
				// on except
				// rollback
				this.Delete (aDimIndex, aInsIndex, aInsertedCount);
				// raise again
				throw;
			}
		}

		// add at end

		public void AddAtEnd (int aDimIndex, int aAddCount)
		{
			int aAddIndex = this.GetDimensionSize (aDimIndex);
			this.Insert (aDimIndex, aAddIndex, aAddCount);
		}

		// delete from end

		public void DeleteFromEnd (int aDimIndex, int aDelCount)
		{
			int aDimSize = this.GetDimensionSize(aDimIndex);
			int aDelIndex = aDimSize - aDelCount;
			this.Delete (aDimIndex, aDelIndex, aDelCount);
		}

		// set a dim size

		public void SetDimensionSize (int aDimIndex, int aDimSize)
		{
			this.ClearDim (aDimIndex);
			this.AddAtEnd (aDimIndex, aDimSize);
		}

		// get dims sizes

		public int[] GetDimensionsSizes()
		{
			int aDimsCount = this.GetDimensions();
			int[] aDimsArrayResult = new int[aDimsCount];
			int aDimIndex = 0;
			while (aDimIndex < aDimsCount) {
				int aDimSize = this.GetDimensionSize(aDimIndex);
				aDimsArrayResult[aDimIndex] = aDimSize;
				++ aDimIndex;
			}
			return aDimsArrayResult;
		}

		// set dims sizes

		public void SetDimensionsSizes (int[] aDimsSizes)
		{
			this.Clear();

			int aDimsCount = aDimsSizes.Length;

			// set new dimensions
			this.SetDimensions (aDimsCount);

			int aDimIndex = 0;
			while (aDimIndex < aDimsCount) {

				int aDimSize = aDimsSizes[aDimIndex];

				this.SetDimensionSize (aDimIndex, aDimSize);

				++ aDimIndex;
			}
			// ok
		}

		// dims sizes property

		public int[] DimensionsSizes
		{
			get { return this.GetDimensionsSizes(); }
			set { this.SetDimensionsSizes (value); }
		}

		// resize dim

		public void ResizeDim (int aDimIndex, int aNewDimSize)
		{
			int aOldDimSize = this.GetDimensionSize(aDimIndex);
			int aDiffSize = aNewDimSize - aOldDimSize;
			if (aDiffSize > 0)
				this.AddAtEnd (aDimIndex, aDiffSize);
			else if (aDiffSize < 0)
				this.DeleteFromEnd (aDimIndex, - aDiffSize);
			// end if
		}

//========================================================================================

		// get item

		public T GetItem (int[] aIndexes)
		{
			return this.GetItemAtIndexes (aIndexes);
		}

		// set item

		public void SetItem (int[] aIndexes, T aValue)
		{
			this.SetItemAtIndexes (aIndexes, aValue);
		}

		// get item at index

		public T GetItem (int aLinearIndex)
		{
			int[] aIndexes = this.IndexesFromLinearIndex (aLinearIndex);
			return this.GetItem (aIndexes);
		}

		// set item at index

		public void SetItem (int aLinearIndex, T aValue)
		{
			int[] aIndexes = this.IndexesFromLinearIndex (aLinearIndex);
			this.SetItem (aIndexes, aValue);
		}

		// operator [index]

		public T this [int aIndex]
		{
			get {
				return this.GetItem (aIndex);
			}
			set {
				this.SetItem (aIndex, value);
			}
		}


	} // VRMultiDimArray<T>


} // namespace