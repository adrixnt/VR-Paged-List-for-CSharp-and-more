using System;

using System.Collections.Generic;

using VRAdrixNT.GenericMultiDimArray;

namespace VRAdrixNT.GenAdjMatrixGraph {


		// LinkData

		[Serializable]
		public class LinkData<TValue> {

			// instance data

			private bool theIsLinkSetState = false;

			private TValue theData;

			// init

			public LinkData() { }

			// accessors

			// link state

			public bool IsLinkSet() { return this.theIsLinkSetState; }

			public void SetLink(TValue aData) { this.Data = aData; this.theIsLinkSetState = true; }
			public void UnsetLink() { this.theIsLinkSetState = false; }

			// data

			public TValue Data {
				get { return this.theData; }
				set { this.theData = value; }
			}


		} // LinkData


	// Graph

	[Serializable]
	public class VRGraph<TItem, TValue>
	{

		// LinkData New Default Value Provider

		[Serializable]
		public class LinkDataNewDefaultValueProvider :
			IVRMDArrayAbstNewDefaultValueProvider<LinkData<TValue>>
		{
			// method implementation
			public LinkData<TValue> GetNewDefaultValue() { return new LinkData<TValue>(); }
		}


		// instance data

		private List<TItem> theList = new List<TItem>();

		private VRMultiDimArray<LinkData<TValue>> theMatrix = 
			new VRMultiDimArray<LinkData<TValue>>();


		// init

		public VRGraph()
		{
			// this.theMatrix = new VRMultiDimArray<LinkData<TValue>>();
			// set the new default value provider
			this.theMatrix.NewDefaultValueProvider = new LinkDataNewDefaultValueProvider();
			// set dimensions
			this.theMatrix.Dimensions = (2);
		}

		// size

		public int Size { get { return this.theList.Count; } }

		// item at (index)

		public TItem this[int aIndex] {
			get { return this.theList[aIndex]; }
			set { this.theList[aIndex] = value; }
		}

		// insert item

		public void Insert (int aIndex, TItem aItem)
		{
			this.theList.Insert (aIndex, aItem);
			try
			{
				this.theMatrix.Insert (0, aIndex);
				try
				{
					this.theMatrix.Insert (1, aIndex);
					// done !!
				}
				catch (Exception x)
				{
					this.theMatrix.Delete (0, aIndex);
					throw x;
				}
			}
			catch (Exception x)
			{
				this.theList.RemoveAt (aIndex);
				throw x;
			}
		}

		// add item

		public void Add (TItem aItem) { this.Insert (this.Size, aItem); }

		// remove item

		public TItem Remove (int aDelIndex)
		{
			this.theMatrix.Delete (1, aDelIndex);
			this.theMatrix.Delete (0, aDelIndex);
			TItem aItem = this.theList[aDelIndex];
			this.theList.RemoveAt (aDelIndex);
			return aItem;
		}

		// clear

		public void Clear()
		{
			while (this.Size > 0)
				this.Remove (0);
		}

		// get link value

		public TValue GetLinkValue (int aSrcIndex, int aDstIndex)
		{
			return this.theMatrix.GetItem(new int[] { aSrcIndex, aDstIndex }).Data;
		}

		// linked

		public bool Linked (int aSrcIndex, int aDstIndex)
		{
			return this.theMatrix.GetItem(new int[] { aSrcIndex, aDstIndex }).IsLinkSet();
		}

		// link

		public void Link (int aSrcIndex, int aDstIndex, TValue aValue)
		{
			this.theMatrix.GetItem(new int[] { aSrcIndex, aDstIndex }).SetLink (aValue);
		}

		// unlink

		public void Unlink (int aSrcIndex, int aDstIndex)
		{
			this.theMatrix.GetItem(new int[] { aSrcIndex, aDstIndex }).UnsetLink();
		}


/*/
		// DEBUG Matrix

		public void DEBUG_Matrix_ListMatrixOnConsole()
		{
			Console.WriteLine("dimensions: " + this.theMatrix.Dimensions);
			int aCount = this.theMatrix.Size;
			Console.WriteLine("size: (" + aCount + ")");
			int aIndex = 0;
			while (aIndex < aCount) {
				LinkData<TValue> aLinkData = this.theMatrix[aIndex];
				Console.WriteLine(
					"[" + aIndex + "] : " + aLinkData.IsLinkSet().ToString() + " :: " +
					aLinkData.Data.ToString()
				);
				++ aIndex;
			}
		}
/*/


	} // VRGraph


} // namespace