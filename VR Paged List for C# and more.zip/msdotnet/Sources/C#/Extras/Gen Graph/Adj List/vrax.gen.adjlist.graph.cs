using System;

using System.Runtime.Serialization;

using System.Collections.Generic;

using VRAdrixNT.Utils.RangeCheck;

namespace VRAdrixNT.GenAdjListGraph {

	// Arc

	[Serializable]
	public class VRArc<TItem, TValue>
	{

		private TItem theItem;

		private TValue theValue;

		// init

		public VRArc() { }

		public VRArc (TItem aItem, TValue aValue)
		{
			this.Item = aItem;
			this.Value = aValue;
		}

		// accessors

		// item

		public TItem GetItem() { return this.theItem; }
		private void SetItem(TItem aItem) { this.theItem = aItem; }
		public TItem Item {
			get { return this.GetItem(); }
			set { this.SetItem (value); }
		}

		// value

		public TValue GetValue() { return this.theValue; }

		public void SetValue (TValue aValue) { this.theValue = aValue; }

		public TValue Value {
			get { return this.GetValue(); }
			set { this.SetValue (value); }
		}

	} // Arc


	// Vertex

	[Serializable]
	public class VRVertex<TItem, TValue>
	{

		// instance data

		private TItem theItem;

		private List<VRArc<TItem, TValue>> theArcsList = new List<VRArc<TItem, TValue>>();

		// init

		public VRVertex() { }

		public VRVertex (TItem aItem)
		{
			this.Item = aItem;
		}

		// item

		public TItem GetItem() { return this.theItem; }
		private void SetItem (TItem aItem) { this.theItem = aItem; }
		public TItem Item {
			get { return this.GetItem(); }
			set { this.SetItem (value); }
		}

		// arcs list

		private List<VRArc<TItem, TValue>> ArcsList {
			get { return this.theArcsList; }
		}

		// size

		public int Size {
			get { return this.ArcsList.Count; }
		}

		// range check

		public bool IsItemIndexValid(int aIndex)
		{
			return VRIntRangeCheck.IsItemIndexValid(aIndex, 0, this.Size);
		}

		// index of (item)

		public int IndexOf (TItem aItem)
		{
			List<VRArc<TItem, TValue>> aList = this.ArcsList;
			int aSize = aList.Count;
			int aIndex = 0;
			while (aIndex < aSize) {
				if (((object) (aList[aIndex].Item)) == ((object) aItem))
					break;
				++ aIndex;
			}
			return aIndex;
		}

		// contains (item) ?

		public bool Contains (TItem aItem)
		{
			return this.IsItemIndexValid (this.IndexOf(aItem));
		}

		// arc value

		public TValue GetArcValue (TItem aItem)
		{
			int aIndex = this.IndexOf (aItem);
			if (!this.IsItemIndexValid(aIndex))
				// fail !!
				throw new Exception ("arc not found");
			// ok
			return this.ArcsList[aIndex].Value;
		}

		// set arc

		public void SetArc (TItem aItem, TValue aValue)
		{
			List<VRArc<TItem, TValue>> aList = this.ArcsList;
			int aIndex = this.IndexOf (aItem);
			if ( ! this.IsItemIndexValid (aIndex) )
				// the link does not exists: create it
				aList.Add (new VRArc<TItem, TValue>(aItem, aValue));
				// ok
			else
				// just update value
				aList[aIndex].Value = aValue;
				// done
			// end if
		}

		// remove arc

		public void RemoveArc (TItem aItem)
		{
			List<VRArc<TItem, TValue>> aList = this.ArcsList;
			int aIndex = this.IndexOf (aItem);
			if (this.IsItemIndexValid(aIndex))
				aList.RemoveAt (aIndex);
			// ok
		}

		public VRArc<TItem, TValue> GetArcAt (int aIndex)
		{
			return this.ArcsList [aIndex];
		}


	} // Vertex


	// Graph

	[Serializable]
	public class VRGraph<TItem, TValue>
	{
		// instance data

		private List<VRVertex<TItem, TValue>> theVertList = new List<VRVertex<TItem, TValue>>();

		// init

		public VRGraph() { }

		// accessors

		// vertex list

		private List<VRVertex<TItem, TValue>> VertList {
			get { return this.theVertList; }
		}

		// size

		public int Size { get { return this.VertList.Count; }  }

		// range check

		public bool IsItemIndexValid (int aIndex)
		{
			return VRIntRangeCheck.IsItemIndexValid(aIndex, 0, this.Size);
		}

		public bool IsInsertIndexValid (int aIndex)
		{
			return VRIntRangeCheck.IsInsertIndexValid(aIndex, 0, this.Size);
		}

		// index of item

		public int IndexOf (TItem aItem)
		{
			List<VRVertex<TItem, TValue>> aList = this.VertList;
			int aSize = aList.Count;
			int aIndex = 0;
			while (aIndex < aSize) {
				// VRVertex<TItem, TValue> aVertex = aList.get(aIndex);
				if (((object)(aList[aIndex].Item)) == (object)(aItem))
					break; // found !!
				++ aIndex;
			}
			return aIndex;
		}

		// contains (item) ?

		public bool Contains(TItem aItem)
		{
			return this.IsItemIndexValid ( this.IndexOf (aItem) );
		}

		// get item at (index)

		public TItem GetItemAt (int aIndex)
		{
			return this.VertList[aIndex].Item;
		}

		// this [index]

		public TItem this [int aIndex] {
			get { return this.GetItemAt (aIndex);  }
		}

		// insert item

		public void Insert (int aIndex, TItem aItem)
		{
			if (this.Contains(aItem))
				throw new Exception ("duplicate items are not allowed");
			// insert
			this.VertList.Insert (aIndex, new VRVertex<TItem, TValue>(aItem));
		}

		// add item

		public void Add (TItem aItem) { this.Insert (this.Size, aItem); }

		// remove

		public TItem Remove (int aDelIndex)
		{
			TItem aDelItem = this[aDelIndex];
			// remove all occurrencies of aDelItem
			List<VRVertex<TItem, TValue>> aList = this.VertList;
			int aSize = aList.Count;
			int aIndex = 0;
			while (aIndex < aSize) {
				aList[aIndex].RemoveArc (aDelItem);
				++ aIndex;
			}
			// remove item
			aList.RemoveAt (aDelIndex);
			return aDelItem;
		}

		// clear

		public void Clear()
		{
			while (this.Size > 0)
				this.Remove (0);
		}

		// linked

		public bool Linked (int aSrcIndex, int aDstIndex)
		{
			return this.VertList[aSrcIndex].Contains ( this[aDstIndex] );
		}

		// link value

		public TValue GetLinkValue (int aSrcIndex, int aDstIndex)
		{
			return this.VertList[aSrcIndex].GetArcValue ( this[aDstIndex] );
		}

		// link

		public void Link (int aSrcIndex, int aDstIndex, TValue aValue)
		{
			this.VertList[aSrcIndex].SetArc (this[aDstIndex], aValue);
		}

		// unlink

		public void Unlink (int aSrcIndex, int aDstIndex)
		{
			this.VertList[aSrcIndex].RemoveArc ( this[aDstIndex] );
		}


	} // Graph


	// Graph Procs

	public class VRGraphProcs {

		// find paths among (aSrcIndex, aDstIndex) in aGraph<TItem, TValue>

		public static List<List<int>> FindPaths <TItem, TValue> (
			VRGraph<TItem, TValue> aGraph,
			int aSrcNodeIndex, int aDstNodeIndex,
			List<int> aTraversedNodes
		) {
			if (aTraversedNodes.Contains(aSrcNodeIndex)) return null;

			// push aSrcNodeIndex as already traversed
			aTraversedNodes.Insert (0, aSrcNodeIndex);

			// [*] create the result list of paths
			List<List<int>> aResultPathsList = new List<List<int>>();

			int aNodesCount = aGraph.Size;
			int aNodeIndex = 0;
			while (aNodeIndex < aNodesCount) {

				// [*] create the local paths list ref
				List < List<int> > aLocalPathsList = null;

				if (aGraph.Linked(aSrcNodeIndex, aNodeIndex)) {

					// link: (src -> other node)

					if (aNodeIndex == aDstNodeIndex) {

						// aNodeIndex is our target destination
						// direct link (src -> dst)

						// [*] create an empty local paths list
						aLocalPathsList = new List<List<int>>();

						// [*] create an empty path
						List<int> aPath = new List<int>();

						// aPath = [aDstNodeIndex]
						aPath.Add (aDstNodeIndex);

						// add aPath to the local list
						aLocalPathsList.Add (aPath);
						// ok!

					} else {

						// aNodeIndex is NOT the target
						// direct link: src node -> other node
						// recurse on (aNodeIndex, aDstNodeIndex)
						aLocalPathsList = FindPaths (aGraph, aNodeIndex, aDstNodeIndex, aTraversedNodes);
						// back from recursive call

					}

				}

				// note: aLocalPathsList can be null !!

				if (aLocalPathsList != null) {

					// add aSrcNodeIndex to all paths in aLocalPathsList

					// add every path in aLocalPathsList to resultPathsList

					int aPathsCount = aLocalPathsList.Count;
					int aPathIndex = 0;
					while (aPathIndex < aPathsCount) {

						// get path from local paths list
						List<int> aPath = aLocalPathsList [aPathIndex];

						// [*] clone aPath
						List<int> aPathToAdd = new List<int> (aPath);

						// aPathToAdd = [aSrcNodeIndex] + aPathToAdd
						aPathToAdd.Insert (0, aSrcNodeIndex);

						// add aPathToAdd to resultPathsList
						aResultPathsList.Add (aPathToAdd);

						// next
						++ aPathIndex;
					}

				}

				// next
				++ aNodeIndex;
			}

			// pop aSrcNodeIndex from the already traversed nodes stack
			aTraversedNodes.RemoveAt (0);

			return aResultPathsList;
		}

		// user macro

		public static List<List<int>> FindPaths<TItem, TValue> (
			VRGraph<TItem, TValue> aGraph,
			int aSrcNodeIndex, int aDstNodeIndex
		) {
			return FindPaths (aGraph, aSrcNodeIndex, aDstNodeIndex, new List<int>());
		}


	}


} // namespace