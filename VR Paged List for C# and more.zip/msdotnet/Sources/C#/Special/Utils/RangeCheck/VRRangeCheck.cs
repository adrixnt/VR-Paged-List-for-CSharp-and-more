
namespace VRAdrixNT.Utils.RangeCheck
{
	using System;

#region long range check

	public class VRLongRangeCheck
	{
		public VRLongRangeCheck() {}

#region Exceptions

		// Exceptions

		public class RangeCheckBaseException : Exception
		{
			public RangeCheckBaseException (string aMsg) : base(aMsg) {}
		}

		// invalid range size

		public class InvalidRangeSizeException : RangeCheckBaseException
		{
			private long theRangeSize = 0L;

			public long RangeSize { get { return this.theRangeSize; } }

			public InvalidRangeSizeException (string aMsg, long aRangeSize) :
				base (aMsg)	
			{
				this.theRangeSize = aRangeSize;
			}
		}

		// invalid items range size

		public class InvalidItemsRangeSizeException : InvalidRangeSizeException
		{
			public InvalidItemsRangeSizeException (long aRangeSize) :
				base ("invalid items range size", aRangeSize)
			{}
		}

		// invalid insert range size

		public class InvalidInsertRangeSizeException : InvalidRangeSizeException
		{
			public InvalidInsertRangeSizeException (long aRangeSize) :
				base ("invalid insert range size", aRangeSize)
			{}
		}

		// invalid range index

		public class InvalidRangeIndexException : RangeCheckBaseException
		{
			private long theIndex = 0L;
			private long theRangeIndex = 0L;
			private long theRangeSize = 0L;

			public long Index { get { return this.theIndex; } }
			public long RangeIndex { get { return this.theRangeIndex; } }
			public long RangeSize { get { return this.theRangeSize; } }

			public InvalidRangeIndexException (string aMsg, long aIndex, long aRangeIndex, long aRangeSize) :
				base (aMsg)
			{
				this.theIndex = aIndex;
				this.theRangeIndex = aRangeIndex;
				this.theRangeSize = aRangeSize;
			}
		}

		// invalid range item index

		public class InvalidItemsRangeIndexException : InvalidRangeIndexException
		{
			public InvalidItemsRangeIndexException (long aIndex, long aRangeIndex, long aRangeSize) :
				base ("invalid range item index", aIndex, aRangeIndex, aRangeSize)
			{}
		}

		// invalid range insert index

		public class InvalidInsertRangeIndexException : InvalidRangeIndexException
		{
			public InvalidInsertRangeIndexException (long aIndex, long aRangeIndex, long aRangeSize) :
				base ("invalid range insert index", aIndex, aRangeIndex, aRangeSize)
			{}
		}

#endregion

//=======================================================================================

#region procs & funcs

//=======================================================================================

		// procs & funcs

		public static long ItemsRangeBeginIndex (long aRangeIndex, long aRangeCount)
		{
			return aRangeIndex;
		}
		public static long ItemsRangeEndIndex (long aRangeIndex, long aRangeCount)
		{
			return aRangeIndex + aRangeCount - 1L ;
		}

		public static long InsertRangeBeginIndex (long aRangeIndex, long aRangeCount)
		{
			return aRangeIndex;
		}
		public static long InsertRangeEndIndex (long aRangeIndex, long aRangeCount)
		{
			return (aRangeIndex + aRangeCount);
		}

//=======================================================================================

		public static bool IsItemsRangeSizeValid (long aRangeSize)
		{
			return (aRangeSize > 0L);
		}
		public static bool IsInsertRangeSizeValid (long aRangeSize)
		{
			return (aRangeSize >= 0L);
		}

		public static void CheckValidItemsRangeSize (long aRangeSize)
		{
			if ( ! IsItemsRangeSizeValid (aRangeSize) )
				throw new InvalidItemsRangeSizeException (aRangeSize);
			// ok!
		}

		public static void CheckValidInsertRangeSize (long aRangeSize)
		{
			if ( ! IsInsertRangeSizeValid (aRangeSize) )
				throw new InvalidInsertRangeSizeException (aRangeSize);
			// ok!
		}

//=======================================================================================

		// is valid range item index ?

		public static bool IsItemIndexValid (long aIndex, long aRangeIndex, long aRangeCount)
		{
			return
				(aIndex >= aRangeIndex) &&
				(aIndex < (aRangeIndex + aRangeCount))
			;
		}

		// is valid range insert index ?

		public static bool IsInsertIndexValid (long aIndex, long aRangeIndex, long aRangeCount)
		{
			return
				(aIndex >= aRangeIndex) &&
				(aIndex <= (aRangeIndex + aRangeCount))
			;
		}

		// check valid item index

		public static void CheckValidItemIndex (long aIndex, long aRangeIndex, long aRangeCount)
		{
			CheckValidItemsRangeSize (aRangeCount);
			// ok!
			if ( ! IsItemIndexValid (aIndex, aRangeIndex, aRangeCount) )
				throw new InvalidItemsRangeIndexException (aIndex, aRangeIndex, aRangeCount);
			// ok!
		}

		// check valid insert index

		public static void CheckValidInsertIndex (long aIndex, long aRangeIndex, long aRangeCount)
		{
			CheckValidInsertRangeSize (aRangeCount);
			// ok!
			if ( ! IsInsertIndexValid (aIndex, aRangeIndex, aRangeCount) )
				throw new InvalidInsertRangeIndexException (aIndex, aRangeIndex, aRangeCount);
			// ok!
		}

//=======================================================================================

		// test valid items range

		public static bool IsItemsRangeValid (long aChkIndex, long aChkCount, long aRngIndex, long aRngCount)
		{
			return
				IsItemsRangeSizeValid (aChkCount) &&
				IsItemIndexValid (aChkIndex, aRngIndex, aRngCount) &&
				IsItemIndexValid (ItemsRangeEndIndex (aChkIndex, aChkCount), aRngIndex, aRngCount)
			;
		}

		// test valid insert range

		public static bool IsInsertRangeValid (long aChkIndex, long aChkCount, long aRngIndex, long aRngCount)
		{
			return
				IsInsertRangeSizeValid (aChkCount) &&
				IsInsertIndexValid (aChkIndex, aRngIndex, aRngCount) &&
				IsInsertIndexValid (InsertRangeEndIndex (aChkIndex, aChkCount), aRngIndex, aRngCount)
			;
		}

		// check

		// check valid items range

		public static void CheckValidItemsRange (long aChkIndex, long aChkCount, long aRngIndex, long aRngCount)
		{
			CheckValidItemsRangeSize (aChkCount);
			// ok!
			CheckValidItemIndex (aChkIndex, aRngIndex, aRngCount);
			// ok!
			CheckValidItemIndex (ItemsRangeEndIndex (aChkIndex, aChkCount), aRngIndex, aRngCount);
			// ok!
		}

		// check valid insert range

		public static void CheckValidInsertRange (long aChkIndex, long aChkCount, long aRngIndex, long aRngCount)
		{
			CheckValidInsertRangeSize (aChkCount);
			// ok!
			CheckValidInsertIndex (aChkIndex, aRngIndex, aRngCount);
			// ok!
			CheckValidInsertIndex (InsertRangeEndIndex (aChkIndex, aChkCount), aRngIndex, aRngCount);
			// ok!
		}

//=======================================================================================

#endregion

	} // VRLongRangeCheck

#endregion

//=======================================================================================

#region int range check

	public class VRIntRangeCheck
	{
		public VRIntRangeCheck() {}

#region Exceptions

		// Exceptions

		public class RangeCheckBaseException : Exception
		{
			public RangeCheckBaseException (string aMsg) : base(aMsg) {}
		}

		// invalid range size

		public class InvalidRangeSizeException : RangeCheckBaseException
		{
			private int theRangeSize = 0;

			public int RangeSize { get { return this.theRangeSize; } }

			public InvalidRangeSizeException (string aMsg, int aRangeSize) :
				base (aMsg)	
			{
				this.theRangeSize = aRangeSize;
			}
		}

		// invalid items range size

		public class InvalidItemsRangeSizeException : InvalidRangeSizeException
		{
			public InvalidItemsRangeSizeException (int aRangeSize) :
				base ("invalid items range size", aRangeSize)
			{}
		}

		// invalid insert range size

		public class InvalidInsertRangeSizeException : InvalidRangeSizeException
		{
			public InvalidInsertRangeSizeException (int aRangeSize) :
				base ("invalid insert range size", aRangeSize)
			{}
		}

		// invalid range index

		public class InvalidRangeIndexException : RangeCheckBaseException
		{
			private int theIndex = 0;
			private int theRangeIndex = 0;
			private int theRangeSize = 0;

			public int Index { get { return this.theIndex; } }
			public int RangeIndex { get { return this.theRangeIndex; } }
			public int RangeSize { get { return this.theRangeSize; } }

			public InvalidRangeIndexException (string aMsg, int aIndex, int aRangeIndex, int aRangeSize) :
				base (aMsg)
			{
				this.theIndex = aIndex;
				this.theRangeIndex = aRangeIndex;
				this.theRangeSize = aRangeSize;
			}
		}

		// invalid range item index

		public class InvalidItemsRangeIndexException : InvalidRangeIndexException
		{
			public InvalidItemsRangeIndexException (int aIndex, int aRangeIndex, int aRangeSize) :
				base ("invalid range item index", aIndex, aRangeIndex, aRangeSize)
			{}
		}

		// invalid range insert index

		public class InvalidInsertRangeIndexException : InvalidRangeIndexException
		{
			public InvalidInsertRangeIndexException (int aIndex, int aRangeIndex, int aRangeSize) :
				base ("invalid range insert index", aIndex, aRangeIndex, aRangeSize)
			{}
		}

#endregion

//=======================================================================================

#region procs & funcs

		public static int ItemsRangeBeginIndex (int aRangeIndex, int aRangeCount)
		{
			return aRangeIndex;
		}
		public static int ItemsRangeEndIndex (int aRangeIndex, int aRangeCount)
		{
			return aRangeIndex + aRangeCount - 1 ;
		}

		public static int InsertRangeBeginIndex (int aRangeIndex, int aRangeCount)
		{
			return aRangeIndex;
		}
		public static int InsertRangeEndIndex (int aRangeIndex, int aRangeCount)
		{
			return (aRangeIndex + aRangeCount);
		}

//=======================================================================================

		public static bool IsItemsRangeSizeValid (int aRangeSize)
		{
			return (aRangeSize > 0);
		}
		public static bool IsInsertRangeSizeValid (int aRangeSize)
		{
			return (aRangeSize >= 0);
		}

		public static void CheckValidItemsRangeSize (int aRangeSize)
		{
			if ( ! IsItemsRangeSizeValid (aRangeSize) )
				throw new InvalidItemsRangeSizeException (aRangeSize);
			// ok!
		}

		public static void CheckValidInsertRangeSize (int aRangeSize)
		{
			if ( ! IsInsertRangeSizeValid (aRangeSize) )
				throw new InvalidInsertRangeSizeException (aRangeSize);
			// ok!
		}

//=======================================================================================

		// is valid range item index ?

		public static bool IsItemIndexValid (int aIndex, int aRangeIndex, int aRangeCount)
		{
			return
				(aIndex >= aRangeIndex) &&
				(aIndex < (aRangeIndex + aRangeCount))
			;
		}

		// is valid range insert index ?

		public static bool IsInsertIndexValid (int aIndex, int aRangeIndex, int aRangeCount)
		{
			return
				(aIndex >= aRangeIndex) &&
				(aIndex <= (aRangeIndex + aRangeCount))
			;
		}

		// check valid item index

		public static void CheckValidItemIndex (int aIndex, int aRangeIndex, int aRangeCount)
		{
			CheckValidItemsRangeSize (aRangeCount);
			// ok!
			if ( ! IsItemIndexValid (aIndex, aRangeIndex, aRangeCount) )
				throw new InvalidItemsRangeIndexException (aIndex, aRangeIndex, aRangeCount);
			// ok!
		}

		// check valid insert index

		public static void CheckValidInsertIndex (int aIndex, int aRangeIndex, int aRangeCount)
		{
			CheckValidInsertRangeSize (aRangeCount);
			// ok!
			if ( ! IsInsertIndexValid (aIndex, aRangeIndex, aRangeCount) )
				throw new InvalidInsertRangeIndexException (aIndex, aRangeIndex, aRangeCount);
			// ok!
		}


//=======================================================================================

		// test valid items range

		public static bool IsItemsRangeValid (int aChkIndex, int aChkCount, int aRngIndex, int aRngCount)
		{
			return
				IsItemsRangeSizeValid (aChkCount) &&
				IsItemIndexValid (aChkIndex, aRngIndex, aRngCount) &&
				IsItemIndexValid (ItemsRangeEndIndex (aChkIndex, aChkCount), aRngIndex, aRngCount)
			;
		}

		// test valid insert range

		public static bool IsInsertRangeValid (int aChkIndex, int aChkCount, int aRngIndex, int aRngCount)
		{
			return
				IsInsertRangeSizeValid (aChkCount) &&
				IsInsertIndexValid (aChkIndex, aRngIndex, aRngCount) &&
				IsInsertIndexValid (InsertRangeEndIndex (aChkIndex, aChkCount), aRngIndex, aRngCount)
			;
		}

		// check

		// check valid items range

		public static void CheckValidItemsRange (int aChkIndex, int aChkCount, int aRngIndex, int aRngCount)
		{
			CheckValidItemsRangeSize (aChkCount);
			// ok!
			CheckValidItemIndex (aChkIndex, aRngIndex, aRngCount);
			// ok!
			CheckValidItemIndex (ItemsRangeEndIndex (aChkIndex, aChkCount), aRngIndex, aRngCount);
			// ok!
		}

		// check valid insert range

		public static void CheckValidInsertRange (int aChkIndex, int aChkCount, int aRngIndex, int aRngCount)
		{
			CheckValidInsertRangeSize (aChkCount);
			// ok!
			CheckValidInsertIndex (aChkIndex, aRngIndex, aRngCount);
			// ok!
			CheckValidInsertIndex (InsertRangeEndIndex (aChkIndex, aChkCount), aRngIndex, aRngCount);
			// ok!
		}


//=======================================================================================


#endregion

//=======================================================================================

	} // VRIntRangeCheck

#endregion

	// ... ... ...
	// more ?

}

