using System;

namespace VRAdrixNT.Utils.RangeCheck
{

	// Range Exceptions

	public class RangeCheckBaseException : Exception
	{
		public RangeCheckBaseException (string aMsg) : base(aMsg) {}
	}

	// invalid range size

	public class InvalidRangeSizeException : RangeCheckBaseException
	{
		public InvalidRangeSizeException (string aMsg) : base (aMsg) {}
	}

	// invalid items range size

	public class InvalidItemsRangeSizeException : InvalidRangeSizeException
	{
		public InvalidItemsRangeSizeException (string aMsg) :
			base (aMsg)
		{}
	}

	// invalid insert range size

	public class InvalidInsertRangeSizeException : InvalidRangeSizeException
	{
		public InvalidInsertRangeSizeException (string aMsg) :
			base (aMsg)
		{}
	}

	// invalid range index

	public class InvalidRangeIndexException : RangeCheckBaseException
	{
		public InvalidRangeIndexException (string aMsg) : base (aMsg) {}
	}

	// invalid range item index

	public class InvalidItemsRangeIndexException : InvalidRangeIndexException
	{
		public InvalidItemsRangeIndexException (string aMsg) :
			base (aMsg)
		{}
	}

	// invalid range insert index

	public class InvalidInsertRangeIndexException : InvalidRangeIndexException
	{
		public InvalidInsertRangeIndexException (string aMsg) :
			base (aMsg)
		{}
	}

}