using System;

namespace VRAdrixNT.Utils.StrFmt.IndexesArray
{

	public class VRIndexesArrayStrFmtUtils
	{

		// format indexes array

		public static string FormatIndexesArray (
			int[] aIndexes,
			string aPrefixStr, string aPostfixStr,
			string aIndexPrefixStr, string aIndexPostfixStr,
			string aIndexSeparatorStr
		) {
			string aStrResult = "";

			int aCount = aIndexes.Length;

			aStrResult += aPrefixStr;

			int aIndex = 0;

			while (aIndex < aCount) {

				aStrResult +=
					aIndexPrefixStr +
						( aIndexes [aIndex] ) +
					aIndexPostfixStr;

				if ( aIndex < (aCount - 1) )
					aStrResult += aIndexSeparatorStr;
				// end if

				++ aIndex;
			}

			aStrResult += aPostfixStr;

			return aStrResult;
		}

	}

}
