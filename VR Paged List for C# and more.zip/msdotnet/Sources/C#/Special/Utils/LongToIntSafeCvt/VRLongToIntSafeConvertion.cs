
namespace VRAdrixNT.Utils.LongToIntSafeCvt
{
	using System;

	public class VRLongToIntSafeCast
	{
		public VRLongToIntSafeCast() {}

		public class OutsideIntSizeSpaceException : Exception
		{
			private long theValue = 0L;

			public long Value { get { return this.theValue; } }

			public OutsideIntSizeSpaceException (string aMsg, long aValue) :
				base (aMsg)
			{
				this.theValue = aValue;
			}

		} // OutsideIntSizeSpaceException

		public static bool IsInsideIntSizeSpace (long aValue)
		{
			return (int.MinValue <= aValue) && (aValue <= int.MaxValue) ;
		}

		public static void CheckInsideIntSizeSpace (long aValue)
		{
			if ( ! IsInsideIntSizeSpace (aValue) )
				throw new OutsideIntSizeSpaceException ("(" + aValue + ") is outside int size space", aValue);
			// ok!
		}

		public static int LongToInt (long aValue)
		{
			CheckInsideIntSizeSpace (aValue);
			return (int) aValue;
		}

	}

}

// that's all folks ...