using System;

namespace VRAdrixNT.BasicUtils.IntArray
{
	public class VRIntArrayUtils {

		// Concat (a, b)

		public static int[] Concat (int[] aArrayA, int[] aArrayB)
		{
			long aCountA = aArrayA.LongLength;
			long aCountB = aArrayB.LongLength;
			int[] aArrayResult = new int [aCountA + aCountB];
			Array.Copy (aArrayA, 0L, aArrayResult, 0L, aCountA);
			Array.Copy (aArrayB, 0L, aArrayResult, aCountA, aCountB);
			return aArrayResult;
		}

		// Fill

		public static void Fill (int[] aArray, int aIndex, int aCount, int aValue)
		{
			int i = 0;
			while (i < aCount) {
				aArray [aIndex + i] = aValue;
				++ i;
			}
		}

	}

}