

namespace VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main.PerfStats
{

	using VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main.Support;

//=======================================================================================
// Performance Statistics
//=======================================================================================

	public class VRPListPerfStats : IVRPLBTreeEnumerator
	{

		public struct PagesSummaries
		{
			public long totalPagesCount; // the total number of pages
			public long totalPagesUsedItemsCount; // the total number of used items
			// min/max page items counters
			public long maxPagesItemsCount;
			public long minPagesItemsCount;
		}

		// =============
		// instance data

		private VRPagedList fThePList;

		private PagesSummaries[] fPageType = new PagesSummaries [2];

		private IVRPLBTreeEnumerator fTheEnumerator = null;

		// =======
		// methods

		// zero-init

		public void ZeroInit()
		{
			int i = 0;
			while (i < 2) {
				this.fPageType[i].totalPagesCount = 0L;
				this.fPageType[i].totalPagesUsedItemsCount = 0L;
				this.fPageType[i].maxPagesItemsCount = 0L;
				this.fPageType[i].minPagesItemsCount = 0L;
				if (this.fThePList != null)
					this.fPageType[i].minPagesItemsCount = this.fThePList.GetPageTypeSize (i);
				//end if
				++i;
			}
		}

		// init

		public VRPListPerfStats (VRPagedList aPList, IVRPLBTreeEnumerator aEnumerator) :
			base()
		{
			this.fThePList = aPList;
			this.fTheEnumerator = aEnumerator;
			this.ZeroInit();
		}

		// accessors

		public void SetList (VRPagedList aPList)
		{
			this.fThePList = aPList;
			this.ZeroInit();
		}

		public VRPagedList GetList() { return this.fThePList; }

		// user enumerator

		public void SetBTreePagesEnumerator (IVRPLBTreeEnumerator aEnumerator)
		{
			this.fTheEnumerator = aEnumerator;
		}

		public IVRPLBTreeEnumerator GetBTreePagesEnumerator()
		{
			return this.fTheEnumerator;
		}

//=======================================================================================
// enumerating procs

#region IVRPLBTreeEnumerator Members

		public bool OnStartEnumPages (
			VRPagedList aPagedList,
			int aLevelsCount,
			int aLevelIndex,
			long aPagesListCount
		) {
			if (this.fTheEnumerator != null)
				return this.fTheEnumerator.OnStartEnumPages (
					aPagedList, aLevelsCount, aLevelIndex, aPagesListCount
				);
			return true;
		}

		public bool OnEnumPage (
			VRPagedList aPagedList,
			int aLevelsCount,
			int aLevelIndex,
			long aPagesListCount,
			long aPageListIndex,
			bool isDataPage,
			long aPageItemsCount,
			long aPageDeepCount
		) {
			// begin

			int pageTypeIndex = 0;
			if (isDataPage)
				pageTypeIndex = 1;
			//end if

			++ this.fPageType[pageTypeIndex].totalPagesCount;

			this.fPageType[pageTypeIndex].totalPagesUsedItemsCount += aPageItemsCount;

			if (aPageItemsCount > this.fPageType[pageTypeIndex].maxPagesItemsCount)
				this.fPageType[pageTypeIndex].maxPagesItemsCount = aPageItemsCount;

			if (aPageItemsCount < this.fPageType[pageTypeIndex].minPagesItemsCount)
				this.fPageType[pageTypeIndex].minPagesItemsCount = aPageItemsCount;

			// done!

			// invoke our enum-page user call-back (if any)
			if (this.fTheEnumerator != null)
				return this.fTheEnumerator.OnEnumPage (
					aPagedList, aLevelsCount, aLevelIndex, aPagesListCount,
					aPageListIndex,
					isDataPage,
					aPageItemsCount, aPageDeepCount
				);
			return true;
		}

		public bool OnStopEnumPages (
			VRPagedList aPagedList,
			int aLevelsCount,
			int aLevelIndex,
			long aPagesListCount
		) {
			// TODO:  Add VRPListPerfStats.OnStopEnumPages implementation
			if (this.fTheEnumerator != null)
				return this.fTheEnumerator.OnStopEnumPages (
					aPagedList, aLevelsCount, aLevelIndex, aPagesListCount
				);
			return true;
		}

#endregion

//=======================================================================================

		// ================================
		// Computing Performance Statistics

		public bool ComputePerfStats()
		{
			this.ZeroInit();
			if (this.fThePList != null) {
				bool result = this.fThePList.DeepEnumBTreePages (this);
				if (!result)
					this.ZeroInit();
				return result;
			}
			return false;
		}

//=======================================================================================

		// ==================
		// retrieving results

		// max page items count - page size

		public long GetPageTypeSize (int aPageType)
		{
			return this.fThePList.GetPageTypeSize (aPageType);
		}
		public long GetRefsPageSize() { return this.GetPageTypeSize (VRPLAbstPage.PageType.kRefsPage); }
		public long GetDataPageSize() { return this.GetPageTypeSize (VRPLAbstPage.PageType.kDataPage); }


		// total number of pages - count

		public long GetTotalPagesTypeCount (int aPageType)
		{
			return this.fPageType[aPageType].totalPagesCount;
		}
		public long GetTotalRefsPagesCount() { return this.GetTotalPagesTypeCount (VRPLAbstPage.PageType.kRefsPage); }
		public long GetTotalDataPagesCount() { return this.GetTotalPagesTypeCount (VRPLAbstPage.PageType.kDataPage); }

		// total number of used items - count

		public long GetTotalPagesTypeUsedItemsCount (int aPageType)
		{
			return this.fPageType[aPageType].totalPagesUsedItemsCount;
		}
		public long GetTotalRefsPagesUsedItemsCount() { return this.GetTotalPagesTypeUsedItemsCount (VRPLAbstPage.PageType.kRefsPage); }
		public long GetTotalDataPagesUsedItemsCount() { return this.GetTotalPagesTypeUsedItemsCount (VRPLAbstPage.PageType.kDataPage); }

		// max/min items-count per page

		// max
		public long GetMaxPagesTypeItemsCount (int aPageType)
			{ return this.fPageType[aPageType].maxPagesItemsCount; }
		// refs pages
		public long GetMaxRefsPagesItemsCount() { return this.GetMaxPagesTypeItemsCount (VRPLAbstPage.PageType.kRefsPage); }
		// data pages
		public long GetMaxDataPagesItemsCount() { return this.GetMaxPagesTypeItemsCount (VRPLAbstPage.PageType.kDataPage); }

		// min
		public long GetMinPagesTypeItemsCount (int aPageType)
			{ return this.fPageType[aPageType].minPagesItemsCount; }
		// refs pages
		public long GetMinRefsPagesItemsCount() { return this.GetMinPagesTypeItemsCount (VRPLAbstPage.PageType.kRefsPage); }
		// data pages
		public long GetMinDataPagesItemsCount() { return this.GetMinPagesTypeItemsCount (VRPLAbstPage.PageType.kDataPage); }


		// number of total allotted <type>-pages items - count

		public long GetTotalPagesTypeAllottedItemsCount (int aPageType)
		{
			return this.fPageType[aPageType].totalPagesCount * this.GetPageTypeSize (aPageType);
		}
		public long GetTotalRefsPagesAllottedItemsCount() { return this.GetTotalPagesTypeAllottedItemsCount (VRPLAbstPage.PageType.kRefsPage); }
		public long GetTotalDataPagesAllottedItemsCount() { return this.GetTotalPagesTypeAllottedItemsCount (VRPLAbstPage.PageType.kDataPage); }


		// number of total un-used <type>-pages items - count

		public long GetTotalPagesTypeUnusedItemsCount (int aPageType)
		{
			return
				this.GetTotalPagesTypeAllottedItemsCount (aPageType) -
				this.fPageType[aPageType].totalPagesUsedItemsCount
			;
		}
		public long GetTotalRefsPagesUnusedItemsCount() { return this.GetTotalPagesTypeUnusedItemsCount (VRPLAbstPage.PageType.kRefsPage); }
		public long GetTotalDataPagesUnusedItemsCount() { return this.GetTotalPagesTypeUnusedItemsCount (VRPLAbstPage.PageType.kDataPage); }


		// <type>-pages usage ratio - real number

		public double GetPagesTypeUsageRatio (int aPageType)
		{
			// usage.ratio = (used / allotted)
			long denom = this.GetTotalPagesTypeAllottedItemsCount (aPageType);
			if (denom != 0L)
				return ((double)this.GetTotalPagesTypeUsedItemsCount (aPageType)) / ((double)denom);
			//else
			return 1.0;
			// result == 1.0 : optimum allocation usage ratio
			// result < 0.5 : bad allocation usage ratio
		}
		public double GetRefsPagesUsageRatio() { return this.GetPagesTypeUsageRatio (VRPLAbstPage.PageType.kRefsPage); }
		public double GetDataPagesUsageRatio() { return this.GetPagesTypeUsageRatio (VRPLAbstPage.PageType.kDataPage); }

		// <type>-pages usage % - real number

		public double GetPagesTypeUsagePercent (int aPageType)
		{
			// usage.percent = (used / allotted) * 100
			return this.GetPagesTypeUsageRatio (aPageType) * 100.0;
			// result == 100% : optimum allocation usage ratio
			// result < 50% : bad allocation usage ratio
		}
		public double GetRefsPagesUsagePercent() { return this.GetPagesTypeUsagePercent (VRPLAbstPage.PageType.kRefsPage); }
		public double GetDataPagesUsagePercent() { return this.GetPagesTypeUsagePercent (VRPLAbstPage.PageType.kDataPage); }


		// medium number of items per <type>-page - real number

		public double GetMediumNumberOfItemsPerPageType (int aPageType)
		{
			// result: total_used_items_count / total_pages_count
			long denom = this.GetTotalPagesTypeCount (aPageType);
			if (denom != 0L)
				return
				((double)this.GetTotalPagesTypeUsedItemsCount (aPageType)) / ((double)denom);
			//else
				return 0.0;
		}
		public double GetMediumNumberOfItemsPerRefsPage() { return this.GetMediumNumberOfItemsPerPageType (VRPLAbstPage.PageType.kRefsPage); }
		public double GetMediumNumberOfItemsPerDataPage() { return this.GetMediumNumberOfItemsPerPageType (VRPLAbstPage.PageType.kDataPage); }


//=======================================================================================
// B+Tree summaries

		// total B+Tree pages count

		public long GetTotalPagesCount()
		{
			return
				this.GetTotalRefsPagesCount() +
				this.GetTotalDataPagesCount()
			;
		}

		// items counters

		// allotted

		public long GetTotalPagesAllottedItemsCount()
		{
			return
				this.GetTotalRefsPagesAllottedItemsCount() +
				this.GetTotalDataPagesAllottedItemsCount()
			;
		}

		// used

		public long GetTotalPagesUsedItemsCount()
		{
			return
				this.GetTotalRefsPagesUsedItemsCount() +
				this.GetTotalDataPagesUsedItemsCount()
			;
		}

		// not-used

		public long GetTotalPagesUnusedItemsCount()
		{
			return
				this.GetTotalPagesAllottedItemsCount() -
				this.GetTotalPagesUsedItemsCount()
			;
		}


		// usage ratio - real number

		public double GetPagesUsageRatio()
		{
			// result: used / allotted
			long denom = this.GetTotalPagesAllottedItemsCount();
			if (denom != 0L)
				return ((double)this.GetTotalPagesUsedItemsCount()) / ((double)denom) ;
			//else
				return (1.0);
			// result == 1.0 : optimum allocation usage ratio
			// result < 0.5 : bad allocation usage ratio
		}

		// usage % - real number

		public double GetPagesUsagePercent()
		{
			// x = (used / allotted) * 100
			return this.GetPagesUsageRatio() * 100.0;
			// result == 100% : optimum allocation usage ratio
			// result < 50% : bad allocation usage ratio
		}

		// medium number of items per page - real number

		public double GetMediumNumberOfItemsPerPage()
		{
			long denom = this.GetTotalPagesCount();
			if (denom != 0L)
				return ((double)this.GetTotalPagesUsedItemsCount()) / ((double)denom) ;
			//else
				return (0.0);
		}


		// ... ... ...
		// ... ... ...
		// ... ... ...


	} // VRPListPerfStats


}//namespace

// that's all folks ...
