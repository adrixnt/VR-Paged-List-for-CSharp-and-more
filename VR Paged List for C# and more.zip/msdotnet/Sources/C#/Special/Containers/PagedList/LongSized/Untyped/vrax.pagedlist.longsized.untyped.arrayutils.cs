
namespace VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main.Support
{

	public sealed class ArrayUtils
	{
		private ArrayUtils() {}

//=======================================================================================

		public static long SizeOf (object[] aSrcArray) { return aSrcArray.LongLength; }

		public static bool IsEmpty (object[] aSrcArray)
		{
			return (aSrcArray.LongLength <= 0L) ;
		}

//=======================================================================================

		/*/ fill an array subrange with a filler-value
		/*/

		public static object[] Fill (object[] aDstArray, long aDstIndex, long aFillItemsCount, object aFillerValue)
		{
			long i = 0L;
			while (i < aFillItemsCount) 
			{
				aDstArray [aDstIndex + i] = aFillerValue;
				++i;
			}
			return aDstArray;
		}

		public static object[] Fill (object[] aDstArray, long aFillItemsCount, object aFillerValue)
		{
			return Fill (aDstArray, (0L), aFillItemsCount, aFillerValue);
		}

		public static object[] Fill (object[] aDstArray, object aFillerValue)
		{
			return Fill (aDstArray, SizeOf(aDstArray), aFillerValue);
		}

//=======================================================================================
// clear : fill with null values

		public static object[] Clear (object[] aDstArray, long aDstIndex, long aClearItemsCount)
		{
			return Fill (aDstArray, aDstIndex, aClearItemsCount, /*/aFillerValue/*/ null);
		}

		public static object[] Clear (object[] aDstArray, long aClearItemsCount)
		{
			return Clear (aDstArray, (0L), aClearItemsCount);
		}

		public static object[] Clear (object[] aDstArray)
		{
			return Clear (aDstArray, SizeOf(aDstArray));
		}

//=======================================================================================
// Moving Array Items

		// ===================
		// heterogeneous moves (among two arrays)

		// moveLeft, moveRight, move : they all return "aDstArray"

		/*/ moveLeft
			move items from left to right
		/*/

		public static object[] MoveLeft (
			object[] aDstArray, long aDstIndex,
			object[] aSrcArray, long aSrcIndex,
			long aMoveItemsCount
		) {
			long i = 0L;
			while (i < aMoveItemsCount) 
			{
				aDstArray [aDstIndex + i] = aSrcArray [aSrcIndex + i];
				++i;
			}
			return aDstArray;
		}

		/*/ moveRight
			move items from right to left
		/*/

		public static object[] MoveRight (
			object[] aDstArray, long aDstIndex,
			object[] aSrcArray, long aSrcIndex,
			long aMoveItemsCount
		) {
			long i = aMoveItemsCount - 1L;
			while (i >= 0L) 
			{
				aDstArray [aDstIndex + i] = aSrcArray [aSrcIndex + i];
				--i;
			}
			return aDstArray;
		}

		/*/ move
			automatically decide whether to move left or right
		/*/

		public static object[] Move (
			object[] aDstArray, long aDstIndex,
			object[] aSrcArray, long aSrcIndex,
			long aMoveItemsCount
		) {
			if (aDstArray == aSrcArray) 
			{
				// moving items in the same array - in place move
				if (aDstIndex > aSrcIndex)
					return MoveRight (aDstArray, aDstIndex, aSrcArray, aSrcIndex, aMoveItemsCount);
				else
					return MoveLeft (aDstArray, aDstIndex, aSrcArray, aSrcIndex, aMoveItemsCount);
			}
			else
				return MoveLeft (aDstArray, aDstIndex, aSrcArray, aSrcIndex, aMoveItemsCount);
		}

//=======================================================================================

		// ==============
		// in-place moves (inside the same array)

		/*/ moveLeft, moveRight
			this version moves data inside the same array
		/*/

		public static object[] MoveLeft (
			object[] aSrcDstArray,
			long aDstIndex, long aSrcIndex,
			long aMoveItemsCount
		) {
			return MoveLeft (
				aSrcDstArray, aDstIndex,
				aSrcDstArray, aSrcIndex,
				aMoveItemsCount
			);
		}

		public static object[] MoveRight (
			object[] aSrcDstArray,
			long aDstIndex, long aSrcIndex,
			long aMoveItemsCount
		) {
			return MoveRight (
				aSrcDstArray, aDstIndex,
				aSrcDstArray, aSrcIndex,
				aMoveItemsCount
			);
		}

		/*/ move
			automatically decide whether to move left or right
			inside the same array - in place move
		/*/

		public static object[] Move (
			object[] aSrcDstArray,
			long aDstIndex, long aSrcIndex,
			long aMoveItemsCount
		) {
			if (aDstIndex > aSrcIndex)
				return MoveRight (aSrcDstArray, aDstIndex, aSrcIndex, aMoveItemsCount);
			else
				return MoveLeft (aSrcDstArray, aDstIndex, aSrcIndex, aMoveItemsCount);
		}

//=======================================================================================
// Inserting / Deleting Array Items

		// insert shift

		public static object[] InsertShift (
			object[] aDataItemsArray,
			long aOldItemsCount,
			long aInsIndex,
			long aInsItemsCount,
			bool wantClear
		) {
			{ // range checking
				if (aInsIndex < 0L) 
				{
					aInsItemsCount += aInsIndex;
					aInsIndex = 0L;
				}
				if (aInsIndex > aOldItemsCount)
					// do nothing & return
					return aDataItemsArray;
			}

			// insert shift
			MoveRight (
				aDataItemsArray,
				/*/DST/*/ (aInsIndex + aInsItemsCount),
				/*/SRC/*/ aInsIndex,
				/*/COUNT/*/ (aOldItemsCount - aInsIndex)
			);

			if (wantClear)
				Clear (
					aDataItemsArray, 
					/*/CLEAR-INDEX/*/ aInsIndex, 
					/*/COUNT/*/ aInsItemsCount
				);
			//end if

			// done!
			return aDataItemsArray;
		}

		// delete shift

		public static object[] DeleteShift (
			object[] aDataItemsArray,
			long aOldItemsCount,
			long aDelIndex,
			long aDelItemsCount,
			bool wantClear
		) {
			{ // range checking
				if (aDelIndex < 0L) 
				{
					// aDelIndex is negative
					// subtract aDelIndex from aDelItemsCount
					//aDelItemsCount = aDelItemsCount + aDelIndex;
					aDelItemsCount += aDelIndex;
					// delete from the first item
					aDelIndex = 0L;
				}
				if (aDelIndex >= aOldItemsCount)
					// aDelIndex is out of range: do nothing & return
					return aDataItemsArray;
				if ((aDelIndex + aDelItemsCount) > aOldItemsCount)
					// >> aDelItemsCount is out of bounds: clip it !!
					aDelItemsCount = aOldItemsCount - aDelIndex;
			}

			// delete shift
			MoveLeft (
				aDataItemsArray,
				/*/DST/*/ aDelIndex,
				/*/SRC/*/ (aDelIndex + aDelItemsCount),
				/*/COUNT/*/ (aOldItemsCount - (aDelIndex + aDelItemsCount))
			);

			if (wantClear)
				Clear (
					aDataItemsArray, 
					/*/CLEAR-INDEX/*/ (aOldItemsCount - aDelItemsCount), 
					/*/COUNT/*/ aDelItemsCount
				);
			//end if

			// done!
			return aDataItemsArray;
		}

//=======================================================================================

	} // ArrayUtils

//=======================================================================================

}

// that's all folks ...
