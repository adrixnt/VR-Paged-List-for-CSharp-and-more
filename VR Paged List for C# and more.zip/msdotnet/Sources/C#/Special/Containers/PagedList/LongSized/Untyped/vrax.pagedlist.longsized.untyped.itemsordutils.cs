
/*/
namespace VRAdrixNT.Containers.PagedList.ItemsOrderUtils.RangeCheckUtils
{
	public sealed class VRRangeCheck
	{
		private VRRangeCheck() {}

		public static bool IsItemIndexValid (long aIndex, long aRangeIndex, long aRangeCount)
		{
			return
				(aIndex >= aRangeIndex) &&
				(aIndex < (aRangeIndex + aRangeCount))
				;
		}

	}

}

	//using VRAdrixNT.Containers.PagedList.ItemsOrderUtils.RangeCheckUtils;

/*/


namespace VRAdrixNT.Containers.PagedList.LongSized.Untyped.ItemsOrderUtils
{

	using VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main;

	// replace the following ...

	//using IVRPLItemWithItemComparator = VRAdrixNT.Containers.PagedList.Main.IVRPLItemComparator;
	//using IVRPLKeyWithItemComparator = VRAdrixNT.Containers.PagedList.Main.IVRPLItemComparator;

	// ... with IVRPLItemComparator

	using VRAdrixNT.Utils.RangeCheck;

public sealed class VRPListItemsOrdUtils
{
	private VRPListItemsOrdUtils() {} // class module;

//=======================================================================================
// Checking a List Range Order
//=======================================================================================

#region Checking a List Range Order

	// to Check an Item's Range for Ascending Order

	public static bool IsAscendingOrdered (
		VRPagedList aList,
		long aChkItemIndex,	// starting check index
		long aChkItemsCount,	// items to check count
		IVRPLItemComparator aCompareItemsProc
	) {
		// insert range check
		aList.CheckValidInsertRange (aChkItemIndex, aChkItemsCount);
		// ok!
		VRPagedListIterator itemIter = new VRPagedListIterator (aList, aChkItemIndex);
		long aIndex = 0L;
		// next [++]
		itemIter.Next(); // ++ next item
		++ aIndex; //++
		while (aIndex < aChkItemsCount) {
			// get current item
			object aItem = itemIter.Item;
			// get prev item
			object prevItem = itemIter.GetPrevItem();
			// compare ...
			int cmpResult = aList.Compare (
				aCompareItemsProc,
				prevItem, aItem
			);
			if (cmpResult > 0)
				// prevItem > aItem
				return false;
				// the list range is NOT in Ascending Order
			//else
				// prevItem <= aItem
				// continue ...
			//end if
			// next ...
			itemIter.Next(); // ++ next item
			++ aIndex; // ++
		}//loop
		// ok! the list range is in Ascending Order
		return true;
	}

	// to Check an Item's Range for Descending Order

	public static bool IsDescendingOrdered (
		VRPagedList aList,
		long aChkItemIndex,	// starting check index
		long aChkItemsCount,	// items to check count
		IVRPLItemComparator aCompareItemsProc
	) {
		// insert range check
		aList.CheckValidInsertRange (aChkItemIndex, aChkItemsCount);
		// ok!
		VRPagedListIterator itemIter = new VRPagedListIterator (aList, aChkItemIndex);
		long aIndex = 0L;
		// next [++]
		itemIter.Next(); // next item
		++ aIndex;
		while (aIndex < aChkItemsCount) {
			// get current item
			object aItem = itemIter.Item;
			// get prev item
			object prevItem = itemIter.GetPrevItem();

			// compare ...
			int cmpResult = aList.Compare (
				aCompareItemsProc,
				prevItem, aItem
			);
			if (cmpResult < 0)
				// prevItem < aItem
				return false;
				// the list range is NOT in Descending Order
			//else
				// prevItem >= aItem
				// continue ...
			//end if
			itemIter.Next(); // next item
			++ aIndex;
		}//loop
		// ok! the list range is in Descending Order
		return true;
	}

	// to compute the range order type

	// order type

	public static int ComputeOrderType (
		VRPagedList aList,
		long aChkItemIndex,	// starting check index
		long aChkItemsCount,	// items to check count
		IVRPLItemComparator aCompareItemsProc,
		int aDefaultOrderType
	) {
		// get Ascending Order State
		bool isInAscOrd = IsAscendingOrdered (
			aList, aChkItemIndex, aChkItemsCount, aCompareItemsProc
		);

		// get Descending Order State
		bool isInDesOrd = IsDescendingOrdered (
			aList, aChkItemIndex, aChkItemsCount, aCompareItemsProc
		);

		if ((isInAscOrd) && (isInDesOrd))
			// Asc-Ord State == Des-Ord State
			// assume no specific order - assume it is unordered
			// return the default order code
			return aDefaultOrderType; // (0);
		else
		if (isInAscOrd)
			// this range is in Ascending order
			return (+1);
		else
		if (isInDesOrd)
			// this range is in Descending order
			return (-1);
		else
			// this range is unordered
			return (0); // unordered
		//end if
	}

	// (0) default

	public static int ComputeOrderType (
		VRPagedList aList,
		long aChkItemIndex,	// starting check index
		long aChkItemsCount,	// items to check count
		IVRPLItemComparator aCompareItemsProc
	) {
		return ComputeOrderType (aList, aChkItemIndex, aChkItemsCount, aCompareItemsProc, (0));
	}

	// any order ?

	public static bool AnyOrder (
		VRPagedList aList,
		long aChkItemIndex,	// starting check index
		long aChkItemsCount,	// items to check count
		IVRPLItemComparator aCompareItemsProc
	) {
		return ComputeOrderType (aList, aChkItemIndex, aChkItemsCount, aCompareItemsProc) != (0) ;
	}

	// test

	public static bool IsOrdered (
		VRPagedList aList,
		long aChkItemIndex,	// starting check index
		long aChkItemsCount,	// items to check count
		//bool checkForAscendingOrder,
		int aOrderType,
		IVRPLItemComparator aCompareItemsProc
	) {
		if (aOrderType > 0)
			// test: Ascending Order
			return IsAscendingOrdered (
				aList, aChkItemIndex, aChkItemsCount, aCompareItemsProc
			);
		else
		if (aOrderType < 0)
			// test: Descending Order
			return IsDescendingOrdered (
				aList, aChkItemIndex, aChkItemsCount, aCompareItemsProc
			);
		else
		// (aOrderType == 0)
			// test: any Order
			return AnyOrder (
				aList, aChkItemIndex, aChkItemsCount, aCompareItemsProc
			);
		//end if
	}

#endregion

//=======================================================================================
// Checking the whole paged-list order
//=======================================================================================

#region Checking the whole paged-list order

	// Ascending Order ?

	public static bool IsAscendingOrdered (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc
	) {
		return IsAscendingOrdered (aList, 0L, aList.ItemsCount, aCompareItemsProc);
	}

	// Descending Order ?

	public static bool IsDescendingOrdered (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc
	) {
		return IsDescendingOrdered (aList, 0L, aList.ItemsCount, aCompareItemsProc);
	}

	// order type

	public static int ComputeOrderType (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc,
		int aDefaultOrderType
	) {
		return ComputeOrderType (
			aList, 0L, aList.ItemsCount,
			aCompareItemsProc,
			aDefaultOrderType
		);
	}

	// default to (0)

	public static int ComputeOrderType (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc
	) {
		return ComputeOrderType (aList, aCompareItemsProc, (0));
	}

	// any order ?

	public static bool AnyOrder (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc
	) {
		return ComputeOrderType (aList, aCompareItemsProc) != (0) ;
	}

	// test

	public static bool IsOrdered (
		VRPagedList aList,
		//bool checkForAscendingOrder,
		int aOrderType,
		IVRPLItemComparator aCompareItemsProc
	) {
		return IsOrdered (
			aList, 0L, aList.ItemsCount,
			aOrderType,
			aCompareItemsProc
		);
	}


#endregion

//=======================================================================================
// Checking List Auto Order
//=======================================================================================

#region Checking List Auto Order

	// Check for Auto Ascending Order

	public static bool IsAutoAscendingOrdered (VRPagedList aList)
	{
		IVRPLItemComparator aItemCompareFunc = aList.ItemToItemComparator;
		// start with the second item (if any)
		VRPagedListIterator itemIter = new VRPagedListIterator (aList, 1L);
		while (itemIter.IsItemIndexValid())
		{
			// get items
			object aItem = itemIter.Item;
			// get the prev item!
			object prevItem = itemIter.GetPrevItem();
			// compare
			int cmpResult = aList.Compare (
				aItemCompareFunc, prevItem, aItem
			);
			if (cmpResult > 0)
				// prevItem > aItem
				return false;
				// the list range is NOT in Ascending Order
			//else
				// prevItem <= aItem
				// continue ...
			//end if
			// next
			++ itemIter;
		}
		return true;
	}

	// Check for Auto Descending Order

	public static bool IsAutoDescendingOrdered (VRPagedList aList)
	{
		IVRPLItemComparator aItemCompareFunc = aList.ItemToItemComparator;
		// start with the second item (if any)
		VRPagedListIterator itemIter = new VRPagedListIterator (aList, 1L);
		while (itemIter.IsItemIndexValid())
		{
			// get items
			object aItem = itemIter.Item;
			// get the prev item!
			object prevItem = itemIter.GetPrevItem();
			// compare
			int cmpResult = aList.Compare (
				aItemCompareFunc, prevItem, aItem
			);
			if (cmpResult < 0)
				// prevItem < aItem
				return false;
				// the list range is NOT in Descending Order
			//else
				// prevItem >= aItem
				// continue ...
			//end if
			// next
			++ itemIter;
		}
		return true;
	}

	// computing the auto order code

	public static int ComputeAutoOrderType (VRPagedList aList, int aDefaultCode)
	{
		bool isInAscOrd = IsAutoAscendingOrdered (aList);
		bool isInDesOrd = IsAutoDescendingOrdered (aList);
		if (isInAscOrd && isInDesOrd)
			// it is both in (Ascending|Descending) Order
			return (aDefaultCode);
		else
		if (isInAscOrd)
			// it is in Ascending Order
			return (+1);
		else
		if (isInDesOrd)
			// it is in Descending Order
			return (-1);
		else
			// unordered
			return (0);
		//end if
	}

	// overload

	public static int ComputeAutoOrderType (VRPagedList aList)
	{
		return ComputeAutoOrderType (aList, (0));
	}

	// any auto order ?

	public static bool AnyAutoOrder (VRPagedList aList)
	{
		return ComputeAutoOrderType (aList) != (0);
	}

	// test ASC|DES Order

	public static bool IsAutoOrdered (VRPagedList aList, int aOrderType)
	{
		if (aOrderType > 0)
			// test auto ASC Order
			return IsAutoAscendingOrdered (aList);
		else
		if (aOrderType < 0)
			// test auto DES Order
			return IsAutoDescendingOrdered (aList);
		else
			// test any order
			return AnyAutoOrder (aList);
		//end if
	}

#endregion

//=======================================================================================
// Reversing List Items
//=======================================================================================

	// this is called each time an item is swapped with another one

	public delegate void VRPLSwapItemsFeedback (
		VRPagedList aList,
		long aItemAIndex,
		long aItemBIndex
	);

//=======================================================================================

#region Reversing List Items

	// to reverse a range of items

	public static void Reverse (
		VRPagedList aList,
		long aStartingIndex,
		long aItemsCount,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		// insert range check
		aList.CheckValidInsertRange (aStartingIndex, aItemsCount);
		// ok!
		aList.CheckUnorderedList();
		// ok!
		VRPagedListIterator aLoIter = new VRPagedListIterator (aList, aStartingIndex);
		VRPagedListIterator aHiIter = new VRPagedListIterator (aList, aStartingIndex + (aItemsCount - 1L));
		while (aLoIter < aHiIter) {
			// lock changes notifications
			aList.LockListChangedEvent();
			try {
				// swap (*aLoIter, *aHiIter);
				VRPagedListIterator.SwapItems (aLoIter, aHiIter);
				// list changed!
				// invoke the swap step proc (if any)
				if (aSwapStepProc != null)
					aSwapStepProc (aList, aLoIter.Index, aHiIter.Index);
				//end if
			} finally {
				// unlock changes notifications
				aList.UnlockListChangedEvent();
			}
			// next/prev
			++ aLoIter;
			-- aHiIter;
		}
		// done!
	}

	// overloads

	public static void Reverse (
		VRPagedList aList,
		long aStartingIndex,
		long aItemsCount
	) {
		Reverse (aList, aStartingIndex, aItemsCount, null);
	}

	// to reverse the whole list

	// overloads

	public static void Reverse (
		VRPagedList aList,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		Reverse (aList, (0L), aList.ItemsCount, aSwapStepProc);
		// ok!
	}

	// overloads

	public static void Reverse (VRPagedList aList)
	{
		Reverse (aList, null);
	}

#endregion

//=======================================================================================
// Changing the Item's Auto Order
//=======================================================================================

#region Changing the Item's Auto Order

	// to reverse the items auto order

	public static void ReverseAutoOrder (
		VRPagedList aList,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		// get the old order type
		int aOldOrderType = aList.AutoOrderType;

		if (aOldOrderType != 0) {
			// ASC <==> DES

			// set it as unordered!
			aList.AutoOrderType = (0);
			// success!

			// reverse items
			Reverse (aList, 0L, aList.ItemsCount, aSwapStepProc);
		}//end if

		// reverse the old order type
		aList.AutoOrderType = ( - aOldOrderType );

		// done!
		return;
	}

	// overload
	public static void ReverseAutoOrder (VRPagedList aList)
	{
		ReverseAutoOrder (aList, null);
	}


	// to turn to auto ascending order

	public static void TurnToAutoAscendingOrder (
		VRPagedList aList,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		// get the old order type
		int aOldOrderType = aList.AutoOrderType;

		if (aOldOrderType > 0) return;

		if (aOldOrderType < 0) {
			// it was Descending: turn to Ascending

			// set it as unordered!
			aList.AutoOrderType = (0);

			// reverse items
			Reverse (aList, 0L, aList.Size, aSwapStepProc);
		}//end if

		// turn to Ascending
		aList.AutoOrderType = (+1);
	}

	// overload
	public static void TurnToAutoAscendingOrder (VRPagedList aList)
	{
		TurnToAutoAscendingOrder (aList, null);
	}

	// to turn to auto descending order

	public static void TurnToAutoDescendingOrder (
		VRPagedList aList,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		// get the old order type
		int aOldOrderType = aList.AutoOrderType;

		if (aOldOrderType < 0) return;

		if (aOldOrderType > 0) {
			// it was Ascending: turn to Descending

			// set it as unordered!
			aList.AutoOrderType = (0);

			// reverse items
			Reverse (aList, 0L, aList.Size, aSwapStepProc);
		}//end if

		// turn to Descending
		aList.AutoOrderType = (-1);
	}

	// overload
	public static void TurnToAutoDescendingOrder (VRPagedList aList)
	{
		TurnToAutoDescendingOrder (aList, null);
	}


	// to change the auto-order

	public static void ChangeAutoOrder (
		VRPagedList aList,
		int aNewOrderType,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		if (aNewOrderType < 0)
			// DES
			TurnToAutoDescendingOrder (aList, aSwapStepProc);
		else
		if (aNewOrderType > 0)
			// ASC
			TurnToAutoAscendingOrder (aList, aSwapStepProc);
		//else
		// (aNewOrderType == 0) !!
			// do nothing
			//;
		//end if

		// try to set new order type!
		aList.AutoOrderType = (aNewOrderType);
	}

	// overload
	public static void ChangeAutoOrder (VRPagedList aList, int aNewOrderType)
	{
		ChangeAutoOrder (aList, aNewOrderType, null);
	}

//=======================================================================================
/*/
	// param true/false

	public static void TurnToAutoAscendingOrderItems (
		VRPagedList aList,
		bool setIt,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		if (setIt)
			TurnToAutoAscendingOrderItems (aList, aSwapStepProc);
		else
			TurnToAutoDescendingOrderItems (aList, aSwapStepProc);
		//end if
	}
	// overload
	public static void TurnToAutoAscendingOrderItems (VRPagedList aList, bool setIt)
	{
		TurnToAutoAscendingOrderItems (aList, setIt, null);
	}

	public static void TurnToAutoDescendingOrderItems (
		VRPagedList aList,
		bool setIt,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		if (setIt)
			TurnToAutoDescendingOrderItems (aList, aSwapStepProc);
		else
			TurnToAutoAscendingOrderItems (aList, aSwapStepProc);
		//end if
	}
	// overload
	public static void TurnToAutoDescendingOrderItems (VRPagedList aList, bool setIt)
	{
		TurnToAutoDescendingOrderItems (aList, setIt, null);
	}
/*/
//=======================================================================================

#endregion

//=======================================================================================


//=======================================================================================
// Quick Sort
//=======================================================================================


#region Quick Sort

//=======================================================================================
// Quick Sort :: unchecked procs
//=======================================================================================

#region Quick Sort :: unchecked procs

	// to Sort Items in Ascending Order

	// Unchecked Ascending Order QuickSort

	// UncheckedAscendingOrderQuickSort

	// old: QuickSortItemsAsc

	private static void UncheckedAscendingOrderQuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		//if (aSortItemsCount <= 1L) return;
		// assert: (aSortItemsCount >= 2) !!

		long iIterIndex = 0L;
		long jIterIndex = 0L;

		{ // begin block
			VRPagedListIterator iIter = new VRPagedListIterator (aList, aSortItemIndex);
			VRPagedListIterator jIter = new VRPagedListIterator (aList, (aSortItemIndex + aSortItemsCount) - 1L);
			//
			VRPagedListIterator midIter = new VRPagedListIterator (aList, (aSortItemsCount / 2L) + aSortItemIndex);
			//do {
			while (iIter.Index < jIter.Index)
			{

				// make a copy of mid item
				object midItem = midIter.Item; // xitem

				int cmpResultInf = 0;
				int cmpResultSup = 0;

				// inferior part: find next "i" such as "abase[i] >= xitem"
				while (true) {
					cmpResultInf = aList.Compare (
						aCompareItemsProc,
						iIter.Item, midItem
					);
					if (cmpResultInf >= 0)
						// abase[i] >= xitem
						break;
					//end if
					iIter.Next(); // ++ iIter
				}//repeat

				// superior part: find next "j" such as "abase[j] <= xitem"
				while (true) {
					cmpResultSup = aList.Compare ( //callCompareItemWithItemFunc (
						aCompareItemsProc,
						jIter.Item, midItem
					);
					if (cmpResultSup <= 0)
						// abase[j] <= xitem
						break;
					//end if
					jIter.Prev(); // -- jIter
				}//repeat

				if (iIter.Index <= jIter.Index) {
					// swap items (i,j) only if they are different ones
					if (iIter.Index != jIter.Index) {
						// if (a[i] == mid) && (a[j] == mid) then (a[i] == a[j]) : do not swap!
						if ( ! ((cmpResultInf == 0) && (cmpResultSup == 0)) ) {

							// swap (a[i], a[j]) !!
							aList.LockListChangedEvent();
							try {
								VRPagedListIterator.SwapItems (iIter, jIter);
							} finally {
								aList.UnlockListChangedEvent();
							}
							// give feedback
							if (aSwapStepProc != null)
								//try {
								aSwapStepProc (aList, iIter.Index, jIter.Index);
								//} catch (Exception) { /*/eat/*/ }
							//end if

						}//end if
					}//end if

					/*/
					if (iIter.CurrentIndex == midIter.CurrentIndex) // (iIter == midIter) ?
						midIter.CurrentIndex = jIter.CurrentIndex; // midIter = jIter
					else
					if (jIter.CurrentIndex == midIter.CurrentIndex) // (jIter == midIter) ?
						midIter.CurrentIndex = iIter.CurrentIndex; // midIter = iIter;
					//end if
					/*/

					iIter.Next(); // ++ iIter;
					jIter.Prev(); // -- jIter;

				}//end if

			} // repeat
			//} while (iIter.CurrentIndex < jIter.CurrentIndex);

			iIterIndex = iIter.Index;
			jIterIndex = jIter.Index;

		} // end block

		// sort inferior part
		if (jIterIndex > aSortItemIndex)

			UncheckedAscendingOrderQuickSort (
				aList,
				aSortItemIndex, (jIterIndex - aSortItemIndex + 1L),
				aCompareItemsProc,
				aSwapStepProc
			);

		//end if

		// sort superior part
		//if (iIterIndex < (aSortItemIndex + aSortItemsCount))
		if (iIterIndex < (aSortItemIndex + aSortItemsCount - 1L))

			UncheckedAscendingOrderQuickSort (
				aList,
				iIterIndex, (aSortItemIndex + aSortItemsCount - iIterIndex),
				aCompareItemsProc,
				aSwapStepProc
			);

		//end if

		// ok!
	}

//=======================================================================================

	// to Sort Items in Descending Order

	// Unchecked Descending Order QuickSort

	// UncheckedDescendingOrderQuickSort

	// old: QuickSortItemsDes

	private static void UncheckedDescendingOrderQuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		//if (aSortItemsCount <= 1L) return;
		// assert: (aSortItemsCount >= 2) !!

		long iIterIndex = 0L;
		long jIterIndex = 0L;

		{ // begin block
			VRPagedListIterator iIter = new VRPagedListIterator (aList, aSortItemIndex);
			VRPagedListIterator jIter = new VRPagedListIterator (aList, (aSortItemIndex + aSortItemsCount) - 1L);
			//
			VRPagedListIterator midIter = new VRPagedListIterator (aList, (aSortItemsCount / 2L) + aSortItemIndex);
			//do {
			while (iIter.Index < jIter.Index)
			{

				// make a copy of mid item
				object midItem = midIter.Item; // xitem

				int cmpResultInf = 0;
				int cmpResultSup = 0;

				// inferior part: find next "i" such as "abase[i] >= xitem"
				while (true) {
					cmpResultInf = aList.Compare ( //callCompareItemWithItemFunc (
						aCompareItemsProc,
						iIter.Item, midItem
					);
					if (cmpResultInf <= 0)
						// abase[i] <= xitem
						break;
					//end if
					iIter.Next(); // ++ iIter
				}//repeat

				// superior part: find next "j" such as "abase[j] <= xitem"
				while (true) {
					cmpResultSup = aList.Compare ( //callCompareItemWithItemFunc (
						aCompareItemsProc,
						jIter.Item, midItem
					);
					if (cmpResultSup >= 0)
						// abase[j] >= xitem
						break;
					//end if
					jIter.Prev(); // -- jIter
				}//repeat

				if (iIter.Index <= jIter.Index) {
					// swap items (i,j) only if they are different ones
					if (iIter.Index != jIter.Index) {
						// if (a[i] == mid) && (a[j] == mid) then (a[i] == a[j]) : do not swap!
						if ( ! ((cmpResultInf == 0) && (cmpResultSup == 0)) ) {

							// swap (a[i], a[j]) !!
							aList.LockListChangedEvent();
							try {
								VRPagedListIterator.SwapItems (iIter, jIter);
							} finally {
								aList.UnlockListChangedEvent();
							}
							// give feedback
							if (aSwapStepProc != null)
								//try {
								aSwapStepProc (aList, iIter.Index, jIter.Index);
								//} catch (Exception) { /*/eat/*/ }
							//end if

						}//end if
					}//end if

					/*/
					if (iIter.CurrentIndex == midIter.CurrentIndex) // (iIter == midIter) ?
						midIter.CurrentIndex = jIter.CurrentIndex; // midIter = jIter
					else
					if (jIter.CurrentIndex == midIter.CurrentIndex) // (jIter == midIter) ?
						midIter.CurrentIndex = iIter.CurrentIndex; // midIter = iIter;
					//end if
					/*/

					iIter.Next(); // ++ iIter;
					jIter.Prev(); // -- jIter;

				}//end if

			} // repeat
			//} while (iIter.CurrentIndex < jIter.CurrentIndex);

			iIterIndex = iIter.Index;
			jIterIndex = jIter.Index;

		} // end block

		// sort inferior part
		if (jIterIndex > aSortItemIndex)

			UncheckedDescendingOrderQuickSort (
				aList,
				aSortItemIndex, (jIterIndex - aSortItemIndex + 1L),
				aCompareItemsProc,
				aSwapStepProc
			);

		//end if

		// sort superior part
		//if (iIterIndex < (aSortItemIndex + aSortItemsCount))
		if (iIterIndex < (aSortItemIndex + aSortItemsCount - 1L))

			UncheckedDescendingOrderQuickSort (
				aList,
				iIterIndex, (aSortItemIndex + aSortItemsCount - iIterIndex),
				aCompareItemsProc,
				aSwapStepProc
			);

		//end if

		// ok!
	}

#endregion

//=======================================================================================
// Quick Sort :: checked procs
//=======================================================================================

#region Quick Sort Range

	// Ascending Quick Sort Range

	// AscendingOrderQuickSort

	// old: QuickSortRangeAscending

	public static void AscendingOrderQuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		// insert range check
		aList.CheckValidInsertRange (aSortItemIndex, aSortItemsCount);
		// ok!
		aList.CheckUnorderedList();
		// ok!
		// ascending quick-sort
		UncheckedAscendingOrderQuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			aCompareItemsProc,
			aSwapStepProc
		);
	}

	// overloads

	public static void AscendingOrderQuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		IVRPLItemComparator aCompareItemsProc
	) {
		AscendingOrderQuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			aCompareItemsProc,
			null
		);
	}

	public static void AscendingOrderQuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount // items to sort count
	) {
		AscendingOrderQuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			null
		);
	}

//=======================================================================================

	// Descending Quick Sort Range

	// DescendingOrderQuickSort

	// old: QuickSortRangeDescending

	public static void DescendingOrderQuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		// insert range check
		aList.CheckValidInsertRange (aSortItemIndex, aSortItemsCount);
		// ok!
		aList.CheckUnorderedList();
		// ok!
		// descending quick-sort
		UncheckedDescendingOrderQuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			aCompareItemsProc,
			aSwapStepProc
		);
	}

	// overloads

	public static void DescendingOrderQuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		IVRPLItemComparator aCompareItemsProc
	) {
		DescendingOrderQuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			aCompareItemsProc,
			null
		);
	}

	public static void DescendingOrderQuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount // items to sort count
	) {
		DescendingOrderQuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			null
		);
	}

//=======================================================================================

	// Sorting a Range of Items - choose Asc/Des Ord

	// QuickSort

	// old: QuickSortRange

	// Sorting a Range of Items - choose Asc/Des Ord

	public static void QuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		int aOrderType,
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		if (aOrderType > 0)
			// Asc
			AscendingOrderQuickSort (
				aList, aSortItemIndex, aSortItemsCount,
				aCompareItemsProc,
				aSwapStepProc
			);
		else
		if (aOrderType < 0)
			// Des
			DescendingOrderQuickSort (
				aList, aSortItemIndex, aSortItemsCount,
				aCompareItemsProc,
				aSwapStepProc
			);
		else
			return;
		//end if
	}

	// overloads

	public static void QuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		int aOrderType,
		IVRPLItemComparator aCompareItemsProc
	) {
		QuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			aOrderType,
			aCompareItemsProc,
			null
		);
	}

	public static void QuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		int aOrderType
	) {
		QuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			aOrderType,
			null
		);
	}

//=======================================================================================

/*/
	public static void QuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		bool sortInAscendingOrder,
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		if (sortInAscendingOrder)
			// Ascending Order was requested
			AscendingOrderQuickSort (
				aList, aSortItemIndex, aSortItemsCount,
				aCompareItemsProc,
				aSwapStepProc
			);
		else
			// Descending Order was requested
			DescendingOrderQuickSort (
				aList, aSortItemIndex, aSortItemsCount,
				aCompareItemsProc,
				aSwapStepProc
			);
		//end if
	}

	// overloads

	public static void QuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		bool sortInAscendingOrder,
		IVRPLItemComparator aCompareItemsProc
	) {
		QuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			sortInAscendingOrder,
			aCompareItemsProc,
			null
		);
	}

	public static void QuickSort (
		VRPagedList aList,
		long aSortItemIndex,  // starting sort index
		long aSortItemsCount, // items to sort count
		bool sortInAscendingOrder
	) {
		QuickSort (
			aList, aSortItemIndex, aSortItemsCount,
			sortInAscendingOrder,
			null
		);
	}
/*/


#endregion


//=======================================================================================
// Sorting the whole List
//=======================================================================================

#region Sorting the whole List

	// Sorting All Items - Ascending

	// AscendingOrderQuickSort

	// old: QuickSortItemsAscending

	public static void AscendingOrderQuickSort (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		AscendingOrderQuickSort (
			aList, 0L, aList.ItemsCount,
			aCompareItemsProc,
			aSwapStepProc
		);
	}

	// overloads

	public static void AscendingOrderQuickSort (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc
	) {
		AscendingOrderQuickSort (aList, aCompareItemsProc, null);
	}

	public static void AscendingOrderQuickSort (VRPagedList aList)
	{
		AscendingOrderQuickSort (aList, null);
	}


	// Sorting All Items - Descending

	// DescendingOrderQuickSort

	// old: QuickSortItemsDescending

	public static void DescendingOrderQuickSort (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		DescendingOrderQuickSort (
			aList, 0L, aList.ItemsCount,
			aCompareItemsProc,
			aSwapStepProc
		);
	}

	// overloads

	public static void DescendingOrderQuickSort (
		VRPagedList aList,
		IVRPLItemComparator aCompareItemsProc
	) {
		DescendingOrderQuickSort (aList, aCompareItemsProc, null);
	}

	public static void DescendingOrderQuickSort (VRPagedList aList)
	{
		DescendingOrderQuickSort (aList, null);
	}


//=======================================================================================


	// Sorting All Items - choose (Asc|Des) Ord

	// QuickSort

	// old: QuickSortItems

	public static void QuickSort (
		VRPagedList aList,
		int aOrderType,
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		if (aOrderType > 0)
			// Ascending Order
			AscendingOrderQuickSort (aList, aCompareItemsProc, aSwapStepProc);
		else
		if (aOrderType < 0)
			// Descending Order
			DescendingOrderQuickSort (aList, aCompareItemsProc, aSwapStepProc);
		//end if
	}

	// overloads

	public static void QuickSort (
		VRPagedList aList,
		int aOrderType,
		IVRPLItemComparator aCompareItemsProc
	) {
		QuickSort (aList, aOrderType, aCompareItemsProc, null);
	}

	public static void QuickSort (
		VRPagedList aList,
		int aOrderType
	) {
		QuickSort (aList, aOrderType, null);
	}


//=======================================================================================
/*/

	// Sorting All Items - choose (Asc|Des) Ord

	public static void QuickSort (
		VRPagedList aList,
		bool sortInAscendingOrder,
		IVRPLItemComparator aCompareItemsProc,
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		if (sortInAscendingOrder)
			// Ascending Order was requested
			AscendingOrderQuickSort (aList, aCompareItemsProc, aSwapStepProc);
		else
			// Descending Order was requested
			DescendingOrderQuickSort (aList, aCompareItemsProc, aSwapStepProc);
		//end if
	}

	// overloads

	public static void QuickSort (
		VRPagedList aList,
		bool sortInAscendingOrder,
		IVRPLItemComparator aCompareItemsProc
	) {
		QuickSort (aList, sortInAscendingOrder, aCompareItemsProc, null);
	}

	public static void QuickSort (
		VRPagedList aList,
		bool sortInAscendingOrder
	) {
		QuickSort (aList, sortInAscendingOrder, null);
	}

/*/
//=======================================================================================

#endregion

//=======================================================================================


//=======================================================================================
// changing the Auto-Order State of a list
//=======================================================================================

#region changing the Auto Order State of a List

	/*/ ChangeAutoOrderState

		also changes the auto-order comparator procs

		warning: the "DuplicatesMode" of the list
		is NOT Changed by these procs !!
		you have to change it yourself !!
	/*/

	public static void ChangeAutoOrderState (
		VRPagedList aList,
		int aNewOrderType, // the new order type
		// comparators info
		IVRPLItemComparator aCompareItemProc,
		IVRPLItemComparator aCompareKeyProc,
		// swap items proc
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		// clear the auto-order compare funcs
		aList.ItemToItemComparator = null;
		aList.KeyToItemComparator = null;
		// set it as not auto ordered
		aList.AutoOrderType = (0);

		// sort as needed	...
		if (aNewOrderType > 0)
			// Ascending Order
			AscendingOrderQuickSort (
				aList,
				aCompareItemProc,
				aSwapStepProc
			);
		else
		if (aNewOrderType < 0)
			// Descending Order
			DescendingOrderQuickSort (
				aList,
				aCompareItemProc,
				aSwapStepProc
			);
		//else
			//; // do nothing!
		//end if

		// set the new auto order type
		aList.AutoOrderType = (aNewOrderType);
		// set the new comparators ...
		aList.ItemToItemComparator = aCompareItemProc;
		aList.KeyToItemComparator = aCompareKeyProc;
		// done!
	}

//=======================================================================================

	// overloads

	public static void ChangeAutoOrderState (
		VRPagedList aList,
		int aNewOrderType, // the new order type
		// comparators info
		IVRPLItemComparator aCompareItemProc,
		IVRPLItemComparator aCompareKeyProc
	) {
		ChangeAutoOrderState (
			aList,
			aNewOrderType,
			aCompareItemProc, aCompareKeyProc,
			null
		);
	}

//=======================================================================================

	/*/
		the following will preserve the current auto order type
	/*/

	public static void ChangeAutoOrderState (
		VRPagedList aList,
		// comparators info
		IVRPLItemComparator aCompareItemProc,
		IVRPLItemComparator aCompareKeyProc,
		// swap items proc
		VRPLSwapItemsFeedback aSwapStepProc
	) {
		ChangeAutoOrderState (
			aList,
			// the same old order type
			aList.AutoOrderType,
			// the new order procs
			aCompareItemProc,
			aCompareKeyProc,
			// swap items proc
			aSwapStepProc
		);
	}

	public static void ChangeAutoOrderState (
		VRPagedList aList,
		// comparators info
		IVRPLItemComparator aCompareItemProc,
		IVRPLItemComparator aCompareKeyProc
	) {
		ChangeAutoOrderState (
			aList,
			aCompareItemProc, aCompareKeyProc,
			null
		);
	}

//=======================================================================================

#endregion

//=======================================================================================

#endregion


//=======================================================================================


//=======================================================================================
// Ordered List Range Binary Search
//=======================================================================================


//=======================================================================================
// binary search correction

#region binary search correction

	/*/ to find the start of a sequence of equal items
		used in direct searches
	/*/

	// Find Last NotEqual Item Index

	// old: FindEqItemsSeqBeginIndex

	private static long FindLastNotEqualItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		long aStartingIndex,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc
	) {
		//long aItemIndex = aStartingIndex - 1L;
		VRPagedListIterator aItemIndex = new VRPagedListIterator(aList, aStartingIndex); // - 1L);
		while (true) {

			if ( ! VRLongRangeCheck.IsItemIndexValid (aItemIndex.Index, aRngIndex, aRngCount) )
				break;

			// get item
			object aItem = aItemIndex.Item; // aList [aItemIndex];

			// compare: aKeyToSearch vs aItem
			int relCmpVal = aList.Compare (aCompareFunc, aKeyValue, aItem);

			if (relCmpVal != 0)
				// (aKey != aVect[i])
				break;

			//else continue
			-- aItemIndex;

		}//repeat
		return aItemIndex.Index; // + 1L;
	}

//=======================================================================================

	/*/ to find the end of a sequence of equal items
		used in reverse searches
	/*/

	// Find First NotEqual Item Index

	// old: FindEqItemsSeqEndIndex

	private static long FindFirstNotEqualItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		long aStartingIndex,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc
	) {
		//long aItemIndex = aStartingIndex + 1L;
		VRPagedListIterator aItemIndex = new VRPagedListIterator(aList, aStartingIndex); // + 1L);
		while (true) {

			if ( ! VRLongRangeCheck.IsItemIndexValid (aItemIndex.Index, aRngIndex, aRngCount) )
				break;

			// get item
			object aItem = aItemIndex.Item; // aList [aItemIndex];

			// compare: aKeyToSearch vs aItem
			int relCmpVal = aList.Compare (aCompareFunc, aKeyValue, aItem);

			if (relCmpVal != 0)
				// (aKey != aVect[i])
				break;

			//else continue
			++ aItemIndex;

		}//repeat
		return aItemIndex.Index; // - 1L;
	}


#endregion


//=======================================================================================
// Ordered Binary Search (basic procs)
//=======================================================================================

#region Ordered Binary Search (basic procs)

	// Ascending Order

	// Find Ascending Ordered Item Index

	// FindAscendingOrderedItemIndex

	// old: BinSearchRangeAscRaw

	public static long FindAscendingOrderedItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode
		bool aFindNearestItemMode,
		bool aReverseSearchMode,
		bool aUseAccurateOrderedSearch
	) {
		// insert range check
		aList.CheckValidInsertRange (aRngIndex, aRngCount);
		// ok!

		bool aFindItemMode = ! aFindNearestItemMode;
		bool aDirectSearchMode = ! aReverseSearchMode;

		long loIndex = aRngIndex;
		long hiIndex = aRngIndex + aRngCount - 1L;

		long midIndex = (-1L);
		bool found = false;

		while (loIndex <= hiIndex) {

			/*/long/*/ midIndex = (loIndex + hiIndex) / 2L;

			// get middle item
			object aItem = aList.GetItemAtIndex (midIndex);

			// compare: aKeyToSearch vs aItem
			int relCmpVal = aList.Compare (aCompareFunc, aKeyToSearch, aItem);

			if (relCmpVal == 0) {
				// (aKey == aVect[mid]): an exact match was found!
				found = true;
				break;
				//return (midIndex);
			}//end if

			// Ascending order
			if (relCmpVal < 0)
				// (aKey < aVect[mid]): search into the lower side
				hiIndex = midIndex - 1L;
			else
				// (aKey > aVect[mid]): search into the upper side
				loIndex = midIndex + 1L;
			//end if

		}//repeat

		long aIndex = (-1L);

		if (found) {

			// found !!
			aIndex = (midIndex);

		} else {

			// an exact match was not found!
			if (aFindItemMode) {
				// find the actual item
				if (aDirectSearchMode)
					// direct
					aIndex = (aRngIndex + aRngCount);
				else
					// reverse
					aIndex = (aRngIndex - 1L); //(hiIndex - loIndex); // aIndex = (-1L);
				//end if
			} else {
				// find the nearest item index
				//if (aSearchMode > (0))
				if (aDirectSearchMode)
					// direct
					// aSearchMode >= (+1) : find the nearest item index in direct mode
					aIndex = (loIndex);
				else
				//if (aSearchMode < (0))
					// reverse
					// aSearchMode <= (-1) : find the nearest item index in reverse mode
					aIndex = (hiIndex);
				//end if
			}//end if

		}//end if

		if (aUseAccurateOrderedSearch) {

			// use accurate ordered search
			if (aDirectSearchMode)
				// direct : <<
				aIndex = FindLastNotEqualItemIndex (
					aList, aRngIndex, aRngCount,
					aIndex - 1L,
					aKeyToSearch, aCompareFunc
				) + 1L;
			else
				// reverse : >>
				aIndex = FindFirstNotEqualItemIndex (
					aList, aRngIndex, aRngCount,
					aIndex + 1L,
					aKeyToSearch, aCompareFunc
				) - 1L;
			//end if

		}//end if

		return aIndex;
	}

//=======================================================================================

	// Descending Order

	// Find Descending Ordered Item Index

	// FindDescendingOrderedItemIndex

	// old: BinSearchRangeDesRaw

	public static long FindDescendingOrderedItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode
		bool aFindNearestItemMode,
		bool aReverseSearchMode,
		bool aUseAccurateOrderedSearch
	) {
		// insert range check
		aList.CheckValidInsertRange(aRngIndex, aRngCount);
		// ok!

		long midIndex = (-1L);
		bool found = false;

		bool aFindItemMode = !aFindNearestItemMode;
		bool aDirectSearchMode = !aReverseSearchMode;

		long loIndex = aRngIndex;
		long hiIndex = aRngIndex + aRngCount - 1L;

		while (loIndex <= hiIndex) {

			/*/long/*/ midIndex = (loIndex + hiIndex) / 2L;

			// get middle item
			object aItem = aList.GetItemAtIndex (midIndex);

			// compare: aKeyToSearch vs aItem
			int relCmpVal = aList.Compare (aCompareFunc, aKeyToSearch, aItem);

			if (relCmpVal == 0) {
				// (aKey == aVect[mid]): an exact match was found!
				found = true;
				break;
				//return (midIndex);
			}//end if

			// Descending order
			if (relCmpVal > 0)
				// (aKey > aVect[mid]): search into the lower side
				hiIndex = midIndex - 1L;
			else
				// (aKey < aVect[mid]): search into the upper side
				loIndex = midIndex + 1L;
			//end if

		}//repeat

		long aIndex = (-1L);

		if (found) {

			// found !!
			aIndex = (midIndex);

		} else {

			// an exact match was not found!

			if (aFindItemMode) {
				// find the actual item
				if (aDirectSearchMode)
					// direct
					aIndex = (aRngIndex + aRngCount);
				else
					// reverse
					// aSearchMode == (0) : an exact match was not found
					aIndex = (aRngIndex - 1L); //(hiIndex - loIndex); // aIndex = (-1L);
				//end if

			} else {
				// find the nearest item index
				if (aDirectSearchMode) // if (aSearchMode > (0))
					// aSearchMode >= (+1) : find the nearest item index in direct mode
					aIndex = (loIndex);
				else
				//if (aSearchMode < (0))
					// aSearchMode <= (-1) : find the nearest item index in reverse mode
					aIndex = (hiIndex);
				//end if
			}//end if

		}//end if

		if (aUseAccurateOrderedSearch) {

			// use accurate ordered search
			if (aDirectSearchMode)
				// direct : <<
				aIndex = FindLastNotEqualItemIndex(
					aList, aRngIndex, aRngCount,
					aIndex - 1L,
					aKeyToSearch, aCompareFunc
				) + 1L;
			else
				// reverse : >>
				aIndex = FindFirstNotEqualItemIndex(
					aList, aRngIndex, aRngCount,
					aIndex + 1L,
					aKeyToSearch, aCompareFunc
				) - 1L;
			//end if

		}//end if

		return aIndex;
	}

//=======================================================================================

	// ( Ascending | Descending ) Order

	// Find Ordered Item Index

	// FindOrderedItemIndex

	// old: BinSearchRangeRaw

	public static long FindOrderedItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode,
		bool aFindNearestItemMode,
		bool aReverseSearchMode,
		int aOrderType,
		bool aUseAccurateOrderedSearch
	) {
		if (aOrderType != 0) {

			// items are Ordered

			if (aOrderType > 0)
				// items are in Ascending Order
				return FindAscendingOrderedItemIndex (
					aList, aRngIndex, aRngCount,
					aKeyToSearch, aCompareFunc,
					//aSearchMode
					aFindNearestItemMode,
					aReverseSearchMode,
					aUseAccurateOrderedSearch
				);
			else
				// items are in Descending Order
				return FindDescendingOrderedItemIndex (
					aList, aRngIndex, aRngCount,
					aKeyToSearch, aCompareFunc,
					//aSearchMode
					aFindNearestItemMode,
					aReverseSearchMode,
					aUseAccurateOrderedSearch
				);
			//end if
		} else {

			// items are not ordered

			//if (aSearchMode > 0)
			if (aReverseSearchMode)
				// (nearest), reverse
				return (aRngIndex - 1L);
			else
				// (nearest), direct
				return (aRngIndex + aRngCount);
         //end if

		}//end if
	}

#endregion

//=======================================================================================

//=======================================================================================
// Binary-Search :: High-Level Procs
//=======================================================================================

//=======================================================================================
// looking for an exact item match

#region looking for an actual item match

	// ( Ascending | Descending )

	// direct // first

	// FindFirstOrderedItemIndex

	// range
	public static long FindFirstOrderedItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		int aOrderType,
		bool aWantAccurateBinSearch
	) {
		// insert range check
		//aList.CheckValidInsertRange (aRngIndex, aRngCount);
		// ok!
		//long aItemIndex =
		return FindOrderedItemIndex (
			aList, aRngIndex, aRngCount,
			aKeyToSearch, aCompareFunc,
			//VRPLSearchMode.kFindExactItemIndex, // exact item index
			false, // find item
			false, // direct
			aOrderType,
			aWantAccurateBinSearch
		);
		/*/
		if (aItemIndex < aRngIndex)
			// not found!
			aItemIndex = (aRngIndex + aRngCount);
		//end if
		if (aWantAccurateBinSearch) { // aList.AccurateBinarySearch
			// use accurate binary search
			if (VRLongRangeCheck.IsItemIndexValid (aItemIndex, aRngIndex, aRngCount)) {
				// an exact match was found
				// vai indietro all'inizio della sequenza di elementi uguali
				aItemIndex = FindEqItemsSeqBeginIndex (
					aList, aRngIndex, aRngCount,
					aKeyToSearch, aCompareFunc,
					aItemIndex
				);
			}//end if
		}//end if
		return aItemIndex;
		/*/
	}

	// whole list
	public static long FindFirstOrderedItemIndex (
		VRPagedList aList,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		int aOrderType,
		bool aWantAccurateBinSearch
	) {
		return FindFirstOrderedItemIndex (
			aList, (0L), aList.ItemsCount,
			aKeyToSearch, aCompareFunc,
			aOrderType,
			aWantAccurateBinSearch
		);
	}


	// reverse // last

	// FindLastOrderedItemIndex

	// range
	public static long FindLastOrderedItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		int aOrderType,
		bool aWantAccurateBinSearch
	) {
		// insert range check
		//aList.CheckValidInsertRange (aRngIndex, aRngCount);
		// ok!
		//long aItemIndex =
		return FindOrderedItemIndex (
			aList, aRngIndex, aRngCount,
			aKeyToSearch, aCompareFunc,
			//VRPLSearchMode.kFindExactItemIndex, // exact item index
			false, // find item
			true, // reverse
			aOrderType,
			aWantAccurateBinSearch
		);
		/*/
		if (aWantAccurateBinSearch) { // aList.AccurateBinarySearch
			// use accurate binary search
			if (VRLongRangeCheck.IsItemIndexValid (aItemIndex, aRngIndex, aRngCount)) {
				// an exact match was found
				// vai avanti alla fine della sequenza di elementi uguali
				aItemIndex = FindEqItemsSeqEndIndex (
					aList, aRngIndex, aRngCount,
					aKeyToSearch, aCompareFunc,
					aItemIndex
				);
			}//end if
		}//end if
		return aItemIndex;
		/*/
	}

	// whole list
	public static long FindLastOrderedItemIndex (
		VRPagedList aList,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		int aOrderType,
		bool aWantAccurateBinSearch
	) {
		return FindLastOrderedItemIndex (
			aList, (0L), aList.ItemsCount,
			aKeyToSearch, aCompareFunc,
			aOrderType,
			aWantAccurateBinSearch
		);
	}


//=======================================================================================

#endregion

//=======================================================================================
// looking for a nearest item

#region looking for a nearest item

	// ( Ascending | Descending )

	// direct // first

	// FindFirstNearestOrderedItemIndex

	// range
	public static long FindFirstNearestOrderedItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		int aOrderType,
		bool aWantAccurateBinSearch
	) {
		// insert range check
		//aList.CheckValidInsertRange (aRngIndex, aRngCount);
		// ok!
		//long aItemIndex =
		return FindOrderedItemIndex (
			aList, aRngIndex, aRngCount,
			aKeyToSearch, aCompareFunc,
			//VRPLSearchMode.kFindNearestItemIndexDirect, // nearest, direct
			true, // find nearest item
			false, // direct
			aOrderType,
			aWantAccurateBinSearch
		);
		/*/
		if (aWantAccurateBinSearch) { // aList.AccurateBinarySearch

			// use accurate binary search

			if (VRLongRangeCheck.IsItemIndexValid (aItemIndex, aRngIndex, aRngCount)) {

				// get item
				object aItem = aList.GetItemAtIndex (aItemIndex);

				// compare: aKeyToSearch vs aItem
				int relCmpVal = aList.Compare //CallCompareKeyWithItemProc
					(aCompareFunc, aKeyToSearch, aItem);

				if (relCmpVal == 0)
					// (aKey == aVect[i])
					// trovato un elemento uguale:
					// vai indietro all'inizio della sequenza di elementi uguali
					aItemIndex = FindEqItemsSeqBeginIndex (
						aList, aRngIndex, aRngCount,
						aKeyToSearch, aCompareFunc,
						aItemIndex
					);
				//end if

			}//end if

		}//end if
		return aItemIndex;
		/*/
	}

	// whole list
	public static long FindFirstNearestOrderedItemIndex (
		VRPagedList aList,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		int aOrderType,
		bool aWantAccurateBinSearch
	) {
		return FindFirstNearestOrderedItemIndex (
			aList, (0L), aList.ItemsCount,
			aKeyToSearch, aCompareFunc,
			aOrderType,
			aWantAccurateBinSearch
		);
	}


	// reverse // last

	// FindLastNearestOrderedItemIndex

	// range
	public static long FindLastNearestOrderedItemIndex (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		int aOrderType,
		bool aWantAccurateBinSearch
	) {
		// insert range check
		//aList.CheckValidInsertRange (aRngIndex, aRngCount);
		// ok!
		//long aItemIndex =
		return FindOrderedItemIndex (
			aList, aRngIndex, aRngCount,
			aKeyToSearch, aCompareFunc,
			//VRPLSearchMode.kFindNearestItemIndexReverse, // nearest, reverse
			true, // find nearest item
			true, // reverse
			aOrderType,
			aWantAccurateBinSearch
		);
		/*/
		if (aWantAccurateBinSearch) { // aList.AccurateBinarySearch

			// use accurate binary search

			if (VRLongRangeCheck.IsItemIndexValid (aItemIndex, aRngIndex, aRngCount)) {

				// get item
				object aItem = aList.GetItemAtIndex (aItemIndex);

				// compare: aKeyToSearch vs aItem
				int relCmpVal = aList.Compare //CallCompareKeyWithItemProc
					(aCompareFunc, aKeyToSearch, aItem);

				if (relCmpVal == 0)
					// (aKey == aVect[i])
					// trovato un elemento uguale:
					// vai avanti alla fine della sequenza di elementi uguali
					aItemIndex = FindEqItemsSeqEndIndex (
						aList, aRngIndex, aRngCount,
						aKeyToSearch, aCompareFunc,
						aItemIndex
					);
				//end if

			}//end if

		}//end if
		return aItemIndex;
		/*/
	}

	// whole list
	public static long FindLastNearestOrderedItemIndex (
		VRPagedList aList,
		object aKeyToSearch,
		IVRPLItemComparator aCompareFunc,
		int aOrderType,
		bool aWantAccurateBinSearch
	) {
		return FindLastNearestOrderedItemIndex (
			aList, (0L), aList.ItemsCount,
			aKeyToSearch, aCompareFunc,
			aOrderType,
			aWantAccurateBinSearch
		);
	}

/*/
	// reverse param

/*/

//=======================================================================================

#endregion

//=======================================================================================

	// ==================================
	// Inserting Items in an Ordered List
	// ==================================

	// macro

	/*/ InsertOrderedItem

			[aCompareFunc]
				the bin-search user compare func
				note that you are comparing an actual item
					not a key !!
					as stated in the definition of this function

			if [wantAddAsFirst] is true then
				the item is fisically inserted at the end
				of a sequence of duplicates
				this won't work if [aWantAccurateBinSearch] is false

			[aOrderType]
				if it is > 0 then assume the list is in Asceding Order
				if it is < 0 then assume the list is in Desceding Order

			[aDuplicatesMode]
				pass (0) if you do not want duplicates
				pass (1) if you allow duplicate items
				pass (2) or something else if you are ignoring duplicate items

			[aWantAccurateBinSearch]
				this makes sense only if the list contains duplicates
				note that the [wantAddAsFirst] parameter works only if this is true

			it throws an exception on errors

			returns
				the index of the newly inserted item
	/*/

	// InsertOrderedItem

	// range

	public static long InsertOrderedItem (
		VRPagedList aList,
		long aRngIndex,
		long aRngCount,
		object aItemData,
		IVRPLItemComparator aCompareFunc,
		bool wantAddAsFirst,
		int aOrderType,
		int aDuplicatesMode,
		bool aWantAccurateBinSearch
	) {
		// insert range check
		aList.CheckValidInsertRange (aRngIndex, aRngCount);
		// ok!

		// binary search a nearest item index
		long aGlobalIndex;
		if (wantAddAsFirst)
			// perform a direct search
			aGlobalIndex = FindFirstNearestOrderedItemIndex (
				aList, aRngIndex, aRngCount,
				aItemData, aCompareFunc,
				aOrderType, aWantAccurateBinSearch
			);
		else
			// perform a reverse search
			aGlobalIndex = FindLastNearestOrderedItemIndex (
				aList, aRngIndex, aRngCount,
				aItemData, aCompareFunc,
				aOrderType, aWantAccurateBinSearch
			);
		//end if

		// check for duplicate items
		//if (!allowDuplicates)
		if (aDuplicatesMode != VRPLDuplicatesMode.theAllowDuplicatesMode)
			// duplicates are not allowed !!
			//if ( aList.IsItemIndexValid (aGlobalIndex) ) {
			if (VRLongRangeCheck.IsItemIndexValid (aGlobalIndex, aRngIndex, aRngCount)) {
				// get stored data item
				object storedDataItem = aList.GetItemAtIndex (aGlobalIndex);
				// (aItemData == storedDataItem) ?
				int cmpResult = aList.Compare //CallCompareKeyWithItemProc
					(aCompareFunc, aItemData, storedDataItem);
				if (cmpResult == 0) {
					// a duplicate was found at (aGlobalIndex) !!
					if (aDuplicatesMode == VRPLDuplicatesMode.theDoNotAllowDuplicatesMode)
						// fail: duplicate items not allowed !!
						throw new VRPListDoNotAllowDuplicatesException (aList, aGlobalIndex, aItemData);
					// else ...
					// duplicates are ignored!
					return aGlobalIndex;
					// done!
				}//end if
			}//end if
		//else
			// duplicates are allowed !!
		//end if
		//ok!

		if (!wantAddAsFirst)
			// make aGlobalIndex a valid insert index
			aGlobalIndex += (1L);
		//end if

		// do insert item at index !!
		aList.InsertItemAtIndex (aGlobalIndex, aItemData);
		// success!

		return aGlobalIndex;
	}

	// all

	public static long InsertOrderedItem (
		VRPagedList aList,
		object aItemData,
		IVRPLItemComparator aCompareFunc,
		bool wantAddAsFirst,
		int aOrderType,
		int aDuplicatesMode,
		bool aWantAccurateBinSearch
	) {
		return InsertOrderedItem (
			aList, (0L), aList.ItemsCount,
			aItemData, aCompareFunc,
			wantAddAsFirst,
			aOrderType,
			aDuplicatesMode,
			aWantAccurateBinSearch
		);
	}



//=======================================================================================


//=======================================================================================


		// more ?
		// ... ... ...
		// ... ... ...
		// ... ... ...


//=======================================================================================


} // VRPListItemsOrdUtils


} // namespace

// that's all folks ...