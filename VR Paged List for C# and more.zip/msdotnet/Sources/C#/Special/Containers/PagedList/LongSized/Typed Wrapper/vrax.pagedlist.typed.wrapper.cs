
namespace VRAdrixNT.Collections.Generic
{

	using System;

	using System.Collections;

	using System.Collections.Generic;

	using VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main;

	public class VRPagedListTypedWrapperEnumerator<T> : IEnumerator<T>
	{

		// instance data

		private VRPagedListIterator theIterator = null;

		public VRPagedListIterator Iterator {
			get { return this.theIterator; }
			set {
				this.theIterator = value;
				this.Reset();
			}
		}

		// init

		public VRPagedListTypedWrapperEnumerator() { }

		public void Dispose() { }

		// reset

		public void Reset()
		{
			this.Iterator.Index = (-1L);
		}

		// move next
		public bool MoveNext()
		{
			if (this.Iterator.IsUpdateNeeded())
				throw new InvalidOperationException ("invalid data set");
			// ok!

			long aSize = this.Iterator.List.Size;
			long aLastItemIndex = aSize - 1L;
			long aCurrItemIndex = this.Iterator.Index;

			bool aCanMoveNext = (aCurrItemIndex < aLastItemIndex);

			// bool aCanMoveNext = (this.Iterator.Index < (this.Iterator.List.Size - 1));
			if (aCanMoveNext) {
				// ++ this.Iterator;
				this.Iterator.Next();
			}
			return aCanMoveNext;
		}

		object IEnumerator.Current {
			get {
				try {
					return this.Iterator.Item;
				}
				catch (Exception) {
					throw new InvalidOperationException();
				}
			}
		}

		public T Current {
			get {
				try {
					return (T) this.Iterator.Item;
				} catch (Exception) {
					throw new InvalidOperationException();
				}
			}
		}

	} // VRPagedListTypedWrapperEnumerator


	// VR PagedList Typed Wrapper

	public class VRPagedListTypedWrapper<T> :
		IEnumerable<T>,
		ICollection<T>,
		IList<T>,
		IList
	{

		// instace data

		private VRPagedList theList = null;

		public VRPagedList List {
			get { return this.theList; }
			set { this.theList = value; }
		}

		// init

		public VRPagedListTypedWrapper() { }

		// get enumerator

		public IEnumerator<T> GetEnumerator()
		{
			VRPagedListIterator aIterator = new VRPagedListIterator();

			aIterator.List = this.List;

			VRPagedListTypedWrapperEnumerator<T> aEnumerator =
				new VRPagedListTypedWrapperEnumerator<T>();

			aEnumerator.Iterator = aIterator;

			return aEnumerator;
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		// IList<T>

		public int Count {
			get { return (int) this.List.Size; }
		}

		public bool IsReadOnly { get { return false; } }

		public bool IsSynchronized { get { return false; } }

		public object SyncRoot { get { return this; } }

		public void Add(T aItem) { this.List.Add(aItem); }

		public bool Contains(T aItem)
		{
			return this.List.Contains(aItem);
		}

		public void Clear() { this.List.Clear(); }

		public void CopyTo(T[] aArray, int aDestIndex)
		{
			int aIndex = aDestIndex;
			foreach (T aItem in this) {
				aArray[aIndex] = aItem;
				++aIndex;
			}
		}

		public bool Remove(T aItem)
		{
			if (this.Contains(aItem)) {
				this.List.Remove(aItem);
				return true;
			}
			return false;
		}

		public int IndexOf(T aItem) { return this.List.IndexOf(aItem); }

		public void Insert(int aIndex, T aItem)
		{
			this.List.Insert(aIndex, aItem);
		}

		public void RemoveAt(int aIndex)
		{
			this.List.Delete(aIndex);
		}

		public T this[int aIndex] {
			get { return (T)this.List[aIndex]; }
			set { this.List[aIndex] = value; }
		}


		bool IList.IsFixedSize { get { return false; } }

		int IList.Add(object aItem) { return this.List.Add(aItem); }

		void IList.Insert(int aIndex, object aItem) { this.List.Insert(aIndex, aItem); }

		bool IList.Contains(object aItem) { return this.List.Contains(aItem); }

		int IList.IndexOf(object aItem) { return this.List.IndexOf(aItem); }

		void IList.Remove(object aItem) { this.List.Remove(aItem); }

		object IList.this [int aIndex] { 
			get { return this.List[aIndex]; }
			set { this.List[aIndex] = value; }
		}

		void ICollection.CopyTo (Array array, int arrayIndex)
		{
			this.List.CopyTo(array, arrayIndex);
		}

	} // VRPagedListTypedWrapper


} // namespace