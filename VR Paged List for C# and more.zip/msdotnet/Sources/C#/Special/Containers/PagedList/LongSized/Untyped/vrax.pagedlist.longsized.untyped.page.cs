

namespace VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main.Support
{

	using System;

//=======================================================================================

	// Abst Page class

	public abstract class VRPLAbstPage
	{

//=======================================================================================
// Check B+Tree Exceptions

#region Check B+Tree Exceptions

		public class CheckBTreeBaseException : Exception
		{
			public CheckBTreeBaseException (string aMsg) : base (aMsg) {}
		}

		// =================
		// invalid page link

		public class InvalidPageLinkException : CheckBTreeBaseException
		{
			public InvalidPageLinkException (string aMsg) :
				base ("Invalid Page " + aMsg + " Link.")
			{}
		}

		// invalid page fwd link

		public class InvalidPageFwdLinkException : InvalidPageLinkException
		{
			public InvalidPageFwdLinkException() : base ("Forward") {}
		}

		// invalid page bwd link

		public class InvalidPageBwdLinkException : InvalidPageLinkException
		{
			public InvalidPageBwdLinkException() : base ("Backward") {}
		}

		// =================
		// invalid page type

		public class InvalidPageTypeException : CheckBTreeBaseException
		{
			public InvalidPageTypeException (string aMsg) :
				base ("Invalid " + aMsg +  " Page Type.")
			{}
		}

		// invalid next page type

		public class InvalidNextPageTypeException : InvalidPageTypeException
		{
			public InvalidNextPageTypeException() : base ("Next") {}
		}

		// invalid prev page type

		public class InvalidPrevPageTypeException : InvalidPageTypeException
		{
			public InvalidPrevPageTypeException() : base ("Prev") {}
		}

		// ====================
		// invalid sub page ref

		public class InvalidSubPageRefException : CheckBTreeBaseException
		{
			public InvalidSubPageRefException() :
				base ("Invalid Sub-Page reference.")
			{}
		}

		// =======================
		// invalid parent page ref

		public class InvalidParentPageRefException : CheckBTreeBaseException
		{
			public InvalidParentPageRefException() :
				base ("Invalid Parent-Page reference.")
			{}
		}

		// ==========================
		// invalid deep items counter

		public class InvalidDeepCounterException : CheckBTreeBaseException
		{
			public InvalidDeepCounterException() :
				base ("Invalid Page Deep-Items-Count.")
			{}
		}

#endregion

//=======================================================================================
// page type

#region page type

		public sealed class PageType
		{
			private PageType() {}
			public const int kRefsPage = 0;
			public const int kDataPage = 1;
			//
			public static bool IsRefsPageType (int aPageType)
			{
				return (aPageType == kRefsPage);
			}
			public static bool IsDataPageType (int aPageType)
			{
				return ! IsRefsPageType (aPageType);
			}
		}

//=======================================================================================
// page type

		public abstract int GetPageType();

		public static bool SamePageType (VRPLAbstPage aPageA, VRPLAbstPage aPageB)
		{
			return aPageA.GetPageType() == aPageB.GetPageType();
		}

		public bool IsDataPage()
		{
			return (this.GetPageType() != 0);
		}
		public bool IsRefsPage()
		{
			return ! this.IsDataPage();
		}

#endregion

//=======================================================================================
// instance data

#region VRPLAbstPage instance data

		private object[] theArray = null;

		private long theItemsCount = 0L;

		private VRPLAbstPage theParentPage = null;
		private VRPLAbstPage theNextPage = null;
		private VRPLAbstPage thePrevPage = null;

#endregion

//=======================================================================================
// init

		public VRPLAbstPage (long aSize)
		{
			this.theArray = new object[aSize];
		}

//=======================================================================================

#region VRPLPage_Links

//=======================================================================================
// parent page

		public void SetParentPage (VRPLAbstPage aNewParent)
		{
			this.theParentPage = aNewParent;
		}
		public VRPLAbstPage GetParentPage()
		{
			return this.theParentPage;
		}

//=======================================================================================
// next/prev page

		// get
		public VRPLAbstPage GetNextPage() { return this.theNextPage; }
		public VRPLAbstPage GetPrevPage() { return this.thePrevPage; }
		// set
		public void SetNextPage (VRPLAbstPage aPage) { this.theNextPage = aPage; }
		public void SetPrevPage (VRPLAbstPage aPage) { this.thePrevPage = aPage; }

		// test for first/last page

		public bool IsFirstPage() { return (this.GetPrevPage() == null); }
		public bool IsLastPage() { return (this.GetNextPage() == null); }

//=======================================================================================
// link / unlink

		// link

		public void Link (VRPLAbstPage aPrvPage, VRPLAbstPage aNxtPage)
		{
			// this.unlink(); // !!
			// link a page to its next & prev ones ...
			this.SetNextPage (aNxtPage);
			this.SetPrevPage (aPrvPage);
			// link next & prev pages (if any) to this one ...
			if (aNxtPage != null)
				aNxtPage.SetPrevPage (this); // link the next page to this one!
			//end if
			if (aPrvPage != null)
				aPrvPage.SetNextPage (this); // link the prev page to this one!
			//end if
		}

		// unlink

		public void Unlink()
		{
			VRPLAbstPage nxtPg = this.GetNextPage();
			VRPLAbstPage prvPg = this.GetPrevPage();
			// unlink next & prev pages from this one by linking them togheter
			if (nxtPg != null)
				// assert: nxtPg.GetPrevPage() == this !!
				nxtPg.SetPrevPage (prvPg); // unlink next page
			//end if
			if (prvPg != null)
				// assert: prvPg.GetNextPage() == this !!
				prvPg.SetNextPage (nxtPg); // unlink prev page
			//end if
			this.SetNextPage (null);
			this.SetPrevPage (null);
			// done!
		}

//=======================================================================================
// to find next / prev page

		// to find the next page

		public VRPLAbstPage FindNextPage()
		{
			// get the parent-page
			VRPLAbstPage aParentPage = this.GetParentPage();
			if (aParentPage != null) 
			{
				long aNxtIndex = aParentPage.IndexOfPageRef (this) + 1L;
				if (aNxtIndex < aParentPage.GetItemsCount())
					return aParentPage.GetPageRefAt (aNxtIndex);
				//end if
				// aNxtIndex is out-of-bounds: try next of parent
				VRPLAbstPage aParentNextPage = aParentPage.FindNextPage(); // recursive call here !!
				if (aParentNextPage != null)
					return aParentNextPage.GetPageRefAt (0L);
				//end if
			}//end if
			return null;
		}

		// to find the prev page

	   public VRPLAbstPage FindPrevPage()
		{
	      // get the parent-page
		   VRPLAbstPage aParentPage = this.GetParentPage();
	      if (aParentPage != null) {
		      long aPrvIndex = aParentPage.IndexOfPageRef (this) - 1L;
				if (aPrvIndex >= 0L)
					return aParentPage.GetPageRefAt (aPrvIndex);
	         //end if
		      // aPrvIndex is out-of-bounds: try prev of parent
			   VRPLAbstPage aParentPrevPage = aParentPage.FindPrevPage(); // recursive call here !!
				if (aParentPrevPage != null)
					return aParentPrevPage.GetPageRefAt (aParentPrevPage.GetItemsCount() - 1L);
	         //end if
		   }//end if
			return null;
		}

//=======================================================================================

		// counting pages forward/backward

		public long CountPagesForward()
		{
			long aCount = 0L;
			VRPLAbstPage aPage = this;
			while (aPage != null) {
				++ aCount;
				aPage = aPage.GetNextPage();
			}
			return aCount;
		}

		public long CountPagesBackward()
		{
			long aCount = 0L;
			VRPLAbstPage aPage = this;
			while (aPage != null) {
				++ aCount;
				aPage = aPage.GetPrevPage();
			}
			return aCount;
		}

#endregion

//=======================================================================================

#region VRPLPage_ItemsCount_And_RangeChecking

//=======================================================================================
// range checking

#region VRPLPage_RangeChecking

		/*/ 
			(0) is always a valid insert index
		/*/

		public bool IsInsertIndexValid (long aIndex)
		{
			return (aIndex >= 0L) && (aIndex <= this.GetItemsCount());
		}

		public bool IsItemIndexValid (long aIndex)
		{
			return (aIndex >= 0L) && (aIndex < this.GetItemsCount());
		}

#endregion

//=======================================================================================
// items count

#region VRPLPage_ItemsCount

		public long GetItemsCount() { return this.theItemsCount; }

		public void SetItemsCount (long aNewCount) { this.theItemsCount = aNewCount; }

		// [+=, -=]
		public void IncrItemsCount (long aValueIncr)
		{
			this.theItemsCount += aValueIncr;
		}
		public void DecrItemsCount (long aValueDecr)
		{
			this.theItemsCount -= aValueDecr;
		}

		// [++,--]
		public void IncrItemsCount()
		{
			this.theItemsCount += 1L;
		}
		public void DecrItemsCount()
		{
			this.theItemsCount -= 1L;
		}

#endregion

//=======================================================================================

#region VRPLPage_IsEmpty

		public bool IsEmpty()
		{
			return (this.GetItemsCount() <= 0L);
		}

		public bool CanBeDisposed()
		{
			if (this.IsDataPage()) 
			{
				// it is a data-page
				if (this.IsEmpty())
					return true; //canDestroyPage = true;
				//end if
				//return false;
			} 
			else 
			{
				// it is a refs-page
				if (this.GetParentPage() != null) 
				{
					// it has a parent
					if (this.IsEmpty()) //(aPage->ItemsCount() <= 0L)
						// and it is empty
						return true; //canDestroyPage = true;
					//else
					// it is a refs-page containing
					// at least one ref-item
					// we cannot destroy it
					//return false;
				} 
				else 
				{
					// it is the root-page
					if (this.GetItemsCount() <= (1L))
						// and it is empty (items-count <= 1) - items-count should be == (1) !!
						return true; //canDestroyPage = true;
					//else
					// the refs-root-page has at least 2 ref-items
					// we cannot destroy it
					//return false;
				}//end if
			}//end if
			return false;
		}

#endregion

#endregion

//=======================================================================================
// deep items count

#region VRPLPage_DeepItemsCount

#region Set,Get,Incr,Decr DeepItemsCount

		public virtual long GetDeepItemsCount()
		{
			return this.GetItemsCount();
		}

		public virtual void SetDeepItemsCount (long aNewCount)
		{
			// do nothing !!
		}

		public virtual void IncrDeepItemsCount (long aValue)
		{
			// do nothing !!
		}
		public virtual void DecrDeepItemsCount (long aValue)
		{
			// do nothing !!
		}

		public virtual void IncrDeepItemsCount()
		{
			// do nothing !!
		}

		public virtual void DecrDeepItemsCount()
		{
			// do nothing !!
		}

#endregion

//=======================================================================================

		// to update the deep items count deep

		public void DeepUpdateDeepItemsCount()
		{
			if (this.IsRefsPage()) {
				long aDeepCount = 0L;
				long aCount = this.GetItemsCount();
				long aIndex = 0L;
				// update loop
				while (aIndex < aCount) {
					VRPLAbstPage aSubPage = this.GetPageRefAt (aIndex);
					// update (aSubPage) deep-count
					aSubPage.DeepUpdateDeepItemsCount();
					// increase this deep-count by the deep-count of (aSubPage)
					aDeepCount += aSubPage.GetDeepItemsCount();
					// next
					++ aIndex;
				}
				// update this deep-count
				this.SetDeepItemsCount (aDeepCount);
			}
			//else
				// do nothing if it is a data-page
			//end if
		}

		// to compute the deep items count deep (no update)

		public long DeepComputeDeepItemsCount()
		{
			if (this.IsRefsPage()) {
				// refs page
				long aDeepCount = 0L;
				long aCount = this.GetItemsCount();
				long aIndex = 0L;
				while (aIndex < aCount) {
					VRPLAbstPage aSubPage = this.GetPageRefAt (aIndex);
					// accumulate deep count
					aDeepCount += aSubPage.DeepComputeDeepItemsCount();
					// next
					++ aIndex;
				}
				return aDeepCount;
			}
			else
				// data page
				return this.GetDeepItemsCount();
			//end if
		}

		// to compute the deep items count shallow (no update)

		public long ShallowComputeDeepItemsCount()
		{
			if	(this.IsRefsPage()) {
				long aDeepCount = 0L;
				long aCount = this.GetItemsCount();
				long aIndex = 0L;
				while	(aIndex < aCount)	{
					VRPLAbstPage aSubPage = this.GetPageRefAt (aIndex);
					aDeepCount += aSubPage.GetDeepItemsCount();
					++ aIndex;
				}
				return aDeepCount;
			}
			else
				return this.GetDeepItemsCount();
			//end if
		}

		public void ShallowUpdateDeepItemsCount()
		{
			this.SetDeepItemsCount (this.ShallowComputeDeepItemsCount());
		}

#endregion

//=======================================================================================
// accessing items

#region Handling Items in the Page Array

#region Accessing Items in the Page Array

		// get

		public object GetItemAt (long aIndex)
		{
			return this.theArray[aIndex];
		}

		public VRPLAbstPage GetPageRefAt (long aIndex)
		{
			return (VRPLAbstPage) this.GetItemAt (aIndex);
		}

		// set

		public void SetItemAt (long aIndex, object aValue)
		{
			this.theArray[aIndex] = aValue;
		}

		public void SetPageRefAt (long aIndex, VRPLAbstPage aPageRef)
		{
			this.SetItemAt (aIndex, aPageRef);
		}

#endregion

//=======================================================================================

#region IndexOfPageRef

		public long IndexOfPageRef (VRPLAbstPage aPageRef)
		{
			long aCount = this.GetItemsCount();
			long aIndex = 0L;
			while (aIndex < aCount) 
			{
				VRPLAbstPage aRef = this.GetPageRefAt (aIndex);
				if (aRef == aPageRef)
					break;
				++ aIndex;
			}
			return aIndex;
		}

#endregion

//=======================================================================================
// data pages items

#region Inserting / Deleting Generic Page Items

		// to insert a user data item

		public void InsertItem (long aIndex, object aValue)
		{
			// WARNING: ItemsCount() is not changed !!
			ArrayUtils.InsertShift (
				this.theArray,
				this.GetItemsCount(), // old items count
				aIndex, // ins index
				(1L), // ins count
				false // wantClear
			);
			this.SetItemAt (aIndex, aValue);
		}

		// to delete a user data item

		public void DeleteItem (long aIndex)
		{
			// WARNING: ItemsCount() is not changed !!
			ArrayUtils.DeleteShift (
				this.theArray,
				this.GetItemsCount(), // old items count
				aIndex, // del index
				(1L), // del count
				true // wantClear
			);
		}

		// to delete many user data items

		public void DeleteItems (long aIndex, long aCount)
		{
			ArrayUtils.DeleteShift (
				this.theArray,
				this.GetItemsCount(), // old items count
				aIndex, aCount,
				true // wantClear
			);
		}

#endregion

//=======================================================================================
// refs pages items

#region Inserting / Deleting Refs Page Items

		public void InsertPageRef (long aIndex, VRPLAbstPage aPageRef)
		{
			// WARNING: ItemsCount() is not changed !!
			this.InsertItem (aIndex, aPageRef);
		}

		public void DeletePageRef (long aIndex)
		{
			// WARNING: ItemsCount() is not changed !!
			this.DeleteItem (aIndex);
		}

		public void DeletePageRefs (long aIndex, long aCount)
		{
			// WARNING: ItemsCount() is not changed !!
			this.DeleteItems (aIndex, aCount);
		}

#endregion

#endregion

//=======================================================================================

#region Accessing the First / Last data page from this one

		// Accessing data pages

		// first data page from this one

		public VRPLAbstPage GetFirstDataPage()
		{
			VRPLAbstPage aPage = this;
			while (true) {
				if (aPage.IsDataPage()) break;
				// [aPage] is a refs-page:	go	down at first index !!
				aPage = aPage.GetPageRefAt (0L);
			}
			return aPage;
		}

		// last data page from this one

		public VRPLAbstPage GetLastDataPage()
		{
			VRPLAbstPage aPage = this;
			while (true) {
				if (aPage.IsDataPage())	break;
				// [aPage] is a refs-page:	go	down at last index !!
				aPage = aPage.GetPageRefAt (aPage.GetItemsCount() - 1L);
			}
			return aPage;
		}

#endregion


//=======================================================================================

#region Accessing First / Last Deep Data Item

	public object GetFirstDeepDataItem()
	{
		VRPLAbstPage aPageToQuery = this;
		while ( ! aPageToQuery.IsDataPage() ) //do
			// assert: aPageToQuery.GetItemsCount() > 0 !!
			aPageToQuery = aPageToQuery.GetPageRefAt (0L);
		//loop
		//return this->DataPageItem (aPageToQuery, 0L);
		return aPageToQuery.GetItemAt (0L);
	}

	public object GetLastDeepDataItem()
	{
		VRPLAbstPage aPageToQuery = this;
		while ( ! aPageToQuery.IsDataPage() ) //do
			// assert: aPageToQuery->ItemsCount() > 0 !!
			aPageToQuery = aPageToQuery.GetPageRefAt (aPageToQuery.GetItemsCount() - 1L);
		//loop
		//return this->DataPageItem (aPageToQuery, aPageToQuery->ItemsCount() - 1L);
		return aPageToQuery.GetItemAt (aPageToQuery.GetItemsCount() - 1L);
	}

	public static object GetPageFirstDeepDataItem (VRPLAbstPage aPage)
	{
		return aPage.GetFirstDeepDataItem();
	}

	public static object GetPageLastDeepDataItem (VRPLAbstPage aPage)
	{
		return aPage.GetLastDeepDataItem();
	}

#endregion

//=======================================================================================

#region helper methods used by page insert/delete/compact core procs

		// helper methods used by page insert/delete/compact core procs

		// Only valid for refs pages

		public long SumSubPagesDeepItemsCounters (long aStartingIndex, long aCount)
		{
			long aSum = 0L;
			long aIndex = 0L;
			while (aIndex < aCount) {
				VRPLAbstPage aSubPage = this.GetPageRefAt (aStartingIndex + aIndex);
				// totalize
				aSum += aSubPage.GetDeepItemsCount();
				//	next
				++ aIndex;
			}
			return aSum;
		}

		// Only valid for refs pages

		public void ChangeSubPagesParent (long aStartingIndex, long aCount, VRPLAbstPage aNewParent)
		{
			long aIndex = 0L;
			while (aIndex < aCount) {
				VRPLAbstPage aSubPage = this.GetPageRefAt (aStartingIndex + aIndex);
				//	change parent
				aSubPage.SetParentPage (aNewParent);
				//	next
				++ aIndex;
			}
		}

#endregion

//=======================================================================================
// B+Tree Debugging

#region B+Tree Debugging section

		// Check a page Fwd/Bwd Links

		public void CheckFwdBwdLinks()
		{
			// get next page / find next page
			VRPLAbstPage aNextPage = this.GetNextPage();
			VRPLAbstPage aNextPage1 = this.FindNextPage();
			// get prev page / find prev page
			VRPLAbstPage aPrevPage = this.GetPrevPage();
			VRPLAbstPage aPrevPage1 = this.FindPrevPage();

			// check fwd/bwd links (1)
			if (aNextPage != aNextPage1)
				throw new InvalidPageFwdLinkException();
			if (aPrevPage != aPrevPage1)
				throw new InvalidPageBwdLinkException();

			// check fwd/bwd links (2)
			if (aNextPage != null)
				if (aNextPage.GetPrevPage() != this)
					throw new InvalidPageBwdLinkException();
			if (aPrevPage != null)
				if (aPrevPage.GetNextPage() != this)
					throw new InvalidPageFwdLinkException();

			// also check the page type
			if (aNextPage != null)
				if (this.GetPageType() != aNextPage.GetPageType())
					throw new InvalidNextPageTypeException();
			if (aPrevPage != null)
				if (this.GetPageType() != aPrevPage.GetPageType())
					throw new InvalidPrevPageTypeException();

			// ok!
		}

//=======================================================================================

		// Checking All sub-pages links

		public void CheckAllSubPagesLinks()
		{
			// check fwd/bwd links ...
			this.CheckFwdBwdLinks();
			// ok!
			if (this.IsRefsPage())
			{// check sub-pages parent-links
				// this is a refs-page
				long aItemsCount = this.GetItemsCount();
				long aIndex = 0L;
				while (aIndex < aItemsCount) {
					VRPLAbstPage aSubPage = this.GetPageRefAt (aIndex);
					// check for null sub-page
					if (aSubPage == null)
						throw new InvalidSubPageRefException();
					// ok!
					// check for a valid sub-page parent
					if (aSubPage.GetParentPage() != this)
						throw new InvalidParentPageRefException();
					// ok!
					// recurse on aSubPage
					aSubPage.CheckAllSubPagesLinks();
					// ok!
					++ aIndex;
				}//loop
			}
			// ok!
		}

//=======================================================================================

		// Checking the Deep-Count

		public void CheckDeepCounters()
		{
			if (this.IsRefsPage()) {
				//	this is a refs-page
				long computedDeepCount = (0L);
				long aItemsCount = this.GetItemsCount();
				long aIndex = 0L;
				while (aIndex < aItemsCount) {
					// get the (i-th) sub page
					VRPLAbstPage aSubPage = this.GetPageRefAt (aIndex);

					// recurse on "aSubPage"
					aSubPage.CheckDeepCounters();
					// ok!

					computedDeepCount += aSubPage.GetDeepItemsCount();

					++ aIndex;
				}//loop

				if (this.GetDeepItemsCount() != computedDeepCount)
					//return false;
					throw new InvalidDeepCounterException();
				// ok!
			}//end if
			// this is a data-page
				//return this->DeepCount() >= 0L;
			// we cannot have empty pages
			// empty	pages are deleted by
			// insert/delete/compact methods
			// of the PagedList class
			if (this.GetDeepItemsCount() <= 0L)
				throw new InvalidDeepCounterException();
			// ok!
		}

#endregion

//=======================================================================================
// Indexing the B+Tree

#region VRPLPage Indexing the B+Tree

		// (data-page, local-index) from (global-index, root-page)

		/*/
			retrieving (data-page, rel-index) from an absolute-item-index
			mainly used when accessing data items

			return values :

			aDataPage == null : the B-TREE is Empty !!
				aLocalIndex == aGlobalIndex

			aDataPage != null : the page we can use to insert/delete/read/write user-data
			aLocalIndex : the index inside aDataPage
				this value could be out-of-bounds

		/*/

		public static void AccessDataPageLocalIndexPairFromGlobalIndex (
			ref VRPLAbstPage aDataPage,
			ref long aLocalIndex,
			long aGlobalIndex,
			VRPLAbstPage aRootPage
		) {
			unchecked {
			aLocalIndex = aGlobalIndex;
			aDataPage = aRootPage; // list.GetRootPage();
			if (aDataPage != null)
			{
				while (aDataPage.IsRefsPage())
				{
					// aDataPage is a	refs-page !!
					// aDataPage.GetItemsCount() must be > 0 !!
					long aCount = aDataPage.GetItemsCount();
					if (aCount <= 0L)
						//	Should NEVER happen !!
						//	Avoid	an	Infinite	loop
						{	aDataPage = null;	break; }
						//	returns an out-of-bounds value
					//end	if
					long aIndex = 0L;
					while (aIndex < aCount)
					{
						VRPLAbstPage aSubPage = aDataPage.GetPageRefAt (aIndex);
						long aSubPageDeepCount = aSubPage.GetDeepItemsCount();
						// check aLocalIndex
						// or select the last page-ref
						if (
							(aLocalIndex < aSubPageDeepCount) ||
							(aIndex >= (aCount - 1L))
						) {
							// found a sub-page where the search should continue
							aDataPage = aSubPage;
							break;
						}
						// subtract the sub-page deep-count from aLocalIndex
						aLocalIndex -= aSubPageDeepCount;
						// next
						++ aIndex;
					} // loop
					// continue with aDataPage
				} // loop
				// finished!
				// assert: aDataPage is a data-page !!
			}//if
			//return (aDataPage, aLocalIndex)
			}//unchecked
		}

//=======================================================================================

		// global-index from (data-page, local-index)

		/*/
			returns aLocalIndex if aDataPage is null
		/*/

		public static long ComputeGlobalIndexFromDataPageLocalIndexPair (
			VRPLAbstPage aDataPage,
			long aLocalIndex
		) {
			unchecked {

			if (aDataPage == null) return aLocalIndex;

			long aGlobalIndex = aLocalIndex;

			VRPLAbstPage aPageToLookup = aDataPage;
			VRPLAbstPage aPage = aDataPage.GetParentPage();
			while (true) {
				if (aPage == null)
					break;
				//end	if
				// totalize deep-items-count in (aPage) before (aPageToLookup)
				long aTotalDeepCount = 0L;
				long aCount = aPage.GetItemsCount();
				long aIndex = 0L;
				while (aIndex < aCount) {
					VRPLAbstPage aTestPage = aPage.GetPageRefAt (aIndex);
					if (aTestPage == aPageToLookup)
						break;
					//end	if
					aTotalDeepCount += aTestPage.GetDeepItemsCount();
					++ aIndex;
				}//loop
				//	compute a global-index
				aGlobalIndex += aTotalDeepCount;
				//	up	one level
				aPageToLookup = aPage;
				aPage	=	aPage.GetParentPage();
			}//loop
			return aGlobalIndex;
			}//unchecked
		}

#endregion

//=======================================================================================
// Page Insert,Delete,Compact Core Procs
//=======================================================================================

#region Page Insert,Delete,Compact Core Procs

//=======================================================================================

		public static void BalancePagesDeepCount
			(VRPLAbstPage aDstBasePage, VRPLAbstPage aSrcBasePage, long movedItemsDeepCount)
		{
			VRPLAbstPage aDstPage = aDstBasePage;
			VRPLAbstPage aSrcPage = aSrcBasePage;
			// stop when we get a common ancestor-page
			while (aDstPage != aSrcPage)
			{
				// the following do nothing for data pages !!

				// subtract [-] (movedItemsDeepCount) from source page's deep-count
				aSrcPage.DecrDeepItemsCount (movedItemsDeepCount);

				// add [+] (movedItemsDeepCount) to destination page's deep-count
				aDstPage.IncrDeepItemsCount (movedItemsDeepCount);

				// up one level
				aSrcPage = aSrcPage.GetParentPage();
				aDstPage = aDstPage.GetParentPage();
			}//loop
		}

//=======================================================================================
// Moving Data-Items from a Source-Data-Page to a Dest-Data-Page

#region Moving Data-Items from a Source-Data-Page to a Dest-Data-Page

		// the following also Clears source data items

		public static void MovePagesItems (
			VRPLAbstPage aDstPage, long aDstIndex,
			VRPLAbstPage aSrcPage, long aSrcIndex,
			long aItemsToCopyCount
		) {
			long aIndex = 0L; // loop index
			while (aIndex < aItemsToCopyCount) 
			{
				// copy
				object aItem = aSrcPage.GetItemAt (aSrcIndex + aIndex);
				aDstPage.SetItemAt (aDstIndex + aIndex, aItem);
				// clear source after copy
				aSrcPage.SetItemAt (aSrcIndex + aIndex, null);
				// next
				++ aIndex;
			}
		}

		// the following do NOT Clear source data items

		public static void CopyPagesItems (
			VRPLAbstPage aDstPage, long aDstIndex,
			VRPLAbstPage aSrcPage, long aSrcIndex,
			long aItemsToCopyCount
		) {
			long aIndex = 0L; // loop index
			while (aIndex < aItemsToCopyCount) 
			{
				// copy
				object aItem = aSrcPage.GetItemAt (aSrcIndex + aIndex);
				aDstPage.SetItemAt (aDstIndex + aIndex, aItem);
				// do NOT clear source after copy
				// next
				++ aIndex;
			}
		}

//=======================================================================================
// aliases

#region Moving Data-Items from a Source-Data-Page to a Dest-Data-Page (aliases)

		// data pages

		public static void MoveDataPagesItems (
			VRPLAbstPage aDstPage, long aDstIndex,
			VRPLAbstPage aSrcPage, long aSrcIndex,
			long aItemsToCopyCount
		) {
			MovePagesItems (
				aDstPage, aDstIndex,
				aSrcPage, aSrcIndex,
				aItemsToCopyCount
			);
		}

		public static void CopyDataPagesItems (
			VRPLAbstPage aDstPage, long aDstIndex,
			VRPLAbstPage aSrcPage, long aSrcIndex,
			long aItemsToCopyCount
		) {
			CopyPagesItems (
				aDstPage, aDstIndex,
				aSrcPage, aSrcIndex,
				aItemsToCopyCount
			);
		}

		// refs pages

		public static void MoveRefsPagesItems (
			VRPLAbstPage aDstPage, long aDstIndex,
			VRPLAbstPage aSrcPage, long aSrcIndex,
			long aItemsToCopyCount
		) {
			MovePagesItems (
				aDstPage, aDstIndex,
				aSrcPage, aSrcIndex,
				aItemsToCopyCount
			);
		}

		public static void CopyRefsPagesItems (
			VRPLAbstPage aDstPage, long aDstIndex,
			VRPLAbstPage aSrcPage, long aSrcIndex,
			long aItemsToCopyCount
		) {
			CopyPagesItems (
				aDstPage, aDstIndex,
				aSrcPage, aSrcIndex,
				aItemsToCopyCount
			);
		}

#endregion

#endregion

//=======================================================================================
// MOVING ITEMS TO SPLIT A PAGE INTO ANOTHER ONE

		/*/ note:
			typeof(aSrcPage) == typeof(aDstPage) !!
			aDstPage must be empty !!
		/*/

		public static void MoveItemsForPageSplit (VRPLAbstPage aDstPage, VRPLAbstPage aSrcPage)
		{
			long srcPageItemsCount = aSrcPage.GetItemsCount();

			// this is the count of the items to move from source-page
			long itemsToMoveCount = srcPageItemsCount / 2L;

			long moveSrcStartingIndex = (srcPageItemsCount - itemsToMoveCount);

			long movedDeepCount = 0L;

			/*/
			move itemsToMoveCount items
				into aDstPage at 0
				from aSrcPage at moveSrcStartingIndex
			end move
			/*/
			MovePagesItems (
				/*/dst:/*/ aDstPage, 0L,
				/*/src:/*/ aSrcPage, moveSrcStartingIndex,
				/*/count:/*/ itemsToMoveCount
			);
			aSrcPage.DecrItemsCount (itemsToMoveCount);
			aDstPage.SetItemsCount (itemsToMoveCount);

			if (aSrcPage.IsRefsPage()) {
				// both are refs-pages

				// compute the balancing deep-count
				movedDeepCount = aDstPage.SumSubPagesDeepItemsCounters (0L, aDstPage.GetItemsCount());

				// also adjust the parent of each moved page to "aDstPage"
				aDstPage.ChangeSubPagesParent (0L, aDstPage.GetItemsCount(), aDstPage);

				// ok!
			} 
			else 
			{
				// both are data-pages

				// the balancing deep-count is the count of the moved data-items
				movedDeepCount = itemsToMoveCount;
			}

			// balance deep-count among src/dst-pages
			BalancePagesDeepCount (aDstPage, aSrcPage, movedDeepCount);
			// done!
		}

//=======================================================================================
// MOVING ITEMS TO MERGE 2 PAGES INTO ONE

		/*/ note:
			typeof(aSrcPage) == typeof(aDstPage) !!
			aDstPage has enough room for all items of aSrcPage !!
			this will Empty the "aSrcPage" source page !!
		/*/

		public static void MoveItemsForPageMerge (VRPLAbstPage aDstPage, VRPLAbstPage aSrcPage)
		{
			// move all items of aSrcPage
			long itemsToMoveCount = aSrcPage.GetItemsCount();

			// at end of aDstPage
			long moveDstStartingIndex = aDstPage.GetItemsCount();

			long movedDeepCount = 0L;

			if (aSrcPage.IsRefsPage()) 
			{
				// both are refs-pages

				// first adjust the parent of each page to move to "aDstPage"
				aSrcPage.ChangeSubPagesParent (0L, aSrcPage.GetItemsCount(), aDstPage);

				// next compute the balancing deep-count
				movedDeepCount = aSrcPage.SumSubPagesDeepItemsCounters (0L, aSrcPage.GetItemsCount());

			} 
			else 
			{
				// both are data-pages

				// the balancing deep-count is the count of the moved data-items
				movedDeepCount = itemsToMoveCount;
			}

			/*/
			move itemsToMoveCount items
				into aDstPage at moveDstStartingIndex
				from aSrcPage at 0
			end move
			/*/
			MovePagesItems (
				/*/dst:/*/ aDstPage, moveDstStartingIndex,
				/*/src:/*/ aSrcPage, 0L,
				/*/count:/*/ itemsToMoveCount
			);
			aDstPage.IncrItemsCount (itemsToMoveCount);
			aSrcPage.SetItemsCount (0L);

			// finally ...

			// balance deep-count among src/dst-pages
			BalancePagesDeepCount (aDstPage, aSrcPage, movedDeepCount);
			// done!
		}

//=======================================================================================
// Moving the last item into the next page

		public static void MoveLastItemIntoNextPage (VRPLAbstPage aDstPage, VRPLAbstPage aSrcPage)
		{
			// last item index in source page
			long lastItemIndex = aSrcPage.GetItemsCount() - 1L;

			long movedDeepCount = 0L;

			// insert a new null item in (aDstPage) at index (0)
			aDstPage.InsertItem (0L, null);

			// get the item to move from source-page
			object aItemToMove = aSrcPage.GetItemAt (lastItemIndex);

			if (aSrcPage.IsRefsPage())
			{
				// both are refs-pages
				VRPLAbstPage pageRef = (VRPLAbstPage) aItemToMove;

				// get the moved items deep-count
				movedDeepCount = pageRef.GetDeepItemsCount();

				// update the parent of the moved page
				pageRef.SetParentPage (aDstPage);
			}
			else
			{
				// both are data-pages

				// only one item was moved
				movedDeepCount = (1L);
			}

			// copy it to dest-page
			aDstPage.SetItemAt (0L, aItemToMove);

			// clear it from source-page
			aSrcPage.SetItemAt (lastItemIndex, null);

			// adjust items count of both pages
			aSrcPage.DecrItemsCount();
			aDstPage.IncrItemsCount();

			// finally ...

			// balance deep-count among src/dst-pages
			BalancePagesDeepCount (aDstPage, aSrcPage, movedDeepCount);
			// done!
		}

//=======================================================================================
// Moving the first item into the previous page

		public static void MoveFirstItemIntoPrevPage (VRPLAbstPage aDstPage, VRPLAbstPage aSrcPage)
		{
			// last item index in destination page
			long lastItemIndex = aDstPage.GetItemsCount();

			long movedDeepCount = 0L;

			// get the item to move
			object aItemToMove = aSrcPage.GetItemAt (0L);

			if (aSrcPage.IsRefsPage())
			{
				// both are refs-pages
				VRPLAbstPage pageRef = (VRPLAbstPage) aItemToMove;

				// get the moved items deep-count
				movedDeepCount = pageRef.GetDeepItemsCount();

				// update the parent of the moved page
				pageRef.SetParentPage (aDstPage);
			}
			else
			{
				// both are data-pages

				// only one item was moved
				movedDeepCount = (1L);
			}

			// copy it to dest-page
			aDstPage.SetItemAt (lastItemIndex, aItemToMove);

			// delete the item at index (0) from (aSrcPage)
			aSrcPage.DeleteItem (0L);

			// adjust items count of both refs-pages
			aSrcPage.DecrItemsCount();
			aDstPage.IncrItemsCount();

			// finally ...

			// balance deep-count among src/dst-pages
			BalancePagesDeepCount (aDstPage, aSrcPage, movedDeepCount);
			// done!
		}

//=======================================================================================
// moving items from aSrcPage into aDstPage prev page

		// Compacting Any page type

		public static void MoveAnyPageItems
			(VRPLAbstPage aDstPage, VRPLAbstPage aSrcPage, long aItemsToMoveCount)
		{
			// assert: aDstPage has room for [aItemsToMoveCount] items !!
			// assert: aSrcPage has at least [aItemsToMoveCount] items !!

			long movedDeepCount = 0L;

			if (aSrcPage.IsRefsPage())
			{
				// both are refs-pages

				// first adjust the parent of each page to move to "aDstPage"
				aSrcPage.ChangeSubPagesParent (0L, aItemsToMoveCount, aDstPage);

				// next compute the balancing deep-count
				movedDeepCount = aSrcPage.SumSubPagesDeepItemsCounters (0L, aItemsToMoveCount);
			}
			else
			{
				// both are data-pages

				movedDeepCount = aItemsToMoveCount;
			}

			// copy (aItemsToMoveCount) items from aSrcPage into aDstPage
			CopyPagesItems (
				/*/dst/*/ aDstPage, /*/dst-index/*/ aDstPage.GetItemsCount(),
				/*/src/*/ aSrcPage, /*/src-index/*/ (0L),
				/*/items-count/*/ aItemsToMoveCount
			);

			// delete (aItemsToMoveCount) items from aSrcPage at index (0)
			aSrcPage.DeleteItems (0L, aItemsToMoveCount);

			// adjust items count of aDstPage, aSrcPage
			aDstPage.IncrItemsCount (aItemsToMoveCount);
			aSrcPage.DecrItemsCount (aItemsToMoveCount);

			// finally balance deep-counts among dst/src-pages
			BalancePagesDeepCount (aDstPage, aSrcPage, movedDeepCount);
			// done!
		}

//=======================================================================================
// page insert / delete helper procs

#region page insert / delete helper procs

		public void AddToDeepItemsCount (long amountToAdd)
		{
			VRPLAbstPage aPage = this;
			while (aPage != null) {
				// add amountToAdd to the DeepItemsCount() of aPage
				aPage.IncrDeepItemsCount (amountToAdd);
				// up one level
				aPage = aPage.GetParentPage();
			}
		}

		public void SubFromDeepItemsCount (long amountToSub)
		{
			this.AddToDeepItemsCount ( - amountToSub );
		}

		public void AddOneToDeepItemsCount()
		{
			this.AddToDeepItemsCount (1L);
		}

		public void SubOneFromDeepItemsCount()
		{
			this.AddToDeepItemsCount (-1L);
		}

#endregion

//=======================================================================================
// inserting / deleting into/from a data page

#region inserting / deleting into/from a data page

		// inserting into a data-page

		public void InsertUserData (long aIndex, object userData)
		{
			// assert: this.IsDataPage() must be true !!

			// insert a new data item (userData) in (aPage) at index (aIndex)
			this.InsertItem (aIndex, userData);

			// [++] ItemsCount !!
			this.IncrItemsCount();

			// [+] add (1) to deep-count of aPage
			this.AddOneToDeepItemsCount();
		}

		// removing from a data-page

		public void RemoveUserData (long aIndex)
		{
			// assert: this.IsDataPage() must be true !!

			// delete the data item at index (aIndex) from (aPage)
			this.DeleteItem (aIndex);

			// [--] ItemsCount !!
			this.DecrItemsCount();

			// [-] sub (1) from deep-count ...
			this.SubOneFromDeepItemsCount();
		}

#endregion

//=======================================================================================
// inserting / deleting into/from into a refs page

#region inserting / deleting into/from into a refs page

		// inserting into a refs-page

		public void InsertPageRefExt
			(long aIndex, VRPLAbstPage aCallerPeerPage, VRPLAbstPage aPageToIns)
		{
			// assert: aPage.IsRefsPage() must be true !!

			// insert a new page-ref item (aPageToIns) in (aPage) at index (aIndex)
			this.InsertPageRef (aIndex, aPageToIns);

			// [++] ItemsCount !!
			this.IncrItemsCount();

			// set the parent of the inserted page to this one
			aPageToIns.SetParentPage (this);

			// link aPageToIns
			{//do
				// aCallerPeerPage may be null
				VRPLAbstPage aPrvPage = aCallerPeerPage;
				VRPLAbstPage aNxtPage = null;
				if (aPrvPage != null)
					aNxtPage = aPrvPage.GetNextPage();
				//end if
				aPageToIns.Link (aPrvPage, aNxtPage);
			}//end do

			{//do
				// [+] add to deep-count ...
				long aPgCnt = aPageToIns.GetDeepItemsCount();
				if (aPgCnt > 0L)
					// BOMB!
					// WE SHOULD INSERT ONLY EMPTY NEWLY CREATED PAGES
					/*/ this should never happen
						because (aPgRef) should point
						to an empty page
					/*/
					this.AddToDeepItemsCount (aPgCnt);
				//end	if
			}//end do

			// done
		}

		// removing from a refs-page

		public void RemovePageRefExt (long aIndex)
		{
			// assert: aPage.IsRefsPage() must be true !!

			// get the page-ref to remove
			VRPLAbstPage aPgRef = this.GetPageRefAt (aIndex);

			// delete the page-ref item at index (aIndex) from (aPage)
			this.DeletePageRef (aIndex);

			// [--] ItemsCount !!
			this.DecrItemsCount();

			// release parent
			aPgRef.SetParentPage (null);
			// release fwd/bwd links
			aPgRef.Unlink();

			{ // [-] sub from deep-count ...
				long aPgCnt = aPgRef.GetDeepItemsCount();
				if (aPgCnt > 0L)
					// BOMB!
					/*/ this should never happen
						because (aPgRef) should point
						to an empty page
						WE SHOULD REMOVE ONLY EMPTY OLD UNUSED PAGES
					/*/
					this.SubFromDeepItemsCount (aPgCnt);
				//end	if
			}//end

			// done
		}

#endregion

//=======================================================================================

//=======================================================================================

#endregion

//=======================================================================================

	} // VRPLAbstPage

//=======================================================================================
// Refs Page class

	public class VRPLRefsPage : VRPLAbstPage
	{
		public override int GetPageType()
		{
			return PageType.kRefsPage;
		}

		// instance data

		private long fDeepItemsCount = 0L;

		// init

		public VRPLRefsPage (long aSize) : 
			base (aSize)
		{}

		// deep items count

		public override long GetDeepItemsCount()
		{
			return this.fDeepItemsCount;
		}

		public override void SetDeepItemsCount (long aNewCount)
		{
			this.fDeepItemsCount = aNewCount;
		}

		public override void IncrDeepItemsCount (long aValue)
		{
			this.fDeepItemsCount += aValue;
		}
		public override void DecrDeepItemsCount (long aValue)
		{
			this.fDeepItemsCount -= aValue;
		}

		public override void IncrDeepItemsCount()
		{
			this.fDeepItemsCount += 1L;
		}

		public override void DecrDeepItemsCount()
		{
			this.fDeepItemsCount -= 1L;
		}

	}

//=======================================================================================
// Data Page class

	public class VRPLDataPage : VRPLAbstPage
	{
		public override int GetPageType()
		{
			return PageType.kDataPage;
		}

		// init

		public VRPLDataPage (long aSize) : 
			base (aSize)
      {}

	}

}

// that's all folks ...
