

namespace VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main
{

	using System;

//=======================================================================================

	using VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main.Support;

//=======================================================================================
// comparing iterators utils

	public class VRIncomparablePagedListIteratorsException : Exception
	{
		public VRIncomparablePagedListIteratorsException (VRPagedListIterator aIterA, VRPagedListIterator aIterB) :
			base ("incomparable iterators")
		{
			// do nothing else
		}
	}

//=======================================================================================
// the VRPagedListIterator class
//=======================================================================================

public class VRPagedListIterator : ICloneable, IComparable
{

//=======================================================================================
// instance data
//=======================================================================================

#region instance data

	// global paged-list indexing info
	private VRPagedList thePagedList = null;
	private long theGlobalIndex = 0L;

	// data page indexing info (to be validated)
	private VRPLAbstPage thePLDataPage = null;
	private long theLocalIndex = 0L;

	// the expected paged list struct state (validate if different from the one stored into the paged-list)
	private long theExpectedStructState = 0L;

#endregion

//=======================================================================================
// instance data properties
//=======================================================================================

#region instance data properties

	// {paged list, list index}

	internal VRPagedList InternalList {
		get { return this.thePagedList; }
		set { this.thePagedList = value; }
	}

	internal long InternalIndex {
		get { return this.theGlobalIndex; }
		set { this.theGlobalIndex = value; }
	}

	// {data page, local index}

	internal VRPLAbstPage Page {
		get { return this.thePLDataPage; }
		set { this.thePLDataPage = value; }
	}

	/*/
	internal long LocalIndex {
		get { return this.fTheLocalIndex; }
		set { this.fTheLocalIndex = value; }
	}
	/*/

	// the expected list struct state

	private long ExpectedListStructState {
		get { return this.theExpectedStructState; }
		set { this.theExpectedStructState = value; }
	}

#endregion

//=======================================================================================

//=======================================================================================
// methods
//=======================================================================================

//=======================================================================================
// comparing iterators utils
//=======================================================================================

#region comparing iterators utils

	public static bool IsComparableIterators (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		return (aIterA.List == aIterB.List);
	}

	public static void CheckComparableIterators (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		if ( ! IsComparableIterators (aIterA, aIterB) )
			throw new VRIncomparablePagedListIteratorsException (aIterA, aIterB);
	}

#endregion

//=======================================================================================
// overrides

#region System.Object overrides

	public override bool Equals (object thatObject)
	{
		if (thatObject == null) return false;
		if ( ! ( thatObject is VRPagedListIterator ) ) return false;
		VRPagedListIterator that = (VRPagedListIterator) thatObject;
		if ( ! IsComparableIterators (this, that) ) return false;
		return this.Index == that.Index;
	}

	public override int GetHashCode()
	{
		//return (int) this.CurrentIndex;
		long aValue = this.Index;
		return ( ((int)aValue) ^ ((int)(aValue >> 32)) );
	}

#endregion

//=======================================================================================
// interface IComparable

#region IComparable interface Members

	public int CompareTo (object obj)
	{
		// DONE:  Add VRPagedListIterator.CompareTo implementation
		VRPagedListIterator that = (VRPagedListIterator) obj;
		// ok!
		CheckComparableIterators (this, that);
		// ok!
		if (this < that)
			return (-1);
		if (this > that)
			return (+1);
		//else
		return 0;
	}

#endregion

//=======================================================================================
// interface ICloneable

#region interface ICloneable

	public object Clone()
	{
		return new VRPagedListIterator (this);
	}

#endregion

//=======================================================================================
// paged.list access

#region paged.list access

	// get [Paged]
	public VRPagedList GetList() { return this.thePagedList; }

	// set [Paged]
	public void SetList (VRPagedList aNewPList)
	{
		this.IterateOn (aNewPList);
	}

	// property alias
	public VRPagedList List
	{
		get { return this.GetList(); }
		set { this.SetList(value); }
	}

	public bool IsListValid() { return this.List != null; }

/*/
	// property
	public VRPagedList PagedList
	{
		get { return this.GetPagedList(); }
		set { this.SetPagedList (value); }
	}
/*/

#endregion

//=======================================================================================
// current index access

#region current index access

	// get [Current]
	public long GetIndex() { return this.theGlobalIndex; }

	// set [Current]
	public void SetIndex (long aNewIndex)
	{
		//this.IterateFrom (aNewIndex);
		this.GoToIndex (aNewIndex); // optmized call
	}

	// property [Current]
	public long Index
	{
		get { return this.GetIndex(); }
		set { this.SetIndex (value); }
	}

/*/
	// alias
	public long Index
	{
		get { return this.GetCurrentIndex(); }
		set { this.SetCurrentIndex (value); }
	}
/*/

#endregion

//=======================================================================================
// accessing the current data-page & local index

#region accessing the current data-page & local index

	// (private) data page

	// get
	private VRPLAbstPage GetDataPage() { return this.thePLDataPage; }
	// set
	private void SetDataPage (VRPLAbstPage aDataPage) { this.thePLDataPage = aDataPage; }

	// prop
	private VRPLAbstPage DataPage
	{
		get { return this.GetDataPage(); }
		set { this.SetDataPage (value); }
	}

	// internal (private) local index

	// get
	//private
	internal long GetLocalIndex() { return this.theLocalIndex; }

	// set
	//private
	internal void SetLocalIndex(long aNewLocalIndex) { this.theLocalIndex = aNewLocalIndex; }

	// prop
	// private
	internal long LocalIndex
	{
		get { return this.GetLocalIndex(); }
		set { this.SetLocalIndex (value); }
	}

//=======================================================================================

	// DEBUG begin

	public object GetDataPageObject()
	{
		return this.Page;
	}

	public object DataPageObject { get { return this.GetDataPageObject(); } }

	public long GetDataPageLocalIndex()
	{
		return this.LocalIndex;
	}

	public long DataPageLocalIndex { get { return this.GetDataPageLocalIndex(); } }

	// computing the current global index from (data page, local index)

	public long ComputeIndex()
	{
		this.UpdateAsNeeded();
		// updated!
		return VRPLAbstPage.ComputeGlobalIndexFromDataPageLocalIndexPair (
			this.Page, this.LocalIndex
		);
	}

	// to verify the current index validity

	public bool IsIndexValid()
	{
		this.UpdateAsNeeded();
		// updated!
		long computedIndex = this.ComputeIndex();
		return (this.Index == computedIndex);
	}

	// DEBUG end

//=======================================================================================

#endregion

//=======================================================================================
// underlying paged list properties

#region underlying paged list properties

	private static long SizeOf (VRPagedList aList)
	{
		if (aList != null)
			return aList.Size;
		//else
		return (0L);
	}

	// private macro: the list near move threshold

	private long GetListNearMoveThreshold()
	{
		if (this.List != null)
			return this.List.IteratorNearMoveThreshold;
		//else
		return (0L);
	}

	// private prop // not yet used
	private long ListNearMoveThreshold
	{
		get { return this.GetListNearMoveThreshold(); }
	}

#endregion

//=======================================================================================
// updating the iterator

#region updating the iterator

	private long GetListStructState()
	{
		if (this.List != null)
			return this.List.GetStructState();
		//else
		return (0L);
	}

	//private
	internal void SyncWithListStructState()
	{
		// synchronize with paged-list
		this.ExpectedListStructState = this.GetListStructState();
	}

	// is update needed ?

	public bool IsUpdateNeeded()
	{
		return (this.ExpectedListStructState != this.GetListStructState());
	}

	// to update (data page, local index) pair from (paged list, global index)

	private void UpdateDataPageLocalIndexPairFromPagedList()
	{
		VRPLAbstPage aDataPage = null;
		long aLocalIndex = this.Index;
		this.Page = null;
		this.LocalIndex = this.Index; //this.fTheGlobalIndex;
		if (this.List != null) {
			// update from paged-list
			this.List.AccessDataPageLocalIndexPairFromGlobalIndex (
				//ref this.fThePLDataPage, ref this.fTheLocalIndex,
				ref aDataPage, ref aLocalIndex,
				this.Index
			);
			this.Page = aDataPage;
			this.LocalIndex = aLocalIndex;
		}//end if
	}

	// to force an update

	public void ForceUpdate()
	{
		// update (data-page, local-index) pair from (paged-list, global-index)
		this.UpdateDataPageLocalIndexPairFromPagedList();
		// sync with paged-list
		this.SyncWithListStructState();
		// done!
	}

	public void UpdateAsNeeded()
	{
		if (this.IsUpdateNeeded())
			// an update is needed: force an update!
			this.ForceUpdate();
		//end if
	}

//=======================================================================================

	// aliases

	public bool IsInvalid()
	{
		return this.IsUpdateNeeded();
	}

	public bool IsValid()
	{
		return ! this.IsUpdateNeeded();
	}

	public void Validate()
	{
		this.ForceUpdate();
	}

	public void ValidateAsNeeded()
	{
		this.UpdateAsNeeded();
	}

//=======================================================================================

#endregion

//=======================================================================================
// init
//=======================================================================================

#region init

	public VRPagedListIterator (VRPagedList aList, long aIndex)
	{
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		// force an update!
		this.ForceUpdate();
	}

	public VRPagedListIterator (long aIndex, VRPagedList aList)
	{
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		// force an update!
		this.ForceUpdate();
	}

	public VRPagedListIterator (VRPagedList aList)
	{
		this.InternalList = aList;
		this.InternalIndex = (0L);
		// force an update!
		this.ForceUpdate();
	}

	public VRPagedListIterator (long aIndex)
	{
		this.InternalList = null;
		this.InternalIndex = aIndex;
		// force an update!
		this.ForceUpdate();
	}

	// default

	public VRPagedListIterator()
	{
		this.InternalList = null;
		this.InternalIndex = (0L);
		// force an update!
		this.ForceUpdate();
	}

//=======================================================================================

	// copy init

	public VRPagedListIterator (VRPagedListIterator that)
	{
		// copy List & Index
		this.InternalList = that.List;
		this.InternalIndex = that.Index;
		// copy DataPage & LocalIndex
		this.Page = that.Page;
		this.LocalIndex = that.LocalIndex;
		// this is the ame as that !!
		this.ExpectedListStructState = that.ExpectedListStructState;
		// force an update! -- NOT Needed !!
		//this.ForceUpdate(); // disabled
	}

	// iterb.CopyFrom (itera)

	public VRPagedListIterator CopyFrom (VRPagedListIterator that)
	{
		if ( ! ReferenceEquals (this, that) ) {
			// copy List & Index
			this.InternalList = that.List;
			this.InternalIndex = that.Index;
			// copy DataPage & LocalIndex
			this.Page = that.Page;
			this.LocalIndex = that.LocalIndex;
			// this is the ame as that !!
			this.ExpectedListStructState = that.ExpectedListStructState;
		}//end if
		return this;
	}


#endregion

//=======================================================================================
// iterative methods :: start iterating
//=======================================================================================

#region iterative methods :: low level and optimized methods

//=======================================================================================

	// force internal methods

	private void ForceIterateOn (VRPagedList aNewList, long aNewIndex)
	{
		// change both paged-list & global-index
		this.InternalList = aNewList;
		this.InternalIndex = aNewIndex;
		// force an update!
		this.ForceUpdate();
	}

	private void ForceIterateOn (VRPagedList aNewList)
	{
		// only the list is changed !!
		this.InternalList = aNewList;
		// this.fTheGlobalIndex = <<same global index>>;
		// force an update!
		this.ForceUpdate();
	}

//=======================================================================================

	private void ForceIterateFrom (long aNewIndex)
	{
		// set only the current iteration index
		this.InternalIndex = aNewIndex;
		// force an update!
		this.ForceUpdate();
	}

//=======================================================================================

	// optimized methods

	private void SmartIterateOn (VRPagedList aNewList, long aNewIndex)
	{
		if ( ! ReferenceEquals (this.List, aNewList) )
			// the list is changing
			// do not care of (aNewIndex) value
			this.ForceIterateOn (aNewList, aNewIndex);
		else
			if ( this.Index != aNewIndex )
			// !! this.List == aNewList
			// only the index is changing
			//this->Optimized_IterateFrom (aNewIndex);
			this.Index = aNewIndex;
		//else
		// !! this->List() == aNewList
		// !! this->Index() == aNewIndex
		// do nothing and stay at current position
		//end if
	}

	private void SmartIterateOn (VRPagedList aNewList)
	{
		if ( ! ReferenceEquals (this.List, aNewList) ) {
			// keep index
			this.ForceIterateOn (aNewList);
			// done
		}//end if
	}


#endregion

//=======================================================================================

#region iterative methods :: start iterating

	// start iterating

	public void IterateFrom (long aGlobalIndex, VRPagedList aPList)
	{
		/*/
		this.fThePagedList = aPList;
		this.fTheGlobalIndex = aGlobalIndex;
		// force an update!
		this.ForceUpdate();
		/*/
		this.SmartIterateOn (aPList, aGlobalIndex);
	}

	public void IterateOn (VRPagedList aPList, long aGlobalIndex)
	{
		/*/
		this.fThePagedList = aPList;
		this.fTheGlobalIndex = aGlobalIndex;
		// force an update!
		this.ForceUpdate();
		/*/
		this.SmartIterateOn (aPList, aGlobalIndex);
	}

	public void IterateFrom (long aGlobalIndex)
	{
		/*/
		// this.fThePagedList = <<same paged list>>;
		this.fTheGlobalIndex = aGlobalIndex;
		// force an update!
		this.ForceUpdate();
		/*/
		// optimized call
		this.Index = aGlobalIndex;
	}

	public void IterateOn (VRPagedList aPList)
	{
		/*/
		this.fThePagedList = aPList;
		// this.fTheGlobalIndex = <<same global index>>;
		// force an update!
		this.ForceUpdate();
		/*/
		this.SmartIterateOn (aPList);
	}

#endregion

//=======================================================================================
// range checking
//=======================================================================================

#region range checking

	// valid item index ?

	public bool IsItemIndexValid()
	{
		this.UpdateAsNeeded();
		// updated!
		if (this.Page != null)
			return this.Page.IsItemIndexValid (this.LocalIndex);
		else
			// no data-page: invalid item index!
			return false;
		//end if
	}

	// valid insert index ?

	public bool IsInsertIndexValid()
	{
		this.UpdateAsNeeded();
		// updated!
		if (this.Page != null)
			return this.Page.IsInsertIndexValid (this.LocalIndex);
		else
			// no data-page: local-index must be (0) to be a valid insert-index!
			return (this.LocalIndex == 0L);
		//end if
	}

#endregion

//=======================================================================================
// accessing data items
//=======================================================================================

#region accessing data items

#region current data item access

	// current data item access

	// get

	public object GetItem()
	{
		// update as needed ...
		this.UpdateAsNeeded();
		// updated!
		if (this.List != null)
			// valid paged-list
			if (this.Page != null)
				// valid current data page
				if (this.Page.IsItemIndexValid (this.LocalIndex)) {
					// valid data page item index
					object aItem = this.Page.GetItemAt (this.LocalIndex);
					// success!
					return aItem;
					// ok!
				}//end if
			//end if
		//end if
		// raise Invalid Item Index !!
		// failure!
		throw new VRPLInvalidItemIndexException (this.List, this.Index, SizeOf(this.List));
	}

	// alias
	//public object GetItem() { return this.GetCurrentItem(); }

	// set

	public void SetItem (object aNewItem)
	{
		// update as needed ...
		this.UpdateAsNeeded();
		// updated!

		if (this.List != null)
			// valid paged-list
			if (this.Page != null)
				// valid current data page
				if (this.Page.IsItemIndexValid (this.LocalIndex)) {
					// valid data page item index

					this.List.SetDataPageItem (
						this.Page, this.LocalIndex,
						this.Index, aNewItem
					);
					// success!

					// raise list contents changed event
					this.List.RaiseListChangedEvent();

					// done!
					return;

				}//end if
			//end if
		//end if
		// else failure
		throw new VRPLInvalidItemIndexException (this.List, this.Index, SizeOf(this.List));
	}

	// alias
	//public void SetItem (object aNewItem) { this.SetCurrentItem (aNewItem); }

/*/
	// property

	public object CurrentItem
	{
		get { return this.GetCurrentItem(); }
		set { this.SetCurrentItem (value); }
	}
/*/

	// alias
	public object Item
	{
		get { return this.GetItem(); }
		set { this.SetItem (value); }
	}

	// swap (a,b)

	public static void SwapItems (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		/*/
		object aItemA = aIterA.CurrentItem;
		object aItemB = aIterB.CurrentItem;
		// swap
		aIterA.CurrentItem = aItemB;
		aIterB.CurrentItem = aItemA;
		/*/
		object tmp = aIterA.Item; // tmp = a
		aIterA.Item = aIterB.Item; // a = b
		aIterB.Item = tmp; // b = a // b = tmp
	}

#endregion

//=======================================================================================
// next/prev data item access

#region next/prev data item access

	// prev item access

	public object GetPrevItem()
	{
		object aPrevItem = null;
		// go to prev item
		this.PrevItem();
		try {
			// try to access the prev item
			aPrevItem = this.GetItem();
			// ok!
		} finally {
			// restore current position
			this.NextItem();
		}
		return aPrevItem;
	}

	public void SetPrevItem (object aNewItem)
	{
		// go to prev item
		this.PrevItem();
		try {
			// try to access the prev item
			this.SetItem (aNewItem);
			// ok!
		} finally {
			// restore current position
			this.NextItem();
		}
	}

	// prop
	public object PrevItemValue
	{
		get { return this.GetPrevItem(); }
		set { this.SetPrevItem (value); }
	}

	// next item access

	public object GetNextItem()
	{
		object aPrevItem = null;
		this.NextItem(); // go to next item
		try {
			// try to access the next item
			aPrevItem = this.GetItem();
			// ok!
		} finally {
			// restore current position
			this.PrevItem();
		}
		return aPrevItem;
	}

	public void SetNextItem (object aNewItem)
	{
		this.NextItem(); // go to next item
		try {
			// try to access the next item
			this.SetItem (aNewItem);
			// ok!
		} finally {
			// restore current position
			this.PrevItem();
		}
	}

	// prop
	public object NextItemValue
	{
		get { return this.GetNextItem(); }
		set { this.SetNextItem (value); }
	}

#endregion

//=======================================================================================
// offeset data item access

#region offeset data item access

	public object GetOffsetItem (long aOffset)
	{
		object aOfsItem = null;
		// go to that item offset
		this.Skip (aOffset);
		try {
			// try to access the offset item
			aOfsItem = this.GetItem();
			// ok!
		} finally {
			// restore current position
			this.Skip ( - aOffset );
		}
		return aOfsItem;
	}

	public void SetOffsetItem (long aOffset, object aNewItem)
	{
		// go to that item offset
		this.Skip (aOffset);
		try {
			// try to access the offset item
			this.SetItem (aNewItem);
			// ok!
		} finally {
			// restore current position
			this.Skip ( - aOffset );
		}
	}

#endregion

//=======================================================================================
// index data item access

#region index data item access

	public object GetItemAtIndex (long aIndex)
	{
		object aItem = null;
		long aPrevIndex = this.GetIndex();
		// goto that index
		this.GoTo (aIndex);
		try {
			// try to access the item at aIndex
			aItem = this.GetItem();
			// ok!
		} finally {
			// restore current position
			this.GoTo (aPrevIndex);
		}
		return aItem;
	}

	public void SetItemAtIndex (long aIndex, object aNewItem)
	{
		long aPrevIndex = this.GetIndex();
		// goto that index
		this.GoTo (aIndex);
		try {
			// try to access the item at aIndex
			this.SetItem (aNewItem);
			// ok!
		} finally {
			// restore current position
			this.GoTo (aPrevIndex);
		}
	}

/*/
	// Item[i]
	public object this [long index]
	{
		get {
			return this.GetItemAtIndex (index);
		}
		set {
			this.SetItemAtIndex (index, value);
		}
	}
/*/

#endregion

//=======================================================================================

#endregion

//=======================================================================================
// iterative methods :: low level methods
//=======================================================================================

#region iterative methods :: low level methods

	// low level methods

	// next data-page item

	private void NextDataPageItem()
	{
		// get the current data-page
		VRPLAbstPage currDataPage = this.Page;

		//	get the current data-page items count
		long currDataPageItemsCount = 0L;
		if (currDataPage != null)
			currDataPageItemsCount = currDataPage.GetItemsCount();
		//end	if

		unchecked {
			// always increase this local-index !!
			//++ this.fTheLocalIndex; // ++
			this.LocalIndex = this.LocalIndex + 1L;
		}

		// check is it is out-of-bounds
		if (this.LocalIndex >= currDataPageItemsCount)
		{
			// we are out of the Current Data-Page bounds !!
			// we	have to skip to the next data-page
			// do NOT skip over a null page !!
			VRPLAbstPage nextDataPage = null;
			if (currDataPage != null)
				nextDataPage = currDataPage.GetNextPage();
			//end	if
			if (nextDataPage != null) {
				// this loop is just in the ugly case nextDataPage is empty !!
				// skip any empty next page loop
				while (true) {
					if (nextDataPage == null) break;
					//end if
					if (nextDataPage.GetItemsCount() > 0L)
						//	should be always true !!
						break;
					//end if
					// next
					nextDataPage = nextDataPage.GetNextPage();
				}//loop
				// check for a valid next data-page
				if (nextDataPage != null) {
					// we got a non-empty next data-page
					this.Page = nextDataPage;
					// skip to the first item of the next page
					this.LocalIndex = (0L);
				}
				//otherwise
					// remain on the same page
					// keep the	previously in-cremented	local-index
				//end if
			}//if
			// the local index was out-of-bounds
		}//if
	}

	// prev data-page item

	private void PrevDataPageItem()
	{
		// get the current data-page
		VRPLAbstPage currDataPage = this.Page;

		unchecked {
			//	always decrease this	local-index	!!
			//-- this.fTheLocalIndex; // --
			this.LocalIndex = this.LocalIndex - 1L;
		}

		// check is it is out-of-bounds
		if (this.LocalIndex < 0L) {
			// the local index is out-of-bounds
			VRPLAbstPage prevDataPage = null;
			if (currDataPage != null)
				prevDataPage = currDataPage.GetPrevPage();
			//end	if

			if (prevDataPage != null) {
				// this loop is just in the ugly case prevDataPage is empty	!!
				// skip any empty prev page loop
				while (true) {
					if (prevDataPage == null) break;
					//end if
					if (prevDataPage.GetItemsCount() > 0L)
						// should be always true !!
						break;
					//end if
					// prev
					prevDataPage = prevDataPage.GetPrevPage();
				}//loop
				// check for a valid prev data-page
				if (prevDataPage != null) {
					// we got a non-empty prev data-page
					this.Page = prevDataPage;
					// skip to the Last item of the prev page
					this.LocalIndex = (prevDataPage.GetItemsCount() - 1L);
				}
				//otherwise
					// remain on the same page
					// keep the previously decremented local-index
				//end if
				// there was a prev data-page
			} //if
			// the local index was out-of-bounds
		} //if
	}

#endregion

//=======================================================================================
// iterative methods :: continue iterating
//=======================================================================================

#region iterative methods :: continue iterating

	// next item

	// {++}
	public void NextItem()
	{
		this.UpdateAsNeeded();
		// updated!
		this.NextDataPageItem();
		// finally
		unchecked {
			//++ this.fTheGlobalIndex; // ++
			this.InternalIndex = this.InternalIndex + 1L;
		}
	}

	// prev item

	// {--}
	public void PrevItem()
	{
		this.UpdateAsNeeded();
		// updated!
		this.PrevDataPageItem();
		// finally
		unchecked {
			//-- this.fTheGlobalIndex; // --
			this.InternalIndex = this.InternalIndex - 1L;
		}
	}

	// to skip items

	// {+=,-=}
	public void SkipItems (long aSkipOffset)
	{
		if (aSkipOffset != 0)
		{
			if (aSkipOffset > 0L)
				while (aSkipOffset > 0L) {
					// next
					this.NextItem();
					-- aSkipOffset; // --
				}//repeat
			else
				while (aSkipOffset < 0L) {
					// prev
					this.PrevItem();
					++ aSkipOffset; // ++
				}//repeat
			//end if
		}//if
	}

#endregion

//=======================================================================================

#region to smart skip items

	// to smart skip items

	public void SmartSkipItems (long aSkipOffset, long aThresholdValue)
	{
		long aAbsThresholdValue = Math.Abs (aThresholdValue);
		long aAbsSkipOffset = Math.Abs (aSkipOffset);
		if (aAbsSkipOffset > aAbsThresholdValue)
		{
			// far move: perform an absolute position
			long aOldIndex = this.GetIndex();
			long aNewIndex = aOldIndex + aSkipOffset;
			//this.IterateFrom (aNewIndex);
			this.ForceIterateFrom (aNewIndex);
		}
		else
			// near move: crawl items
			this.SkipItems (aSkipOffset);
		//end if
	}

	// to smart goto item

	public void SmartGoToItem (long aItemIndex, long aThresholdValue)
	{
		// compute offset
		long aSkipOffset = (aItemIndex - this.GetIndex()); // distance
		// skip
		this.SmartSkipItems (aSkipOffset, aThresholdValue);
	}

#endregion

//=======================================================================================

#region Skip Items Macros

	// //aThresholdValue: this.GetListDataPageSize() * 3L // arbitrary value!!

	/*/
		the following will use the threshold value provided by the list
		to perform near moves
	/*/

	// SkipOffset (offset)

	public void SkipOffset (long aSkipOffset)
	{
		this.SmartSkipItems (
			aSkipOffset,
			this.GetListNearMoveThreshold()
		);
	}

	// GoToIndex (index)

	public void GoToIndex (long aNewIndex)
	{
		this.SmartGoToItem (
			aNewIndex,
			this.GetListNearMoveThreshold()
		);
	}

//=======================================================================================

	// macros

	public void Next() { this.NextItem(); }
	public void Prev() { this.PrevItem(); }

	// skip/goto

	public void GoTo (long aNewIndex)
	{
		// compute offset
		//long aSkipOffset = (aNewIndex - this.GetCurrentIndex()); // distance
		// skip
		//this.SkipOffset (aSkipOffset);
		//
		this.GoToIndex (aNewIndex);
	}

	public void Skip (long aOffset)
	{
		this.SkipOffset (aOffset);
	}

	// move by (offset) // move to (index)

	public void MoveBy (long aOffset)
	{
		this.Skip (aOffset);
	}

	public void MoveTo (long aNewIndex)
	{
		this.GoTo (aNewIndex);
	}


#endregion

//=======================================================================================
// iterative operators

#region iterative operators

	// [++]
	public static VRPagedListIterator operator ++ (VRPagedListIterator aIter)
	{
		aIter.Next();
		return aIter;
	}

	// [--]
	public static VRPagedListIterator operator -- (VRPagedListIterator aIter)
	{
		aIter.Prev();
		return aIter;
	}

//=======================================================================================

	public static VRPagedListIterator operator + (VRPagedListIterator aIter, long aOffset)
	{
		aIter.Skip (aOffset);
		return aIter;
	}
	public static VRPagedListIterator operator + (long aOffset, VRPagedListIterator aIter)
	{
		aIter.Skip (aOffset);
		return aIter;
	}

	public static VRPagedListIterator operator - (VRPagedListIterator aIter, long aOffset)
	{
		aIter.Skip ( - aOffset );
		return aIter;
	}

	public static long operator - (long aNumber, VRPagedListIterator aIter)
	{
		return ( aNumber - aIter.Index );
	}

	public static long operator - (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		return ( aIterA.Index - aIterB.Index );
	}

#endregion

//=======================================================================================
// comparison operators

#region comparison operators

	public static bool operator == (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		return (aIterA.Index == aIterB.Index);
	}
	public static bool operator != (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		return (aIterA.Index != aIterB.Index);
	}

	public static bool operator < (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		return (aIterA.Index < aIterB.Index);
	}
	public static bool operator > (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		return (aIterA.Index > aIterB.Index);
	}

	public static bool operator <= (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		return (aIterA.Index <= aIterB.Index);
	}
	public static bool operator >= (VRPagedListIterator aIterA, VRPagedListIterator aIterB)
	{
		return (aIterA.Index >= aIterB.Index);
	}

//=======================================================================================

	public static bool operator == (VRPagedListIterator aIter, long aIndex)
	{
		return (aIter.Index == aIndex);
	}
	public static bool operator == (long aIndex, VRPagedListIterator aIter)
	{
		return (aIndex == aIter.Index);
	}

	public static bool operator != (VRPagedListIterator aIter, long aIndex)
	{
		return (aIter.Index != aIndex);
	}
	public static bool operator != (long aIndex, VRPagedListIterator aIter)
	{
		return (aIndex != aIter.Index);
	}

//=======================================================================================

	// [<]
	public static bool operator < (VRPagedListIterator aIter, long aIndex)
	{
		return (aIter.Index < aIndex);
	}
	public static bool operator < (long aIndex, VRPagedListIterator aIter)
	{
		return (aIndex < aIter.Index);
	}

	// [>]
	public static bool operator > (VRPagedListIterator aIter, long aIndex)
	{
		return (aIter.Index > aIndex);
	}
	public static bool operator > (long aIndex, VRPagedListIterator aIter)
	{
		return (aIndex > aIter.Index);
	}

//=======================================================================================

	// [<=]
	public static bool operator <= (VRPagedListIterator aIter, long aIndex)
	{
		return (aIter.Index <= aIndex);
	}
	public static bool operator <= (long aIndex, VRPagedListIterator aIter)
	{
		return (aIndex <= aIter.Index);
	}

	// [>=]
	public static bool operator >= (VRPagedListIterator aIter, long aIndex)
	{
		return (aIter.Index >= aIndex);
	}
	public static bool operator >= (long aIndex, VRPagedListIterator aIter)
	{
		return (aIndex >= aIter.Index);
	}


#endregion


//=======================================================================================

//=======================================================================================
// inserting / deleting items at current index
//=======================================================================================

#region inserting / deleting items at current index

	// to insert an item at current position

	public void InsertItem (object aItemData)
	{
		this.UpdateAsNeeded();
		// updated!

		// get the paged list
		VRPagedList aList = this.List;
		// get the current index
		long aGlobalIndex = this.Index;

		if (aList.IsAutoOrdered())
			aList.CheckInsertOrderedItemAtIndex (aGlobalIndex, aItemData);
		// ok!

		// get the current (page, index)
		VRPLAbstPage aDataPageRef = this.Page;
		long aDataPageIndex = this.LocalIndex;

		// range checking
		if ( ! VRPagedList.IsPageInsertIndexValid (aDataPageRef, aDataPageIndex) )
			// invalid insert index
			throw new VRPLInvalidInsertIndexException (aList, aGlobalIndex, aList.ItemsCount);
		//end if

		// insert!
		try {
			// insert!
			aList.InsertIntoDataPageExt (
				ref aDataPageRef, ref aDataPageIndex,
				aItemData, aGlobalIndex
			);
			// ok!
		} catch (Exception) {
			// failure!
			//this.ForceUpdate(); // there is NO need to force an update here!

			/*/
				this code keeps this iterator updated just in the case
				"aList.InsertIntoDataPageExt()" performs some rollback
				remove

				however, no rollback remove is actually done
			/*/

			// begin {

			if (aDataPageRef == null) {
				// we have removed the last item so "aDataPageRef" is null
				// get last data-page
				aDataPageRef = aList.GetLastDataPage();
				// test
				if (aDataPageRef == null)
					// the list is empty
					aDataPageIndex = 0L;
				else
					// go to just past end of the last data-page
					aDataPageIndex = aDataPageRef.GetItemsCount();
				//end if
			}//end if

			// update this iterator
			this.Page = aDataPageRef;
			this.LocalIndex = aDataPageIndex;
			// resync current struct state
			this.SyncWithListStructState();

			// } end

			// raise again!
			throw;
		}
		// ok!

		// success!
		// stay on the currently inserted item!
		// -- aDataPageIndex; // -- // not needed !!

		// update this iterator
		this.Page = aDataPageRef;
		this.LocalIndex = aDataPageIndex;

		// current struct state
		this.SyncWithListStructState();

		// next item!
		this.NextItem();

		// success!
		// list changed!
		aList.RaiseListChangedEvent();

		// done!
	}


	// alias

	public void Insert (object aItemData)
	{
		this.InsertItem (aItemData);
	}


//=======================================================================================

	// to delete an item at current position

	public object DeleteItem()
	{
		this.UpdateAsNeeded();
		// updated!

		// get the paged list
		VRPagedList aList = this.List;
		// get the current index
		long aGlobalIndex = this.Index;

		// get the (page, index) of the current item to delete
		VRPLAbstPage aDataPageRef = this.Page;
		long aDataPageIndex = this.LocalIndex;

		// range checking
		if ( ! VRPagedList.IsPageItemIndexValid (aDataPageRef, aDataPageIndex) )
			// invalid delete index
			throw new VRPLInvalidItemIndexException(aList, aGlobalIndex, aList.Size);
		// ok!

		/*/
		if (aDataPageRef == null)
			// the B+Tree should be empty
			// invalid delete index
			throw new VRPLInvalidItemIndexException (aList, aGlobalIndex, aList.ItemsCount);
		// ok!
		if ( ! aDataPageRef.IsItemIndexValid (aDataPageIndex) )
			// invalid delete index
			throw new VRPLInvalidItemIndexException (aList, aGlobalIndex, aList.ItemsCount);
		// ok!
		/*/

		object aItemToRemove = aDataPageRef.GetItemAt (aDataPageIndex);

		// delete!
		try {
			// delete!
			aList.RemoveFromDataPageExt (
				ref aDataPageRef, ref aDataPageIndex,
				aGlobalIndex
			);
			// ok!
		} catch (Exception) {
			// failure!
			// this should never happen!
			//this.ForceUpdate(); // there is NO need to force an update here!
			// raise again
			throw;
		}
		// ok!

		// success!

      // update this iterator
      //if (aDataPageRef == null)
         // we have removed the last item so "aDataPageRef" is null
         //this.ForceUpdate();
      //else {

		if (aDataPageRef == null) {
			// we have removed the last item so "aDataPageRef" is null
			// get last data-page
			aDataPageRef = aList.GetLastDataPage();
			// test
			if (aDataPageRef == null)
				// the list is empty
				aDataPageIndex = 0L;
			else
				// go to just past end of the last data-page
				aDataPageIndex = aDataPageRef.GetItemsCount();
			//end if
		}//end if

      // update this iterator
      this.Page = aDataPageRef;
      this.LocalIndex = aDataPageIndex;
      // resync current struct state
      this.SyncWithListStructState();

      //}

		// list changed!
		aList.RaiseListChangedEvent();

		// done!
		return aItemToRemove;
	}

/*/
	// alias

	public object DeleteItem()
	{
		return this.DeleteCurrentItem();
	}
/*/

	// alias

	public object Delete()
	{
		return this.DeleteItem();
	}

//=======================================================================================

	// to delete a range from current index

	public void DeleteRange (long aRangeCount)
	{
		// get iterator position
		//long aRangeIndex = this.Index;
		// count down
		long aDownCount = aRangeCount;
		while (aDownCount > 0L) {
			// reposition on external change
			//if (this.Index != aRangeIndex)
				// (re)position
				//this.Index = aRangeIndex;
			//end if
			// delete!
			this.Delete();
			// next
			-- aDownCount;
		}
	}

	public void Delete (long aRangeCount)
	{
		this.DeleteRange (aRangeCount);
	}


//=======================================================================================


#endregion

//=======================================================================================


//=======================================================================================
// Locating Items in an auto-ordered list
//=======================================================================================

//=======================================================================================

	// find item

	// first

	public void FindFirstOrderedItem (object aKeyValue, IVRPLItemComparator aComparator)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// last

	public void FindLastOrderedItem (object aKeyValue, IVRPLItemComparator aComparator)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// find nearest item

	// first

	public void FindFirstNearestOrderedItem (object aKeyValue, IVRPLItemComparator aComparator)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// last

	public void FindLastNearestOrderedItem (object aKeyValue, IVRPLItemComparator aComparator)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

//=======================================================================================

	// first

	public void FindFirstOrderedItem (VRPagedList aList, object aKeyValue, IVRPLItemComparator aComparator)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// last

	public void FindLastOrderedItem (VRPagedList aList, object aKeyValue, IVRPLItemComparator aComparator)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// find nearest item

	// first

	public void FindFirstNearestOrderedItem (VRPagedList aList, object aKeyValue, IVRPLItemComparator aComparator)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// last

	public void FindLastNearestOrderedItem (VRPagedList aList, object aKeyValue, IVRPLItemComparator aComparator)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

//=======================================================================================


//=======================================================================================
// Simple methods (on the same list)
//=======================================================================================

#region Locating Items in an auto-ordered list :: Simple methods (on the same list)

	// Nearest value/key

	// direct

	// value
	public void FindFirstNearestOrderedItemValue (object aKeyValue)
	{
      VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.ItemToItemComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// key
	public void FindFirstNearestOrderedItemKey (object aKeyValue)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.KeyToItemComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}


	// reverse

	// value
	public void FindLastNearestOrderedItemValue (object aKeyValue)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.ItemToItemComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// key
	public void FindLastNearestOrderedItemKey (object aKeyValue)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.KeyToItemComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}


//=======================================================================================

	// Actual value/key

	// direct

	// value
	public void FindFirstOrderedItemValue (object aKeyValue)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.ItemToItemComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// key
	public void FindFirstOrderedItemKey (object aKeyValue)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.KeyToItemComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}


	// reverse

	// value
	public void FindLastOrderedItemValue (object aKeyValue)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.ItemToItemComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// key
	public void FindLastOrderedItemKey (object aKeyValue)
	{
		VRPagedList aList = this.List;
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.KeyToItemComparator
		);
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

#endregion

//=======================================================================================

//=======================================================================================
// Complete methods
//=======================================================================================

	// also set the paged-list for this iterator!!

#region Locating Items in an auto-ordered list :: Complete methods

//=======================================================================================

	// Nearest value/key


	// direct

	// value
	public void FindFirstNearestOrderedItemValue (VRPagedList aList, object aKeyValue)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.ItemToItemComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// key
	public void FindFirstNearestOrderedItemKey (VRPagedList aList, object aKeyValue)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
         aList.KeyToItemComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}


	// reverse

	// value
	public void FindLastNearestOrderedItemValue (VRPagedList aList, object aKeyValue)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.ItemToItemComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// key
	public void FindLastNearestOrderedItemKey (VRPagedList aList, object aKeyValue)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.KeyToItemComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}


//=======================================================================================

	// Actual value/key


	// direct

	// value
	public void FindFirstOrderedItemValue (VRPagedList aList, object aKeyValue)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.ItemToItemComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// key
	public void FindFirstOrderedItemKey (VRPagedList aList, object aKeyValue)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindFirstOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.KeyToItemComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}


	// reverse

	// item
	public void FindLastOrderedItemValue (VRPagedList aList, object aKeyValue)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.ItemToItemComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

	// key
	public void FindLastOrderedItemKey (VRPagedList aList, object aKeyValue)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = aList.FindLastOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aList.KeyToItemComparator
		);
		this.InternalList = aList;
		this.InternalIndex = aIndex;
		this.Page = aDataPage;
		this.LocalIndex = aLocalIndex;
		this.SyncWithListStructState();
	}

//=======================================================================================

#endregion


//=======================================================================================

//=======================================================================================
// to Find item in an auto ordered list
//=======================================================================================

#region Find item in an auto ordered list

	public void FindOrderedItem (
		VRPagedList aList,
		object aKeyValue,
		bool isReverse, // isDirect
		bool isNearest, // isActual
		IVRPLItemComparator aComparator
	) {
		bool isDirect = ! isReverse;
		bool isActual = ! isNearest;
		if (isActual) {
			// find item
			if (isDirect)
				this.FindFirstOrderedItem (aList, aKeyValue, aComparator);
			else
				this.FindLastOrderedItem (aList, aKeyValue, aComparator);
			//end if
		} else {
			// find nearest item
			if (isDirect)
				this.FindFirstNearestOrderedItem (aList, aKeyValue, aComparator);
			else
				this.FindLastNearestOrderedItem (aList, aKeyValue, aComparator);
			//end if
		}//end if
	}

//=======================================================================================

	public void FindOrderedItem (
		VRPagedList aList,
		object aKeyValue,
		bool isReverse, // isDirect
		bool isNearest, // isActual
		bool isValue // isKey
	) {
		bool isDirect = ! isReverse;
		bool isActual = ! isNearest;
		//bool isNearest = ! isActual;
		bool isKey = ! isValue;
		// switch ...
		if (isNearest) {
			// nearest
			if (isDirect) {
				// direct
				if (isKey)
					// key
					this.FindFirstNearestOrderedItemKey (aList, aKeyValue);
				else
					// value
					this.FindFirstNearestOrderedItemValue (aList, aKeyValue);
				//end if
			} else {
				// reverse
				if (isKey)
					// key
					this.FindLastNearestOrderedItemKey (aList, aKeyValue);
				else
					//	value
					this.FindLastNearestOrderedItemValue (aList, aKeyValue);
				//end if
			}//end if
		} else {
			// actual
			if (isDirect) {
				// direct
				if (isKey)
					// key
					this.FindFirstOrderedItemKey (aList, aKeyValue);
				else
					// value
					this.FindFirstOrderedItemValue (aList, aKeyValue);
				//end if
			} else {
				// reverse
				if (isKey)
					// key
					this.FindLastOrderedItemKey (aList, aKeyValue);
				else
					// value
					this.FindLastOrderedItemValue (aList, aKeyValue);
				//end if
			}//end if
		}//end if
		// done
	}

#endregion

//=======================================================================================


//=======================================================================================
// find ordered item constructor

#region find ordered item constructor

	public VRPagedListIterator(
		VRPagedList aList,
		object aKeyValue,
		bool isReverse, // isDirect
		bool isNearest, // isActual,
		IVRPLItemComparator aComparator
	) {
		this.FindOrderedItem (aList, aKeyValue, isReverse, isNearest, aComparator);
		// done!
	}

	public VRPagedListIterator (
		VRPagedList aList,
		object aKeyValue,
		bool isReverse, // isDirect
		bool isNearest, // isActual,
		bool isValue // isKey
	) {
		this.FindOrderedItem (aList, aKeyValue, isReverse, isNearest, isValue);
		// done!
	}

#endregion


//=======================================================================================


//=======================================================================================


} // VRPagedListIterator class


} // namespace

// that's all folks ...
