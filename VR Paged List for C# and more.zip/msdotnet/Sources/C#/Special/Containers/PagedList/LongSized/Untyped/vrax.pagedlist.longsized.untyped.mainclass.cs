
namespace VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main
{

	using System;

	using System.Collections;

	using System.Runtime.Serialization;

//=======================================================================================

	using VRAdrixNT.Utils.LongToIntSafeCvt;

	using VRAdrixNT.Utils.RangeCheck;

//=======================================================================================

	using VRAdrixNT.Containers.PagedList.LongSized.Untyped.Main.Support;

//=======================================================================================
// Paged-List Runtime Exceptions
//=======================================================================================

#region Paged-List Runtime Exceptions

//=======================================================================================

	// paged-list base exception

	public class VRPLBaseException : Exception
	{
		private VRPagedList theList = null;
		public VRPagedList GetList() { return this.theList; }
		public VRPagedList List { get { return this.GetList(); } }
		// init
		public VRPLBaseException (VRPagedList aList, string aMsg) :
			base (aMsg)
		{
			this.theList = aList;
		}
	}

//=======================================================================================

	// internal paged list error exception

	public class VRPLInternalListErrorException : VRPLBaseException
	{
		// init
		public VRPLInternalListErrorException (VRPagedList aList, string aMsg) :
			base (aList, aMsg)
		{}
		public VRPLInternalListErrorException (VRPagedList aList) :
			base (aList, "internal paged-list error.")
		{}
	}

//=======================================================================================

	// paged list is running except

	public class VRPLPagedListIsRunningException : VRPLBaseException
	{
		// init
		public VRPLPagedListIsRunningException (VRPagedList aList) :
			base (aList, "paged-list is running.")
		{}
	}

//=======================================================================================

	// list size limit was reached

	public class VRPLReachedListSizeLimitException : VRPLBaseException
	{
		// init
		public VRPLReachedListSizeLimitException (VRPagedList aList) :
			base (aList, "WARNING: paged-list size limit was reached.")
		{}
	}

//=======================================================================================

	// invalid index

	public class VRPLInvalidIndexException : VRPLBaseException
	{
		private long theIndex = 0L;
		private long theCount = 0L;
		public long GetIndex() { return this.theIndex; }
		public long GetCount() { return this.theCount; }
		public long Index { get { return this.GetIndex(); } }
		public long Count { get { return this.GetCount(); } }
		// init
		public VRPLInvalidIndexException (VRPagedList aList, long aIndex, long aCount, string aMsg) :
			base (aList, "invalid " + aMsg + " index. " + "index: (" + aIndex + ") count: (" + aCount + ").")
		{
			this.theIndex = aIndex;
			this.theCount = aCount;
		}
	}

	// invalid item index

	public class VRPLInvalidItemIndexException : VRPLInvalidIndexException
	{
		public VRPLInvalidItemIndexException (VRPagedList aList, long aIndex, long aCount) :
			base (aList, aIndex, aCount, "item")
		{}
	}

	// invalid insert index

	public class VRPLInvalidInsertIndexException : VRPLInvalidIndexException
	{
		public VRPLInvalidInsertIndexException (VRPagedList aList, long aIndex, long aCount) :
			base (aList, aIndex, aCount, "insert")
		{}
	}

//=======================================================================================

	// ordered list exception

	public class VRPLOrderedListException : VRPLBaseException
	{
		public VRPLOrderedListException (VRPagedList aList) :
			base (aList, "invalid operation: the list is ordered.")
		{}
	}

	// unordered list exception

	public class VRPLUnorderedListException : VRPLBaseException
	{
		public VRPLUnorderedListException (VRPagedList aList) :
			base (aList, "invalid operation: the list is unordered.")
		{}
	}

//=======================================================================================

	// the list do not allow duplicate items exception

	public class VRPListDoNotAllowDuplicatesException : VRPLBaseException
	{
		private long theIndex = 0L;
		private object theItem = null;
		// accessors
		public long GetIndex() { return this.theIndex; }
		public object GetItem() { return this.theItem; }
		// props
		public long Index { get { return this.GetIndex(); } }
		public object Item { get { return this.GetItem(); } }
		// init
		public VRPListDoNotAllowDuplicatesException (VRPagedList aList, long aIndex, object aItem) :
			base (aList,
				"the list do not allow duplicate items. " +
				"duplicate found at (" + aIndex + ")."
			)
		{
			this.theIndex = aIndex;
			this.theItem = aItem;
		}
	}

//=======================================================================================

	// list property change veto exception

	public class VRPLListPropertyChangeVetoException : VRPLBaseException
	{
		private VRPLPropId thePropId;
		private object theOldValue = null;
		private object theNewValue = null;
		// accessors
		public VRPLPropId GetPropId() { return this.thePropId; }
		public object GetOldValue() { return this.theOldValue; }
		public object GetNewValue() { return this.theNewValue; }
		// props
		public VRPLPropId PropId { get { return this.GetPropId(); } }
		public object OldValue { get { return this.GetOldValue(); } }
		public object NewValue { get { return this.GetNewValue(); } }
		// init
		public VRPLListPropertyChangeVetoException (
			VRPagedList aList,
			VRPLPropId aPropId,
			object aOldValue,
			object aNewValue
		) :
			base (aList, "list property change veto.")
		{
			this.thePropId = aPropId;
			this.theOldValue = aOldValue;
			this.theNewValue = aNewValue;
		}
	}

//=======================================================================================

	// invalid size exception

	public class VRPLInvalidSizeException : VRPLBaseException
	{
		private long theSize = 0L;
		// accessors
		public long GetSize() { return this.theSize; }
		// props
		public long Size { get { return this.GetSize(); } }
		// init
		public VRPLInvalidSizeException (VRPagedList aList, string aMsg, long aSize) :
			base (aList, aMsg)
		{
			this.theSize = aSize;
		}
		public VRPLInvalidSizeException (VRPagedList aList, string aMsg) :
			base (aList, aMsg)
		{}
	}

	// invalid data page size exception

	public class VRPLInvalidDataPageSizeException : VRPLInvalidSizeException
	{
		public VRPLInvalidDataPageSizeException (VRPagedList aList) :
			base (aList, "invalid data page size.")
		{}
	}

	// invalid refs page size exception

	public class VRPLInvalidRefsPageSizeException : VRPLInvalidSizeException
	{
		public VRPLInvalidRefsPageSizeException (VRPagedList aList) :
			base (aList, "invalid refs page size.")
		{}
	}

/*/ NOT USED Anymore !!

	// invalid items range size exception

	public class VRPLInvalidItemsRangeSizeException : VRPLInvalidSizeException
	{
		public VRPLInvalidItemsRangeSizeException (VRPagedList aList, long aSize) :
			base (aList, "invalid items range size: (" + aSize + ").", aSize)
		{}
	}
/*/

//=======================================================================================

#endregion

//=======================================================================================

#region others Runtime Exceptions

//=======================================================================================

	// invalid range size exception

	public class VRInvalidRangeSizeException : Exception
	{
		private long theSize = 0L;
		// accessors
		public long GetSize() { return this.theSize; }
		// props
		public long Size { get { return this.GetSize(); } }
		// init
		public VRInvalidRangeSizeException (string aMsg, long aSize) :
			base (aMsg)
		{
			this.theSize = aSize;
		}
		public VRInvalidRangeSizeException (long aSize) :
			base ("invalid range size: (" + aSize + ").")
		{
			this.theSize = aSize;
		}
		// default init
		public VRInvalidRangeSizeException() : base() {}
	}

	// invalid items range size exception

	public class VRInvalidItemsRangeSizeException : VRInvalidRangeSizeException
	{
		public VRInvalidItemsRangeSizeException (string aMsg, long aSize) :
			base (aMsg, aSize)
		{}

		public VRInvalidItemsRangeSizeException (long aSize) :
			base ("invalid items range size: (" + aSize + ").", aSize)
		{}

		public VRInvalidItemsRangeSizeException() : base() {}
	}

	// invalid insert range size exception

	public class VRInvalidInsertRangeSizeException : VRInvalidRangeSizeException
	{
		public VRInvalidInsertRangeSizeException (string aMsg, long aSize) :
			base (aMsg, aSize)
		{}

		public VRInvalidInsertRangeSizeException (long aSize) :
			base ("invalid items range size: (" + aSize + ").", aSize)
		{}

		public VRInvalidInsertRangeSizeException() : base() {}
	}

//=======================================================================================

#endregion

//=======================================================================================
// paged list property identifiers

	public enum VRPLPropId : int
	{
		// pages sizes
		theDataPageSize,
		theRefsPageSize,

		// iterator near moves threshold
		theIteratorNearMoveThreshold,

		// auto order props
		theAutoOrderType,
		theDuplicatesMode,
		theAccurateBinarySearchIndicator,

		// item comparators
		theItemToItemComparator,
		theKeyToItemComparator
	}

//=======================================================================================
// order type

	public sealed class VRPLOrderType
	{
		private VRPLOrderType() {}
		// order types
		public const int theUnorderedState = (0);
		public const int theAscendingOrder = (+1);
		public const int theDescendingOrder = (-1);
	}

//=======================================================================================
// allow duplicates modes

	public sealed class VRPLDuplicatesMode
	{
		private VRPLDuplicatesMode() {}
		// duplicate modes
		public const int theDoNotAllowDuplicatesMode = (0);
		public const int theAllowDuplicatesMode = (1);
		public const int theIgnoreDuplicatesMode = (2); // or any other value
		//
		public static bool IsDoNotAllowDuplicates (int aValue)
		{
			return (aValue == theDoNotAllowDuplicatesMode);
		}
		public static bool IsAllowDuplicates (int aValue)
		{
			return (aValue == theAllowDuplicatesMode);
		}
		public static bool IsIgnoreDuplicates (int aValue)
		{
			if (IsDoNotAllowDuplicates (aValue)) return false;
			if (IsAllowDuplicates (aValue)) return false;
			return true;
		}
	}

//=======================================================================================
// binary-search modes

	public sealed class VRPLSearchMode
	{
		private VRPLSearchMode() {}
		// search modes
		public const int kFindExactItemIndex = (0);
		public const int kFindNearestItemIndexDirect = (+1);
		public const int kFindNearestItemIndexReverse = (-1);
	}

//=======================================================================================
// item/key with item comparator interface

	// old: IVRPLItemOrKeyWithItemComparator

	// new: IVRPLItemComparator

	public interface IVRPLItemComparator
	{
		/*/
			the following returns

			> 0 : (aItemOrKey > aListItem)
			== 0 : (aItemOrKey == aListItem)
			< 0 : (aItemOrKey < aListItem)
		/*/

		// old: CompareItemOrKeyWithItem

		// old: CompareListItem

		// new: Compare

		int Compare (
			VRPagedList aList,
			object aItemOrKey,
			object aListItem
		);
	}

	//using IVRPLItemWithItemComparator = IVRPLItemOrKeyWithItemComparator;
	//using IVRPLKeyWithItemComparator = IVRPLItemOrKeyWithItemComparator;

//=======================================================================================

	// list property change veto

	/*/
		the following may throw an exception
		if that prop (aPropId) could not be changed from (aOldValue) to (aNewValue)

		note: it should throw a VRPLListPropertyChangeVetoException !!
	/*/

	public delegate void VRPLListPropChangeVetoHandler (
		VRPagedList aList,
		VRPLPropId aPropId,
		object aOldValue,
		object aNewValue
	);

//=======================================================================================

	// list property change support

	/*/
		the following is notified each time a property change

		note: it should catch any exception since it is called
			just after a property is changed !!
	/*/

	public delegate void VRPLListPropChangeSupportHandler (
		VRPagedList aList,
		VRPLPropId aPropId,
		object aOldValue,
		object aNewValue
	);

//=======================================================================================
// list contents changes listener (delegate intf)

	/*/
		the following is notified each time
		the list contents change
	/*/

	public delegate void VRPagedListChangesListener (VRPagedList aList);

//=======================================================================================
// compating the B+Tree monitor interface

	public interface IVRPLCompactBTreePagesMonitor
	{
		bool OnCompactingPagesLevelBegin (VRPagedList aPagedList, bool aIsDataPage);

		bool OnCompactingPagesLevelStep (VRPagedList aPagedList, bool aIsDataPage);

		bool OnCompactingPagesLevelEnd (VRPagedList aPagedList, bool aIsDataPage);
	}

//=======================================================================================
// B+Tree Enumerator interface

#region B+Tree Enumerator interface

	public interface IVRPLBTreeEnumerator
	{
		bool OnStartEnumPages (
			VRPagedList aPagedList,
			int aLevelsCount, // the total number of levels
			int aLevelIndex,	// the actual level index
			long aPagesListCount // the number of pages at this level
		);

		bool OnEnumPage (
			VRPagedList aPagedList,
			int aLevelsCount, // the total number of levels
			int aLevelIndex, // the actual level index
			long aPagesListCount,	// the number of pages at this level
			long aPageListIndex, // this page index
			bool isDataPage,	// this page type
			long aPageItemsCount,	// this page items-count
			long aPageDeepCount	// this page deep-count
		);

		bool OnStopEnumPages (
			VRPagedList aPagedList,
			int aLevelsCount, // the total number of levels
			int aLevelIndex, // the actual level index
			long aPagesListCount // the number of pages at this level
		);

	} // IVRPLBTreeEnumerator

#endregion

//=======================================================================================
// VRPagedListEnumerator : IEnumerator

#region VRPagedListEnumerator : IEnumerator

	public class VRPagedListEnumerator : IEnumerator
	{
		private VRPagedListIterator theIterator = null;

		public VRPagedListEnumerator (VRPagedList aList)
		{
			this.theIterator = new VRPagedListIterator (aList);
			this.Reset();
		}

		public void Reset()
		{
			if (this.theIterator.IsUpdateNeeded())
				throw new InvalidOperationException ("invalid data set");
			// ok!
			this.theIterator.IterateFrom (-1L);
		}

		public object Current
		{
			get {
				if ( ! this.theIterator.IsItemIndexValid() )
					throw new InvalidOperationException ("invalid item index.");
				// ok!
				return this.theIterator.Item;
			}
		}

		public bool MoveNext()
		{
			if (this.theIterator.IsUpdateNeeded())
				throw new InvalidOperationException ("invalid data set");
			// ok!
			this.theIterator.Next();
			return this.theIterator.IsItemIndexValid();
		}
	}

#endregion

//=======================================================================================
// the (LongSized) (Untyped) VRPagedList class
//=======================================================================================

[Serializable]
public class VRPagedList :
	ISerializable,
	ICloneable,
	IComparable,
	IEnumerable, ICollection, IList
{

//=======================================================================================
// instance data
//=======================================================================================

#region instance data

		// the B+Tree root-page
		private VRPLAbstPage theRootPage = null;

		/*/ the following is used to keep
			iterators in sync with their related list
		/*/
		private long theStructModCount = 0L;

		// data/refs pages sizes
		private long theDataPageSize = 0L;
		private long theRefsPageSize = 0L;

		// supporting iterators
		private long theIteratorNearMoveThreshold = 0L;

		// auto order props
		private int theAutoOrderType = 0; // the list is not auto ordered by default
		private int theDuplicatesMode = VRPLDuplicatesMode.theDoNotAllowDuplicatesMode; // do NOT allow duplicates by default!

		// accurate binary search indicator
		private bool theAccurateOrderedSearch = false; // do NOT use accurate binary search by default

		// item/key with item comparators
		private IVRPLItemComparator theItemToItemComparator = null;
		private IVRPLItemComparator theKeyToItemComparator = null;

		// list contents changes

		// list changes notifications lock counter
		private int theListChangedEventLockCounter = 0;
		// the list contents changed state
		private bool theListChangedState = false;

/*/
		// internal list iterator for fast list access
		private VRPagedListIterator fTheInternalIterator = new VRPagedListIterator();

		// the use fast access indicator
		private bool fUseFastAccess = false;
/*/

		// ... ... ...

#endregion

//=======================================================================================
// methods
//=======================================================================================

//=======================================================================================
// init

#region init

	// default constructor

	public VRPagedList()
	{
		// init the internal iterator
		//this.fTheInternalIterator.List = this;
		// ... ... ...
	}

	// copy constructor

	public VRPagedList (VRPagedList that)
	{
		// init the internal iterator
		//this.fTheInternalIterator.List = this;
		try {
			CopyList (this, that);
		}
		catch (Exception) {
			this.Clear();
			throw;
		}
	}


	// destructor

	~ VRPagedList()
	{
		//this.DeleteAllItems();
		this.Clear();
	}

#endregion

//=======================================================================================
// fast list access
//=======================================================================================

#region fast list access

//=======================================================================================

#region fast list access: internal iterator

/*/
	private VRPagedListIterator GetInternalIterator()
	{
		return this.fTheInternalIterator;
	}

	// prop
	private VRPagedListIterator InternalIterator
	{
		get { return this.GetInternalIterator(); }
	}
/*/

#endregion

//=======================================================================================

#region fast list access: user indicator

/*/
	public bool IsUseFastAccess()
	{
		return this.fUseFastAccess;
	}

	public void SetUseFastAccess (bool aValue)
	{
		this.fUseFastAccess = aValue;
	}

	// prop
	public bool UseFastAccess
	{
		get { return this.IsUseFastAccess(); }
		set { this.SetUseFastAccess (value); }
	}
/*/

#endregion

//=======================================================================================

#region fast list access: methods

/*/
	// fast item access

	public object FastGetItemAt (long aIndex)
	{
		this.InternalIterator.Index = aIndex;
		return this.InternalIterator.Item;
	}

	public object FastReplaceItemAt (long aIndex, object aNewItem)
	{
		this.InternalIterator.Index = aIndex;
		object aOldItem = this.InternalIterator.Item;
		this.InternalIterator.Item = aNewItem;
		return aOldItem;
	}

	// fast insert

	public void FastInsert (long aIndex, object aItem)
	{
		this.InternalIterator.Index = aIndex;
		this.InternalIterator.Insert (aItem);
	}

	public void FastAdd (object aItem)
	{
		this.FastInsert (this.Size, aItem);
	}

	// fast delete

	public object FastDelete (long aIndex)
	{
		this.InternalIterator.Index = aIndex;
		object aOldItem = this.InternalIterator.Item;
		this.InternalIterator.Delete();
		return aOldItem;
	}
/*/


/*/
	// fast delete range

	public void FastDeleteRange (long aRangeIndex, long aRangeCount)
	{
		this.InternalIterator.Index = aRangeIndex;
		long aDownCount = aRangeCount;
		while (aDownCount > 0L) {
			// (re)position as needed
			if (this.InternalIterator.Index != aRangeIndex)
				// (re)position
				this.InternalIterator.Index = aRangeIndex;
			//end if
			// delete!
			this.InternalIterator.Delete();
			// next
			-- aDownCount;
		}
	}
/*/

	/*/
		public void FastDeleteRange (long aRangeIndex, long aRangeCount)
		{
			// position iterator
			this.InternalIterator.Index = aRangeIndex;
			// delete (aRangeCount) items from (aRangeIndex) ...
			this.InternalIterator.DeleteRange (aRangeCount);
		}
	/*/


#endregion

//=======================================================================================

#endregion


//=======================================================================================



//=======================================================================================
// list copy utils

#region list copy utils

	// the following makes a clone if the arg is cloneable

	public static object MakeClone (object aSrcObject)
	{
		if (aSrcObject != null)
			if (aSrcObject is ICloneable) {
				ICloneable aCloneableSrc = (ICloneable) aSrcObject;
				return aCloneableSrc.Clone();
			}
		//end if
		return aSrcObject;
	}

#endregion

//=======================================================================================
// to copy a source list onto a dest list

#region to copy a source list onto a dest list

	// to make a copy of a source list into this one

	public virtual void CopyFrom (VRPagedList that)
	{
		CopyList (this, that);
	}

	// to copy list properties

	public static void CopyListProperties (
		VRPagedList dstList,
		VRPagedList srcList
	) {
		// pages sizes
		dstList.DataPageSize = srcList.DataPageSize;
		dstList.RefsPageSize = srcList.RefsPageSize;

		// auto order props
		dstList.AutoOrderType = srcList.AutoOrderType;
		dstList.DuplicatesMode = srcList.DuplicatesMode;

		// accurate binary search indicator
		dstList.AccurateOrderedSearch = srcList.AccurateOrderedSearch;

		// comparators
		dstList.ItemToItemComparator = (IVRPLItemComparator)
			MakeClone (srcList.ItemToItemComparator);
		dstList.KeyToItemComparator = (IVRPLItemComparator)
			MakeClone (srcList.KeyToItemComparator);

		// iterators support
		dstList.IteratorNearMoveThreshold = srcList.IteratorNearMoveThreshold;

		// use fast access indicator
		//dstList.UseFastAccess = srcList.UseFastAccess;

		// do NOT Copy
		// property change veto handler
		// property change support handler
		// list contents change listeners
	}

	// to copy a source list onto a dest list

	public static void CopyList (
		VRPagedList dstList,
		VRPagedList srcList
	) {
		// clear destination ...
		dstList.Clear();

		// try to copy properties
		CopyListProperties (dstList, srcList);

		// try to copy all data items
		int aSaveAutoOrderType = dstList.AutoOrderType;
		// set dest as unordered to optimize insertions
		dstList.AutoOrderType = (0);
		try {
			try {
				GenericAddAllListItems (dstList, srcList);
				// ok!
			} catch (Exception) {
				// do NOT clear dest
				//dstList.Clear();
				throw;
			}
		} finally {
			// restore the auto-order type
			dstList.AutoOrderType = aSaveAutoOrderType;
		}
		// done!
	}

#endregion

//=======================================================================================
// adding all items from a source to a dest list

#region adding all items from a source to a dest list

	// Unordered list

	public static void UnorderedAddAllListItems (
		VRPagedList dstList,
		VRPagedList srcList
	) {
		dstList.CheckUnorderedList(); 		
		// ok: dest-list is Unordered!

		VRPagedListIterator srcListIterator = new VRPagedListIterator (srcList, 0);
		VRPagedListIterator dstListInsIterator = new VRPagedListIterator (dstList, dstList.ItemsCount);

		while (srcListIterator.IsItemIndexValid()) {

			// get item from source-list
			object srcDataItem = srcListIterator.Item;

			// try to insert item into dest-list
			dstListInsIterator.InsertItem (srcDataItem);
			// success!

			// next source item
			srcListIterator.Next(); // ++
		}//loop

		// done!
	}

	// Ordered list

	public static void OrderedAddAllListItems (
		VRPagedList dstList,
		VRPagedList srcList
	) {
		//if (dstList.IsUnordered())
			//throw new VRPLUnorderedListException (dstList);
		dstList.CheckAutoOrderedList();
		// ok: dest-list is Auto Ordered!

		// use an iterator on srcList
		VRPagedListIterator srcListIterator = new VRPagedListIterator (srcList, 0);

		while (srcListIterator.IsItemIndexValid()) {

			// get item from source-list
			object srcDataItem = srcListIterator.Item;

			// try to insert item into dest-list
			dstList.InsertOrderedItemLast (srcDataItem);
			// success!

			// next source item
			srcListIterator.Next(); // ++
		}//loop

		// done!
	}

	// Generic list

	public static void GenericAddAllListItems (
		VRPagedList dstList,
		VRPagedList srcList
	) {
		if (dstList.IsUnordered())

			// unordered dest list
			UnorderedAddAllListItems (dstList, srcList);

		else

			// ordered dest list
			OrderedAddAllListItems (dstList, srcList);

		//end if
	}

#endregion

//=======================================================================================
// interface ISerializable

#region interface ISerializable

//=======================================================================================
// serialization

	// serialization utils

	public static void AddSerValue (SerializationInfo info, string aSerId, object aValue, Type aDefaultType)
	{
		if (aValue != null) {
			Type aActualType = aValue.GetType();
			if (aActualType.IsSerializable)
				info.AddValue (aSerId, aValue, aActualType);
			else
				info.AddValue (aSerId, null, aDefaultType);
			//end if
		}
		else
			info.AddValue (aSerId, null, aDefaultType);
		//end if
	}

//=======================================================================================
// serialization

	// to serialize a list in its current state

	public virtual void GetObjectData (SerializationInfo info, StreamingContext context)
	{
		// write data/refs pages sizes
		info.AddValue ("DataPageSize", this.DataPageSize);
		info.AddValue ("RefsPageSize", this.RefsPageSize);

		// write auto-order props
		info.AddValue ("AutoOrderType", this.AutoOrderType);
		info.AddValue ("DuplicatesMode", this.DuplicatesMode);

		// write accurate binary search indicator
		info.AddValue ("AccurateOrderedSearch", this.AccurateOrderedSearch);

		// write out comparators
		AddSerValue (info, "ItemToItemComparator", this.ItemToItemComparator, typeof(IVRPLItemComparator));
		AddSerValue (info, "KeyToItemComparator", this.KeyToItemComparator, typeof(IVRPLItemComparator));

		// iterators support
		info.AddValue ("IteratorNearMoveThreshold", this.IteratorNearMoveThreshold);

		// use fast access indicator
		//info.AddValue ("UseFastAccess", this.UseFastAccess);

		// serialize data items
		this.SerializeDataItems (info);
	}

	// the following serializes data items

	private void SerializeDataItems (SerializationInfo info)
	{
		long aItemsCount = this.ItemsCount;
		info.AddValue ("ItemsCount", aItemsCount);

		VRPagedListIterator aIter = new VRPagedListIterator (this, 0L);
		long i = 0L;
		while (aIter.IsItemIndexValid()) {
			// get item
			object aItem = aIter.Item;
			// serialize it
			AddSerValue (info, "Item[" + i + "]", aItem, typeof(object));
			// next
			++i;
			aIter.Next();
		}
	}

//=======================================================================================
// de-serialization

	// de-serialization constructor

	public VRPagedList (SerializationInfo info, StreamingContext context)
	{
		// init the internal iterator
		//this.fTheInternalIterator.List = this;

		// read data/refs pages sizes
		this.DataPageSize = info.GetInt64 ("DataPageSize");
		this.RefsPageSize = info.GetInt64 ("RefsPageSize");

		// read auto-order props
		this.AutoOrderType = info.GetInt32 ("AutoOrderType");
		this.DuplicatesMode = info.GetInt32 ("DuplicatesMode");

		// read accurate binary search indicator
		this.AccurateOrderedSearch = info.GetBoolean ("AccurateOrderedSearch");

		// read in comparators
		this.ItemToItemComparator = (IVRPLItemComparator)
			info.GetValue ("ItemToItemComparator", typeof(IVRPLItemComparator));
		this.KeyToItemComparator = (IVRPLItemComparator)
			info.GetValue ("KeyToItemComparator", typeof(IVRPLItemComparator));

		// iterators support
		this.IteratorNearMoveThreshold = info.GetInt64 ("IteratorNearMoveThreshold");

		// use fast access indicator
		//this.UseFastAccess = info.GetBoolean ("UseFastAccess");

		// save the auto order type
		int aSavedAutoOrderType = this.AutoOrderType;
		// set it as unordered to optimize de-ser
		this.AutoOrderType = (0); // !!
		try {
			// de-serialize unordered data items
			this.DeserializeDataItems (info);
			// ok!
		} finally {
			// restore the auto order type
			this.AutoOrderType = aSavedAutoOrderType;
		}
		// done!
	}

	// to de-serialize data items

	private void DeserializeDataItems (SerializationInfo info)
	{
		if (this.IsUnordered())
			// always true now !!
			this.DeserializeUnorderedListDataItems (info);
		else
			// always false while de-serializing data
			this.DeserializeAutoOrderedListDataItems (info);
		//end if
	}

	// deserialize unordered list items

	private void DeserializeUnorderedListDataItems (SerializationInfo info)
	{
		long aItemsCount = info.GetInt64 ("ItemsCount");
		VRPagedListIterator aInsIter = new VRPagedListIterator (this, this.ItemsCount);
		long i = 0L;
		while (aItemsCount > 0L) {
			// retrieve that item
			object aItem = info.GetValue ("Item[" + i + "]", typeof (object));
			// insert
			aInsIter.InsertItem (aItem);
			// next
			++ i;
			-- aItemsCount;
		}
	}

	// deserialize auto-ordered list items

	private void DeserializeAutoOrderedListDataItems (SerializationInfo info)
	{
		long aItemsCount = info.GetInt64 ("ItemsCount");
		long i = 0L;
		while (aItemsCount > 0L) 
		{
			// retrieve that item
			object aItem = info.GetValue ("Item[" + i + "]", typeof (object));
			// insert
			this.InsertOrderedItemLast (aItem);
			// next
			++ i;
			-- aItemsCount;
		}
	}

#endregion

//=======================================================================================
// interface ICloneable

#region interface ICloneable

	public virtual object Clone()
	{
		return new VRPagedList (this);
	}

#endregion

//=======================================================================================
// interface IComparable

	/*/
		CompareListItems (aListA, aListB)

		returns
			(0) : aListA == aListB
			(+1) : aListA > aListB
			(-1) : aListA < aListB

		this requires all list items to implement the IComparable intf
	/*/

	public static int CompareListItems (VRPagedList aListA, VRPagedList aListB)
	{
		if (aListA == aListB) return (0);
		if (aListA == null) return (-1); // (aListA < aListB)
		if (aListB == null) return (+1); // (aListA > aListB)

		VRPagedListIterator aIterA = new VRPagedListIterator (aListA, 0);
		VRPagedListIterator aIterB = new VRPagedListIterator (aListB, 0);
		while (true) {
			bool finishedA = ! aIterA.IsItemIndexValid();
			bool finishedB = ! aIterB.IsItemIndexValid();
			if (finishedA && finishedB) break;
			if (finishedA) return (-1); // (aListA < aListB)
			if (finishedB) return (+1); // (aListA > aListB)

			object aItemA = aIterA.Item;
			object aItemB = aIterB.Item;
			int aCmpValue = Compare (aItemA, aItemB);
			if (aCmpValue < 0) return (-1);
			if (aCmpValue > 0) return (+1);
			// assert: (aItemA == aItemB) !!
			aIterA.Next();
			aIterB.Next();
		}
		return (0);
	}

	public int CompareTo (object obj)
	{
		if (obj == null) return (+1);
		VRPagedList that = (VRPagedList) obj;
		return CompareListItems (this, that);
	}

//=======================================================================================

	public static bool EqualsListItems (VRPagedList aListA, VRPagedList aListB)
	{
		if (aListA == aListB) return true;
		if (aListA == null) return false; // (aListA != aListB)
		if (aListB == null) return false; // (aListA != aListB)

		VRPagedListIterator aIterA = new VRPagedListIterator (aListA, 0);
		VRPagedListIterator aIterB = new VRPagedListIterator (aListB, 0);
		while (true) {
			bool finishedA = ! aIterA.IsItemIndexValid();
			bool finishedB = ! aIterB.IsItemIndexValid();
			if (finishedA && finishedB) break;
			if (finishedA) return false; // (aListA != aListB)
			if (finishedB) return false; // (aListA != aListB)

			object aItemA = aIterA.Item;
			object aItemB = aIterB.Item;
			bool eqValue = Equals (aItemA, aItemB);
			if ( ! eqValue ) return false; // (aListA != aListB)
			// assert: (aItemA == aItemB) !!

			aIterA.Next();
			aIterB.Next();
		}
		return true;
	}

	// override
	public override bool Equals (object obj)
	{
		if (obj == null) return false;
		try {
			VRPagedList that = (VRPagedList) obj;
			return EqualsListItems (this, that);
		} catch (Exception) {
			return false;
		}
	}

//=======================================================================================

	// override
	public override int GetHashCode()
	{
		int result = 1;
		VRPagedListIterator aIter = new VRPagedListIterator (this, 0);
		while (aIter.IsItemIndexValid())
		{
			object aItem = aIter.Item;
			int aItemHC = 0;
			if (aItem != null)
				aItemHC = aItem.GetHashCode();
			//end if
			unchecked { result = (31 * result) + aItemHC; }
			// ++
			aIter.Next();
		}
		return result;
	}

//=======================================================================================
// interface IEnumerable

#region IEnumerable interface Members

	public IEnumerator GetEnumerator()
	{
		return new VRPagedListEnumerator (this);
	}

#endregion

//=======================================================================================
// interface ICollection

#region ICollection Members

	public bool IsSynchronized
	{
		get { return false; }
	}

	public object SyncRoot
	{
		get { return this; }
	}

	public int Count
	{
		get
		{
			// it returns the small size
			return this.SmallSize; //(int) this.ItemsCount;
		}
	}

	public void CopyTo (Array array, int index)
	{
		int aMaxSize = array.GetLength(0) - index;
		if (this.Count > aMaxSize)
			throw new ArgumentException ("array is too small. avail space (" + aMaxSize + ")");
		// ok!
		int i = 0;
		foreach (object aItem in this) {
			array.SetValue (aItem, ((index) + i));
			++i;
		}
	}

#endregion

//=======================================================================================
// interface IList

#region IList Members

	/*/
		an "int" index is a small index
		a "long" index is a big index
	/*/

	public bool IsReadOnly
	{
		get
		{
			return false;
		}
	}

	public bool IsFixedSize
	{
		get
		{
			return false;
		}
	}

	// Item[int]
	public object this [int index]
	{
		get
		{
			return this.GetItemAtIndex (index);
		}
		set
		{
			this.SetItemAtIndex (index, value);
		}
	}

	public void Insert (int index, object value)
	{
		// check the small list size limit !!
		this.CheckSmallSizeLimit();
		// ok!
		this.InsertItemAtIndex (index, value);
	}

	public int Add (object value)
	{
		/*/
		// check the small list size limit !!
		this.CheckSmallSizeLimit();
		// ok!
		this.InsertItemAtIndex (this.Size, value); // this.ItemsCount
		// ok!
		return this.Count - 1;
		/*/
		this.Insert (this.SmallSize, value);
		return this.Count - 1;
	}

	public void RemoveAt (int index)
	{
		this.DeleteItemAtIndex (index);
	}

	public int IndexOf (object value)
	{
		// this throws if the size is not "small"
		int aSmallSize = this.SmallSize;
		// ok!
		// locate index of item by value
		long aIndex = this.FindValueItemIndex(value); // OfItemByVal
		// test
		if ( ! this.IsItemIndexValid (aIndex) )
			// the item was not found!
			return (-1);
		// aIndex is into the int range !!
		return (int) aIndex;
	}

	public bool Contains (object value)
	{
		int aIndex = this.IndexOf (value);
		return this.IsItemIndexValid (aIndex);
	}

	public void Remove (object value)
	{
		//int aIndex = this.IndexOf (value);
		// the following works also on huge-sized lists
		long aIndex = this.FindValueItemIndex(value); // OfItemByVal
		if ( this.IsItemIndexValid (aIndex) )
			this.DeleteItemAtIndex (aIndex);
		//end if
	}

#endregion

//=======================================================================================
// property change veto event

#region property change veto event

	public event VRPLListPropChangeVetoHandler PropertyChangeVeto = null;

	public void CheckPropertyChangeVeto (
		VRPLPropId aPropId,
		object aOldValue,
		object aNewValue
	) {
		if (this.PropertyChangeVeto != null)
			//try {
				this.PropertyChangeVeto (this, aPropId, aOldValue, aNewValue);
				// ok!
			//} catch (Exception) {
				// raise again with new property change veto exception
				//throw new VRPLListPropertyChangeVetoException (this, aPropId, aOldValue, aNewValue);
				// fail!
			//}
			// ok!
		//end if
	}

#endregion

//=======================================================================================
// property change support event

#region property change support event

	public event VRPLListPropChangeSupportHandler PropertyChangeSupport = null;

	public void RaisePropertyChanged (
		VRPLPropId aPropId,
		object aOldValue,
		object aNewValue
	) {
		if (this.PropertyChangeSupport != null)
			try {
				this.PropertyChangeSupport (this, aPropId, aOldValue, aNewValue);
			} catch (Exception) {
				// eat any exception
			}
		//end if
	}

#endregion

//=======================================================================================
// structure state changes-counter

#region structure state changes-counter

	// query
	public long GetStructState()
	{
		return this.theStructModCount;
	}

	// read only prop
	public long StructState { get { return this.GetStructState(); } }

	// change
	public void ChangeStructState() // CurrentStructStateChanged()
	{
		unchecked {
			++ this.theStructModCount;
		}
	}

	// clear
	public void ClearStructState()
	{
		this.theStructModCount = 0L;
	}

#endregion

//=======================================================================================
// accurate binary search indicator

#region accurate binary search indicator

	// get
	public bool IsAccurateOrderedSearch()
	{
		return this.theAccurateOrderedSearch;
	}

	// set
	public void SetAccurateOrderedSearch (bool aValue)
	{
		object aOldValue = this.AccurateOrderedSearch;
		object aNewValue = aValue;

		// prop change veto check
		this.CheckPropertyChangeVeto(VRPLPropId.theAccurateBinarySearchIndicator, aOldValue, aNewValue);

		// set!
		this.theAccurateOrderedSearch = aValue;

		// prop change support
		this.RaisePropertyChanged(VRPLPropId.theAccurateBinarySearchIndicator, aOldValue, aNewValue);
		// done!
	}

	// prop
	public bool AccurateOrderedSearch {
		get { return this.IsAccurateOrderedSearch(); }
		set { this.SetAccurateOrderedSearch (value); }
	}

	// reverse aliases

	public bool IsRawBinarySearch()
	{
		return ! this.AccurateOrderedSearch;
	}
	public void SetRawBinarySearch (bool aValue)
	{
		this.AccurateOrderedSearch = ! aValue;
	}
	public bool RawBinarySearch
	{
		get { return this.IsRawBinarySearch(); }
		set { this.SetRawBinarySearch (value); }
	}

#endregion

//=======================================================================================
// supporting iterators

#region supporting iterators

	// get
	public long GetIteratorNearMoveThreshold()
	{
		return this.theIteratorNearMoveThreshold;
	}

	// set
	public void SetIteratorNearMoveThreshold (long aThreshold)
	{
		object aOldValue = this.theIteratorNearMoveThreshold;
		object aNewValue = aThreshold;
		// prop change veto check ...
		this.CheckPropertyChangeVeto(VRPLPropId.theIteratorNearMoveThreshold, aOldValue, aNewValue);
		// ok!
		this.theIteratorNearMoveThreshold = aThreshold;
		// prop change support ...
		this.RaisePropertyChanged(VRPLPropId.theIteratorNearMoveThreshold, aOldValue, aNewValue);
	}

	// prop
	public long IteratorNearMoveThreshold {
		get { return this.GetIteratorNearMoveThreshold(); }
		set { this.SetIteratorNearMoveThreshold (value); }
	}

#endregion

//=======================================================================================
// Root-Page Access
//=======================================================================================

#region Root-Page Access

	// get
	private VRPLAbstPage GetRootPage() { return this.theRootPage; }
	// set
	private void SetRootPage (VRPLAbstPage aPage) { this.theRootPage = aPage; }
	// prop
	private VRPLAbstPage RootPage {
		get { return this.GetRootPage(); }
		set { this.SetRootPage (value); }
	}

	public bool AnyRootPage() { return this.theRootPage != null; }

	public bool NoRootPage() { return this.theRootPage == null; }

//=======================================================================================
// running check ...

	public bool IsRunning() { return this.RootPage != null; }

	public void RunningCheck()
	{
		if (this.IsRunning())
			throw new VRPLPagedListIsRunningException (this);
		// ok! not running!
	}

#endregion

//=======================================================================================
// accesing (data-page, local-index) pair from (global-index, root-page)

#region accesing (data-page, local-index) pair from (global-index, root-page)

	//public 
	internal void AccessDataPageLocalIndexPairFromGlobalIndex (
		ref VRPLAbstPage aDataPage,
		ref long aLocalIndex,
		long aGlobalIndex
	) {
		VRPLAbstPage.AccessDataPageLocalIndexPairFromGlobalIndex (
			ref aDataPage, ref aLocalIndex,
			aGlobalIndex, this.RootPage
		);
	}

#endregion

//=======================================================================================
// data-page range check

#region data-page range check

	public static bool IsPageInsertIndexValid (VRPLAbstPage aPage, long aIndex)
	{
		if (aPage != null)
			return aPage.IsInsertIndexValid (aIndex);
		// else aIndex must be (0) to be valid !!
		return (aIndex == 0L);
	}

	public static bool IsPageItemIndexValid (VRPLAbstPage aPage, long aIndex)
	{
		if (aPage != null)
			return aPage.IsItemIndexValid (aIndex);
		return false;
	}

#endregion

//=======================================================================================
// accessing the first/last data page

#region accessing the first/last data page

	private VRPLAbstPage GetFirstDataPage()
	{
		if (this.theRootPage != null)
			// ask the root-page
			return this.theRootPage.GetFirstDataPage();
		//else: no root-page
			return null;
	}

	//private
	internal VRPLAbstPage GetLastDataPage()
	{
		if (this.theRootPage != null)
			// ask the root-page
			return this.theRootPage.GetLastDataPage();
		//else: no root-page
			return null; // NullPageRef
	}

#endregion

//=======================================================================================
// data/refs pages sizes

#region data/refs pages sizes

	// get
	public long GetDataPageSize() { return this.theDataPageSize; }
	public long GetRefsPageSize() { return this.theRefsPageSize; }

	// set

	public void SetDataPageSize (long aNewSize)
	{
		// running check ...
		this.RunningCheck();
		// ok!
		object aOldValue = this.theDataPageSize;
		object aNewValue = aNewSize;
		// prop change veto check ...
		this.CheckPropertyChangeVeto(VRPLPropId.theDataPageSize, aOldValue, aNewValue);
		// ok!
		this.theDataPageSize = aNewSize;
		// prop change support ...
		this.RaisePropertyChanged(VRPLPropId.theDataPageSize, aOldValue, aNewValue);
	}

	public void SetRefsPageSize (long aNewSize)
	{
		// running check ...
		this.RunningCheck();
		// ok!
		object aOldValue = this.theRefsPageSize;
		object aNewValue = aNewSize;
		// prop change veto check ...
		this.CheckPropertyChangeVeto(VRPLPropId.theRefsPageSize, aOldValue, aNewValue);
		// ok!
		this.theRefsPageSize = aNewSize;
		// prop change support ...
		this.RaisePropertyChanged(VRPLPropId.theRefsPageSize, aOldValue, aNewValue);
	}

	// prop

	public long DataPageSize {
		get { return this.GetDataPageSize(); }
		set { this.SetDataPageSize (value); }
	}

	public long RefsPageSize {
		get { return this.GetRefsPageSize(); }
		set { this.SetRefsPageSize (value); }
	}

//=======================================================================================

	// to set both data/refs-pages sizes

	public void SetPagesSizes (long aDataSize, long aRefsSize)
	{
		this.SetDataPageSize ( aDataSize );
		this.SetRefsPageSize ( aRefsSize );
	}

	// to set both data/refs-pages max items count to the same value

	public void PagesSizes (long aSize)
	{
		this.SetPagesSizes (/*/data:/*/ aSize, /*/refs:/*/ aSize);
	}

//=======================================================================================

#region to check data/refs pages sizes

	public static bool IsValidBTreePageSize (long aSize)
	{
		return (aSize > 1L); // (aSize >= 2L)
	}

	// test

	public bool IsValidDataPageSize()
	{
		return IsValidBTreePageSize ( this.DataPageSize ); // x >= 2L;
	}

	public bool IsValidRefsPageSize()
	{
		return IsValidBTreePageSize ( this.RefsPageSize ); // x >= 2L;
	}

	// check

	public void CheckValidDataPageSize()
	{
		if ( ! this.IsValidDataPageSize() )
			throw new VRPLInvalidDataPageSizeException (this);
		// ok!
	}

	public void CheckValidRefsPageSize()
	{
		if ( ! this.IsValidRefsPageSize() )
			throw new VRPLInvalidRefsPageSizeException (this);
		// ok!
	}

#endregion

//=======================================================================================
// Data/Refs-Pages Limits

#region Data/Refs-Pages Limits

	// page-type size

	public long GetPageTypeSize (int aPageType)
	{
		if (VRPLAbstPage.PageType.IsRefsPageType (aPageType))
			// refs-page type
			return this.GetRefsPageSize();
		//else
			// data-page type
			return this.GetDataPageSize();
		//end if
	}

	// size of any page

	private long GetPageSizeOf (VRPLAbstPage aPage)
	{
		//if (aPage == null) return 0L; // this should never happen !!
		// assert: (aPage != null) !!
		if (aPage.IsRefsPage())
			// refs-page
			return this.GetRefsPageSize();
		//else
			// data-page
			return this.GetDataPageSize();
		//end if
	}

	// Checking Data/Refs-Pages Limits

	private bool IsPageFull (VRPLAbstPage aPage)
	{
		//if (aPage == null) return ???; // should never happen !!
		// assert: (aPage != null) !!
		return (aPage.GetItemsCount() >= this.GetPageSizeOf(aPage));
	}

	// Min pages limit

	// min page-type limit

	long ComputeHalfPageTypeSize (int aPageType)
	{
		long kPageMaxLimit = this.GetPageTypeSize (aPageType);
		long kPageMaxLimitDiv2 = (kPageMaxLimit / 2L);
		// just in the case kPageMaxLimit is not even (it could be odd)
		return (kPageMaxLimit - kPageMaxLimitDiv2);
	}

	private long HalfPageSizeOf (VRPLAbstPage aPage)
	{
		return this.ComputeHalfPageTypeSize (aPage.GetPageType());
	}

	// min data-page limit
	public long HalfDataPageSize()
		{ return this.ComputeHalfPageTypeSize (VRPLAbstPage.PageType.kDataPage); }

	// min refs-page limit
	public long HalfRefsPageSize()
		{ return this.ComputeHalfPageTypeSize (VRPLAbstPage.PageType.kRefsPage); }

#endregion

#endregion

//=======================================================================================
// items count
//=======================================================================================

#region items count / size alias

	 // items count

	public long GetItemsCount()
	{
		if (this.theRootPage != null)
			return this.theRootPage.GetDeepItemsCount();
		else
			// no root page !
			return (0);
	}

	// prop
	public long ItemsCount 
	{
		get { return this.GetItemsCount(); }
	}

	 // size (alias of items.count)

	 public long GetSize() { return this.GetItemsCount(); }

	 // prop alias
	 public long Size
	 {
		  get { return this.GetItemsCount(); }
	 }

	 // is this list empty ?

	public bool IsEmpty() { return (this.ItemsCount == 0L); }

//=======================================================================================

	// list size limit checking

	public bool IsSizeLimit()
	{
		unchecked {
			long aOldSize = this.Size;
			long aNewSize = aOldSize + 1L;
			if (aNewSize <= 0L)
				return true; // the size limit was reached !!
			return false;
		}
	}

	public void CheckSizeLimit()
	{
		if ( this.IsSizeLimit() )
			// fail: list size limit was reached !!
			throw new VRPLReachedListSizeLimitException (this);
		// ok!
	}

//=======================================================================================

	// the small size

	public bool IsSmallSize()
	{
		return VRLongToIntSafeCast.IsInsideIntSizeSpace (this.Size);
	}

	public int GetSmallSize()
	{
		/*/ the following throws if the size
			is outside the min/max-range of an int
		/*/
		return VRLongToIntSafeCast.LongToInt (this.Size);
	}

	// prop: SmallSize
	public int SmallSize { get { return this.GetSmallSize(); } }

	// checking the small list size limit

	public bool IsSmallSizeLimit()
	{
		unchecked {
			int aOldSmallSize = /*/(int)/*/ this.SmallSize;
			int aNewSmallSize = aOldSmallSize + 1;
			if (aNewSmallSize <= 0)
				return true; // the small size limit was reached !!
			return false;
		}
	}

	public void CheckSmallSizeLimit()
	{
		if ( this.IsSmallSizeLimit() )
			// fail: small list size limit was reached !!
			throw new Exception ("the small list size limit was reached.");
		// ok!
	}

//=======================================================================================
// items count debug

#region items count debug

	// DEBUG begin

	// to Rescue from a deep-count corruption
	// You should never have to call it

	public void ForceItemsCountUpdate()
	{
		if (this.theRootPage != null)
			this.theRootPage.DeepUpdateDeepItemsCount();
		//end if
	}

	// Computing the items count

	public long ComputeItemsCount()
	{
		if (this.theRootPage != null)
			return this.theRootPage.DeepComputeDeepItemsCount();
		return 0L;
	}

	// Valid ItemsCount ?

	public bool IsItemsCountValid()
	{
		return ( this.ItemsCount == this.ComputeItemsCount() ) ;
	}

	// DEBUG end

#endregion

#endregion

//=======================================================================================
// range checking
//=======================================================================================

#region range checking

	// is valid item index ?

	// if this list is empty then no index is a valid item index !!

	public bool IsItemIndexValid (long aIndex)
	{
		return (aIndex >= 0L) && (aIndex < this.ItemsCount);
	}

	// is valid insert index ?

	// (0) is always a valid insert index !!

	public bool IsInsertIndexValid (long aIndex)
	{
		return (aIndex >= 0L) && (aIndex <= this.ItemsCount);
	}

//=======================================================================================

#region more range checking

	// to check for a valid item index

	public void CheckValidItemIndex (long aIndex)
	{
		if ( ! this.IsItemIndexValid (aIndex) )
			throw new VRPLInvalidItemIndexException (this, aIndex, this.ItemsCount);
		// ok!
	}

	// to check for a valid insert index

	public void CheckValidInsertIndex (long aIndex)
	{
		if ( ! this.IsInsertIndexValid (aIndex) )
			throw new VRPLInvalidInsertIndexException (this, aIndex, this.ItemsCount);
		// ok!
	}

//=======================================================================================

	// items range check

	/*/
		note: if the size is zero or less then the range is NOT valid !!
	/*/

	public bool IsValidItemsRange (long aIndex, long aCount)
	{
		if (aCount <= 0L) return false;
		// assert: (aCount > 0L) !!
		if ( ! this.IsItemIndexValid (aIndex) ) return false;
		long aLastIndex = (aIndex + aCount - 1L);
		if ( ! this.IsItemIndexValid (aLastIndex) ) return false;
		return true;
	}

	/*/
		if the range size is not valid the an exception is thrown
		check the range only if (aCount > 0L)
	/*/

	public void CheckValidItemsRange (long aIndex, long aCount)
	{
		if (aCount <= 0L)
			// fail: invalid items range size !!
			throw new VRInvalidItemsRangeSizeException (aCount);
		// ok!
		// assert: (aCount > 0L) !!
		// check first range index
		this.CheckValidItemIndex (aIndex);
		// ok!
		long aLastIndex = (aIndex + aCount - 1L);
		// check last range index
		this.CheckValidItemIndex (aLastIndex);
		// ok!
	}

//=======================================================================================

	// insert range check

	public bool IsValidInsertRange (long aIndex, long aCount)
	{
		if (aCount < 0L) return false;
		// assert: (aCount >= 0L) !!
		if ( ! this.IsInsertIndexValid (aIndex) ) return false;
		long aLastIndex = (aIndex + aCount);
		if ( ! this.IsInsertIndexValid (aLastIndex) ) return false;
		return true;
	}

	public void CheckValidInsertRange (long aIndex, long aCount)
	{
		if (aCount < 0L)
			// fail: invalid items range size !!
			throw new VRInvalidInsertRangeSizeException (aCount);
		// ok!
		// assert: (aCount >= 0L) !!
		// check first range index
		this.CheckValidInsertIndex (aIndex);
		// ok!
		long aLastIndex = (aIndex + aCount);
		// check last range index
		this.CheckValidInsertIndex (aLastIndex);
		// ok!
	}


//=======================================================================================


#endregion

//=======================================================================================
// deep range check (for debug purposes only)

#region deep range check (for debug purposes only)

	// is valid item index (deep) ?

	public bool IsDeepItemIndexValid (long aIndex)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = aIndex;
		this.AccessDataPageLocalIndexPairFromGlobalIndex (
			ref aDataPage, ref aLocalIndex, aIndex
		);
		if (aDataPage != null)
			return aDataPage.IsItemIndexValid (aLocalIndex);
		//else: no data-page = no item !!
		return false;
	}

	// is valid insert index (deep) ?

	public bool IsDeepInsertIndexValid (long aIndex)
	{
		VRPLAbstPage aDataPage = null; long aLocalIndex = aIndex;
		this.AccessDataPageLocalIndexPairFromGlobalIndex (
			ref aDataPage, ref aLocalIndex, aIndex
		);
		if (aDataPage != null)
			return aDataPage.IsInsertIndexValid (aLocalIndex);
		//else: no data-page: aIndex must be (0) !!
		return (aIndex == 0L);
	}

#endregion

#endregion

//=======================================================================================
// accessing list items
//=======================================================================================

#region accessing list items

	// to get an item at a given index

	/*/
		if (this.UseFastAccess)
			// use fast access
			return this.FastGetItemAt (aIndex);
		//end if
	/*/
	// else normal access ...

	public object GetItemAtIndex (long aIndex)
	{
		// retrieve page-indexing-info from global-index
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1);
		this.AccessDataPageLocalIndexPairFromGlobalIndex (
			ref aDataPage, ref aLocalIndex,
			aIndex
		);
		if (aDataPage != null)
			if (aDataPage.IsItemIndexValid (aLocalIndex)) {
				object aDataItem = aDataPage.GetItemAt (aLocalIndex);
				return aDataItem;
				// ok!
			}//end if
		//end if
		// else failure
		// no data-page || aLocalIndex out-of-bounds
		// failure!
		throw new VRPLInvalidItemIndexException (this, aIndex, this.ItemsCount);
	}

//=======================================================================================

	// to set an item at a given index

	// low level proc (also used by iterators)

	//package //public
	internal void SetDataPageItem (
		VRPLAbstPage aDataPage,
		long aLocalIndex,
		long aGlobalIndex,
		object aNewDataItem
	) {
		// assert: (aDataPage != null) !!
		if ( ! aDataPage.IsItemIndexValid (aLocalIndex) )
			throw new VRPLInvalidItemIndexException (this, aGlobalIndex, this.ItemsCount);
		// ok!

		// try to see if we can replace ordered items
		if (this.IsAutoOrdered())
			this.CheckReplaceOrderedItemAtIndex (aGlobalIndex, aNewDataItem);
		// ok!

		// get old item
		object aOldDataItem = aDataPage.GetItemAt (aLocalIndex);

		// set item at index in data-page
		aDataPage.SetItemAt (aLocalIndex, aNewDataItem);

		// success!

		// do NOT raise list contents changed event
		// this.RaiseListChangedEvent();
		// ... ... ...

		//return aOldDataItem;
	}

//=======================================================================================

	// to replace an item at a given index

	/*/
		if (this.UseFastAccess)
			// use fast access
			return this.FastReplaceItemAt (aIndex, aDataItem);
		//end if
	/*/
	// else normal access ...


	public object ReplaceItemAtIndex (long aIndex, object aDataItem)
	{
		// retrieve page-indexing-info from global-index
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1);
		// access (data-page, local-index) from global-index
		this.AccessDataPageLocalIndexPairFromGlobalIndex (
			ref aDataPage, ref aLocalIndex,
			aIndex
		);
		if (aDataPage != null)
			if (aDataPage.IsItemIndexValid (aLocalIndex)) {
				// ok!

				// get old item
				object aOldDataItem = aDataPage.GetItemAt (aLocalIndex);

				/*/object aOldDataItem =/*/ this.SetDataPageItem (
					aDataPage, aLocalIndex,
					/*/global index:/*/ aIndex,
					/*/data item:/*/ aDataItem
				);
				// success!

				// raise list contents changed event
				this.RaiseListChangedEvent();

				// done!
				return aOldDataItem;
			}//end if
		//end if
		// else failure
		// no data-page || aLocalIndex out-of-bounds
		// failure!
		throw new VRPLInvalidItemIndexException (this, aIndex, this.ItemsCount);
		// failure!
	}

	// to set an item at a given index

	public void SetItemAtIndex (long aIndex, object aDataItem)
	{
		ReplaceItemAtIndex (aIndex, aDataItem); // discard result
	}

//=======================================================================================
// item indexer

	// Item [long]
	public object this [long aIndex]
	{
		get {
			return this.GetItemAtIndex (aIndex);
		}
		set {
			this.SetItemAtIndex (aIndex, value);
		}
	}

#endregion

//=======================================================================================
// to locate index of item by reference / value

#region to locate index of item by reference / value

	public long FindReferenceItemIndex (object aLookupItem)
	{
		VRPagedListIterator aIter = new VRPagedListIterator (this, 0);
		while (aIter.IsItemIndexValid()) {
			object aItem = aIter.Item;
			if (aLookupItem == aItem) break;
			++ aIter;
		}
		return aIter.Index;
	}

	public long FindValueItemIndex (object aLookupItem)
	{
		VRPagedListIterator aIter = new VRPagedListIterator (this, 0);
		while (aIter.IsItemIndexValid()) {
			object aItem = aIter.Item;
			if ( aLookupItem.Equals (aItem) ) break;
			++ aIter;
		}
		return aIter.Index;
	}

#endregion

//=======================================================================================
// auto order properties
//=======================================================================================

//=======================================================================================
// auto order type

#region auto order type

	// get

	public int GetAutoOrderType() { return this.theAutoOrderType; }

	public bool IsAutoOrdered() { return (this.GetAutoOrderType() != 0); }
	public bool IsUnordered() { return (this.GetAutoOrderType() == 0); }
	public bool IsAutoAscendingOrder() { return (this.GetAutoOrderType() > 0); }
	public bool IsAutoDescendingOrder() { return (this.GetAutoOrderType() < 0); }

	public void CheckUnorderedList()
	{
		// check for an unordered list
		if ( this.IsAutoOrdered() )
			// fail: the list is auto ordered !!
			throw new VRPLOrderedListException (this);
		// ok!
	}

	public void CheckAutoOrderedList()
	{
		// check for an auto-ordered list
		if ( this.IsUnordered() )
			// fail: the list is unordered !!
			throw new VRPLUnorderedListException (this);
		// ok!
	}

	// set

	public void SetAutoOrderType (int aNewOrderType)
	{
		object aOldValue = this.theAutoOrderType;
		object aNewValue = aNewOrderType;
		// prop change veto check
		this.CheckPropertyChangeVeto(VRPLPropId.theAutoOrderType, aOldValue, aNewValue);

		// set
		this.theAutoOrderType = aNewOrderType;

		// prop change support
		this.RaisePropertyChanged(VRPLPropId.theAutoOrderType, aOldValue, aNewValue);
		// done!
	}

	public void SetAutoAscendingOrder() { this.SetAutoOrderType (VRPLOrderType.theAscendingOrder); }

	public void SetAutoDescendingOrder() { this.SetAutoOrderType(VRPLOrderType.theDescendingOrder); }

	public void SetUnordered() { this.SetAutoOrderType(VRPLOrderType.theUnorderedState); }

	// to reverse auto order

	public void ReverseAutoOrderType()
	{
		this.SetAutoOrderType ( - this.GetAutoOrderType() );
	}

	// prop

	public int AutoOrderType
	{
		get { return this.GetAutoOrderType(); }
		set { this.SetAutoOrderType (value); }
	}

#endregion

//=======================================================================================
// duplicates mode

#region duplicates mode

	// get
	public int GetDuplicatesMode() { return this.theDuplicatesMode; }

	// set
	public void SetDuplicatesMode (int aValue)
	{
		object aOldValue = this.theDuplicatesMode;
		object aNewValue = aValue;
		// prop change veto check
		this.CheckPropertyChangeVeto(VRPLPropId.theDuplicatesMode, aOldValue, aNewValue);

		// set
		this.theDuplicatesMode = aValue;

		// prop change support
		this.RaisePropertyChanged(VRPLPropId.theDuplicatesMode, aOldValue, aNewValue);
		// done!
	}

	// prop
	public int DuplicatesMode
	{
		get { return this.GetDuplicatesMode(); }
		set { this.SetDuplicatesMode (value); }
	}

//=======================================================================================

	// macros

	// test

	public bool IsDoNotAllowDuplicateItems()
	{
		return VRPLDuplicatesMode.IsDoNotAllowDuplicates (this.DuplicatesMode);
	}

	public bool IsAllowDuplicateItems()
	{
		return VRPLDuplicatesMode.IsAllowDuplicates (this.DuplicatesMode);
	}

	public bool IsIgnoreDuplicateItems()
	{
		return VRPLDuplicatesMode.IsIgnoreDuplicates (this.DuplicatesMode);
	}

	// set

	public void SetDoNotAllowDuplicateItems()
	{
		this.DuplicatesMode = VRPLDuplicatesMode.theDoNotAllowDuplicatesMode;
	}

	public void SetAllowDuplicateItems()
	{
		this.DuplicatesMode = VRPLDuplicatesMode.theAllowDuplicatesMode;
	}

	public void SetIgnoreDuplicateItems()
	{
		this.DuplicatesMode = VRPLDuplicatesMode.theIgnoreDuplicatesMode;
	}

#endregion

//=======================================================================================
// item / key with item comparators

#region (item | key) to item comparators

	// get

	public IVRPLItemComparator GetItemToItemComparator()
		{ return this.theItemToItemComparator; }

	public IVRPLItemComparator GetKeyToItemComparator()
		{ return this.theKeyToItemComparator; }

	// set

	public void SetItemToItemComparator (IVRPLItemComparator aNewComparator)
	{
		object aOldValue = this.theItemToItemComparator;
		object aNewValue = aNewComparator;
		// property change veto check ...
		this.CheckPropertyChangeVeto(VRPLPropId.theItemToItemComparator, aOldValue, aNewValue);
		// ok!
		this.theItemToItemComparator = aNewComparator;
		// property change support check ...
		this.RaisePropertyChanged(VRPLPropId.theItemToItemComparator, aOldValue, aNewValue);
	}

	public void SetKeyToItemComparator (IVRPLItemComparator aNewComparator)
	{
		object aOldValue = this.theKeyToItemComparator;
		object aNewValue = aNewComparator;
		// property change veto check ...
		this.CheckPropertyChangeVeto(VRPLPropId.theKeyToItemComparator, aOldValue, aNewValue);
		// ok!
		this.theKeyToItemComparator = aNewComparator;
		// property change support check ...
		this.RaisePropertyChanged(VRPLPropId.theKeyToItemComparator, aOldValue, aNewValue);
	}

	// props

	public IVRPLItemComparator ItemToItemComparator
	{
		get { return this.GetItemToItemComparator(); }
		set { this.SetItemToItemComparator (value); }
	}

	public IVRPLItemComparator KeyToItemComparator 
	{
		get { return this.GetKeyToItemComparator(); }
		set { this.SetKeyToItemComparator (value); }
	}

#endregion

//=======================================================================================
// comparing item or key with item

#region comparing item or key with item

	/*/
		this is the default compare function
	/*/

	public static int Compare (object aItemOrKey, object aListItem)
	{
		if (aItemOrKey == aListItem) return (0);
		if (aItemOrKey == null) return (-1); // aItemOrKey < aListItem
		if (aListItem == null) return (+1); // aItemOrKey > aListItem
		//
		/*/
		//if (aListItem is IComparable) ...
		IComparable aComparableListItem = (IComparable) aListItem;
		// success! (aListItem is IComparable)
		return - aComparableListItem.CompareTo (aItemOrKey);
		/*/
		// compare (aItemOrKey, aListItem);
		IComparable aComparableItemOrKey = (IComparable) aItemOrKey;
		return aComparableItemOrKey.CompareTo (aListItem);
	}

	/*/
		this is the main compare function
	/*/

	// old: CallItemOrKeyWithItemComparator

	// old: CompareListItem

	// new: Compare

	public static int Compare (
		VRPagedList aList,
		IVRPLItemComparator aCompareFunc,
		object aItemOrKey,
		object aListItem
	) {
		if (aCompareFunc != null)
			return aCompareFunc.Compare (aList, aItemOrKey, aListItem);
		//end if
		//
		/*/
		if (aItemOrKey == aListItem) return (0);
		if (aItemOrKey == null) return (-1); // aItemOrKey < aListItem
		if (aListItem == null) return (+1); // aItemOrKey > aListItem
		//
		//if (aListItem is IComparable) ...
		IComparable aComparableListItem = (IComparable) aListItem;
		// success! (aListItem is IComparable)
		return - aComparableListItem.CompareTo (aItemOrKey);
		/*/
		// default ...
		return Compare (aItemOrKey, aListItem);
	}

	// instance
	public int Compare (
		IVRPLItemComparator aCompareFunc,
		object aItemOrKey,
		object aListItem
	) {
		/*/
		if (aCompareFunc != null)
			return aCompareFunc.Compare (this, aItemOrKey, aListItem);
		//end if
		//
		if (aItemOrKey == aListItem) return (0);
		if (aItemOrKey == null) return (-1); // aItemOrKey < aListItem
		if (aListItem == null) return (+1); // aItemOrKey > aListItem
		//
		//if (aListItem is IComparable) ...
		IComparable aComparableListItem = (IComparable) aListItem;
		// success! (aListItem is IComparable)
		return - aComparableListItem.CompareTo (aItemOrKey);
		/*/
		return Compare (this, aCompareFunc, aItemOrKey, aListItem);
	}

	// replace: aliases with: Compare (IVRPLItemComparator, object, object)

	// remove: CallItemWithItemComparator

/*/
	public int CallItemWithItemComparator (
		IVRPLItemOrKeyWithItemComparator aCompareFunc,
		object aItemA,
		object aItemB
	) {
		return this.Compare (aCompareFunc, aItemA, aItemB);
	}
/*/

	// remove: CallKeyWithItemComparator

/*/
	public int CallKeyWithItemComparator (
		IVRPLItemOrKeyWithItemComparator aCompareFunc,
		object aKey,
		object aItem
	) {
		return this.Compare (aCompareFunc, aKey, aItem);
	}
/*/

//=======================================================================================

	public int CompareItemToItem (object aItemA, object aItemB)
	{
		return this.Compare (
			this.ItemToItemComparator,
			aItemA, aItemB
		);
	}

	public int CompareKeyToItem (object aKey, object aItem)
	{
		return this.Compare (
			this.KeyToItemComparator,
			aKey, aItem
		);
	}

	public int CompareItemToKey (object aItem, object aKey)
	{
		// reverse params & negate result!
		return ( - this.CompareKeyToItem (aKey, aItem) );
	}

#endregion

//=======================================================================================
// List Contents Changed Event
//=======================================================================================

#region List Contents Changed Event

	public event VRPagedListChangesListener ListChangesListener = null;

//=======================================================================================

	// sending list changes notifications

	public void ListContentsChangedNotification()
	{
		if (this.ListChangesListener != null)
			this.ListChangesListener (this);
		//end if
	}

//=======================================================================================
// List Changes Notifications

	// (private) prop ListChangedEventLockCounter

	private int GetListChangedEventLockCounter()
	{
		return this.theListChangedEventLockCounter;
	}
	private void SetListChangedEventLockCounter (int aCount)
	{
		this.theListChangedEventLockCounter = aCount;
	}
	private int ListChangedEventLockCounter
	{
		get { return this.GetListChangedEventLockCounter(); }
		set { this.SetListChangedEventLockCounter (value); }
	}

	// (private) ++ / --

	private void IncrListChangedEventLockCounter()
	{
		unchecked {
			this.ListChangedEventLockCounter = this.ListChangedEventLockCounter + 1;
		}
	}
	private void DecrListChangedEventLockCounter()
	{
		unchecked {
			this.ListChangedEventLockCounter = this.ListChangedEventLockCounter - 1;
		}
	}

	// lock/unlock/test

	// is it locked ?

	public bool IsListChangedEventLocked()
	{
		return (this.ListChangedEventLockCounter != 0); // > 0
	}

	// lock

	public void LockListChangedEvent()
	{
		// ++ this.fTheListChangedEventLockCounter;
		this.IncrListChangedEventLockCounter();
	}

	// unlock

	public void UnlockListChangedEvent()
	{
		// -- this.fTheListChangedEventLockCounter;
		this.DecrListChangedEventLockCounter();
		// this will notify only if it is changed and unlocked !!
		if (this.Changed)
			this.RaiseListChangedEvent();
		//end if
	}

	// to get / set the lock status

	public int GetListChangedEventLockState()
	{
		return this.ListChangedEventLockCounter;
	}
	public void SetListChangedEventLockState (int aValue)
	{
		this.ListChangedEventLockCounter = aValue;
	}

	// prop
	public int ListChangedEventLockState
	{
		get { return this.GetListChangedEventLockState(); }
		set { this.SetListChangedEventLockState (value); }
	}


//=======================================================================================
// changed state indicator

	// get

	public bool IsChanged()
	{
		return (this.theListChangedState);
	}

	// set

	public void SetChanged (bool aValue)
	{
		this.theListChangedState = aValue;
	}

	// prop

	public bool Changed {
		get { return this.IsChanged(); }
		set { this.SetChanged (value); }
	}

/*/
	// contents are not changed!

	public void ClearListChanged()
	{
		this.fTheListChangedState = false;
	}
/*/

/*/
	// to save it

	public bool GetListChanged()
	{
		return this.IsListChanged();
	}

	// to restore it

	public void SetListChanged (bool setIt)
	{
		if (setIt)
			this.SetListChanged();
		else
			this.ClearListChanged();
		//end if
	}
/*/

//=======================================================================================
// notifications

	private void InternalListChangesNotification()
	{
		// notify listeners list contents changed !!
		this.ListContentsChangedNotification();
	}

//=======================================================================================

/*/
	// the following also clears the changed state

	private void SendListChangesNotification()
	{
		// notifify listeners
		this.InternalListChangesNotification();
		// always clear the list changed indicator
		//this.ClearListChanged();
		this.Changed = false;
	}

	// the following notify if changed

	private void SendListChangesNotificationIfChanged()
	{
		if (this.Changed)
			// changed: send list contents changed notification!
			this.SendListChangesNotification();
		//end if
	}

	// the following notify if changed and unlocked

	private void SendListChangesNotificationIfChangedCheckLock()
	{
		if ( ! this.IsListChangedEventLocked() )
			// unlocked!
			this.SendListChangesNotificationIfChanged();
		//end if
	}

	// the following changes then raise only if not locked

	private void RaiseListChangedEventCheckLock()
	{
		// changed!
		this.Changed = true;
		// notify
		this.SendListChangesNotificationIfChangedCheckLock();
	}

	// public alias of RaiseListChangedEventCheckLock()
/*/

//=======================================================================================

	// to raise a list changed event

	public void RaiseListChangedEvent()
	{
		//this.RaiseListChangedEventCheckLock();
		// changed!
		this.Changed = true;
		// notify only if it is unlocked
		if ( ! this.IsListChangedEventLocked() ) {
			// unlocked!
			// notifify listeners
			this.InternalListChangesNotification();
			// always clear the list changed indicator
			//this.ClearListChanged();
			this.Changed = false;
		//else
			// locked!
			// this stay changed
			// for a next call to aList.UnlockListChangedEvent()
		}//end if
	}

#endregion

//=======================================================================================
// Auto Ordered List Item Utils
//=======================================================================================

#region Auto Ordered List Item Utils

#region Check Placing Ordered Items

	// Check Placing Ordered Items

	public void CheckPlaceOrderedItemBeforeItem (object aItemData, object aNextItem)
	{
		if (this.IsUnordered())
			return; // Ok!
		// else ...

		// compare (aItemData, aNextItem)!
		int resultNext = this.CompareItemToItem (aItemData, aNextItem);

		if (this.IsAutoAscendingOrder()) {
			// Ascending Order
			if (resultNext > 0)
				// (aItemData > aNextItem) !!
				throw new VRPLOrderedListException (this);
			// else ok!
		} else {
			// Descending Order
			if (resultNext < 0)
				// (aItemData < aNextItem) !!
				throw new VRPLOrderedListException (this);
			// else ok!
		}
		// ok!

		if (resultNext == 0)
			if (this.IsDoNotAllowDuplicateItems())
				// the list do NOT allow duplicates
				throw new VRPListDoNotAllowDuplicatesException (this, (-1L), aItemData);
		// ok!
	}

	public void CheckPlaceOrderedItemAfterItem (object aItemData, object aPrevItem)
	{
		if (this.IsUnordered())
			return; // Ok!
		// else ...

		// compare (aItemData, aPrevItem)!
		int resultPrev = this.CompareItemToItem (aItemData, aPrevItem);

		if (this.IsAutoAscendingOrder()) 
		{
			// Ascending Order
			if (resultPrev < 0)
				// (aItemData < aPrevItem) !!
				throw new VRPLOrderedListException (this);
			// else ok!
		} else {
			// Descending Order
			if (resultPrev > 0)
				// (aItemData > aPrevItem) !!
				throw new VRPLOrderedListException (this);
			// else ok!
		}
		// ok!

		if (resultPrev == 0)
			if (this.IsDoNotAllowDuplicateItems())
				// the list do NOT allow duplicates
				throw new VRPListDoNotAllowDuplicatesException (this, (-1L), aItemData);
		// ok!
	}

#endregion

//=======================================================================================

#region Check Place Ordered Item Before / After Index

	// check before

	public void CheckPlaceOrderedItemBeforeIndex (object aItemData, long aIndex)
	{
		if (this.IsUnordered())
			return; // Ok!
		// else ...

		// get the item at (aGlobalIndex) (if any)
		object aNextItem = this.GetItemAtIndex (aIndex);
		// ok!
		// check!
		try {
			this.CheckPlaceOrderedItemBeforeItem (aItemData, aNextItem);
		} catch (VRPListDoNotAllowDuplicatesException) {
			throw new VRPListDoNotAllowDuplicatesException (this, aIndex, aItemData);
		}
		// ok!
	}

	// check after

	public void CheckPlaceOrderedItemAfterIndex (object aItemData, long aIndex)
	{
		if (this.IsUnordered())
			return; // Ok!
		// else ...

		// get the item at (aGlobalIndex) (if any)
		object aPrevItem = this.GetItemAtIndex (aIndex);
		// ok!
		// check!
		try {
			this.CheckPlaceOrderedItemAfterItem (aItemData, aPrevItem);
		} catch (VRPListDoNotAllowDuplicatesException) {
			throw new VRPListDoNotAllowDuplicatesException (this, aIndex, aItemData);
		}
		// ok!
	}

#endregion

//=======================================================================================

	public void CheckReplaceOrderedItemAtIndex (long aIndex, object aItemData)
	{
		if (this.IsUnordered()) return;
		// this list is auto-ordered
		long aPrevIndex = (aIndex - 1L);
		if (this.IsItemIndexValid (aPrevIndex))
			this.CheckPlaceOrderedItemAfterIndex (aItemData, aPrevIndex);
			// ok!
		//end if
		// ok!
		long aNextIndex = (aIndex + 1L);
		if (this.IsItemIndexValid (aNextIndex))
			this.CheckPlaceOrderedItemBeforeIndex (aItemData, aNextIndex);
			// ok!
		//end if
		// ok!
	}

//=======================================================================================

	public void CheckInsertOrderedItemAtIndex (long aIndex, object aItemData)
	{
		if (this.IsUnordered()) return;
		// this list is auto-ordered
		long aPrevIndex = aIndex - 1L;
		if (this.IsItemIndexValid (aPrevIndex))
			this.CheckPlaceOrderedItemAfterIndex (aItemData, aPrevIndex);
			// ok!
		//end if
		// ok!
		long aNextIndex = aIndex;
		if (this.IsItemIndexValid (aNextIndex))
			this.CheckPlaceOrderedItemBeforeIndex (aItemData, aNextIndex);
			// ok!
		//end if
		// ok!
	}

#endregion

//=======================================================================================

//=======================================================================================
// B+Tree Height
//=======================================================================================

#region B+Tree Height

	// to get the B+Tree height (including the level of data-pages)

	/*/ actually it is implemented through a call to "this.CountBTreeLevels()"
		because actually the list does not keep track of the internal B+Tree levels
		as items are inserted or removed or the B+Tree is compacted
	/*/

	public int GetBTreeHeight()
	{
		return this.CountBTreeLevels();
	}

	// prop
	public int BTreeHeight {
		get { return this.GetBTreeHeight(); }
	}

	// to get the B+Tree height (excluding the level of data-pages)

	public int GetBTreeHeightMinusOne()
	{
		int aHeight = this.BTreeHeight;
		if (aHeight > 0L)
			aHeight -= (1);
		//end if
		return aHeight;
	}

	// prop
	public int BTreeHeightMinusOne {
		get { return this.GetBTreeHeightMinusOne(); }
	}

	// height of refs-pages

	public int GetRefsPagesHeight()
	{
		return this.BTreeHeightMinusOne;
	}

	// prop
	public int RefsPagesHeight {
		get { return this.GetRefsPagesHeight(); }
	}


#endregion

//=======================================================================================
// Debug Methods
//=======================================================================================

#region Debug Methods

	// DEBUG Procs begin

#region B+Tree Checking

	// Check B+Tree Links

	public void CheckBTreeLinks()
	{
		if (this.theRootPage != null)
			this.theRootPage.CheckAllSubPagesLinks();
		// else no root-page
	}

	// Check B+Tree Pages Deep Counters

	public void CheckDeepItemsCount()
	{
		if (this.theRootPage != null)
			this.theRootPage.CheckDeepCounters();
		// else no root-page
	}

#endregion

	// DEBUG Procs end

//=======================================================================================
// B+Tree Traversals
//=======================================================================================

	// DEBUG Procs begin

#region accessing B+Tree levels

	// to count all B+Tree levels

	public int CountBTreeLevels()
	{
		VRPLAbstPage aPage = this.RootPage;
		int aCount = 0;
		while (true) { //do
			if (aPage == null)
				break;
			//end if
			// increase levels-counter
			++ aCount;
			// if aPage is a data-page then break !!
			if (aPage.IsRefsPage())
				if (aPage.GetItemsCount() > 0L)
					// should always be true
					// 'cuz we cannot have empty pages
					aPage = aPage.GetPageRefAt (0L);
					// continue with aPage
				else
					break;
				//end if
			else
				// aPage is a data-page
				break;
			//end if
		}//end do
		return aCount;
	}

	// to get the first page at the specified level

	private VRPLAbstPage GetPagesListHeadAtLevel (int aLevelIndex)
	{
		VRPLAbstPage aPage = this.RootPage;
		int aLevelIndexCount = 0;
		while (true) {//do
			if (aPage == null)
				break;
			//end if

			// aPage can contain refs or data
			if (aLevelIndexCount >= aLevelIndex)
				// found!
				// return aPage
				break;
			//end if

			// increase level index
			++ aLevelIndexCount;

			// try to go down a level, else fail !!
			if (aPage.IsRefsPage())
				if (aPage.GetItemsCount() > 0L)
					// go down a level
					aPage = aPage.GetPageRefAt (0L);
					// continue with aPage
				else
					// got an empty refs-page: fail
					aPage = null;
					// break
				//end if
			else
				// aPage is a data-page
				// got a data-page: fail
				aPage = null;
				// break
			//end if
		}//end do
		return aPage;
	}

#endregion

//=======================================================================================

	// forward enum all pages of a b+tree level

	private bool ForwardEnumBTreeLevelPagesList (
		int aLevelsCount,
		int aLevelIndex,
		IVRPLBTreeEnumerator aEnumerator
	) {
		// get list head at the given level
		VRPLAbstPage aPage = this.GetPagesListHeadAtLevel (aLevelIndex);
		long aPagesListItemsCount = 0L;
		if (aPage != null)
			aPagesListItemsCount = aPage.CountPagesForward();
		//end if

		bool ok = true;

		// start
		if (aEnumerator != null)
			ok = aEnumerator.OnStartEnumPages (this, aLevelsCount, aLevelIndex, aPagesListItemsCount);
		//end if
		if (ok) {
			try {
				long aIndex = 0L;
				while ((aPage != null) && (ok)) {
					// call the user proc
					if (aEnumerator != null) {
						ok = aEnumerator.OnEnumPage (
							this, aLevelsCount, aLevelIndex, aPagesListItemsCount,
							aIndex, aPage.IsDataPage(), //aPage.GetPageType(),
							aPage.GetItemsCount(), aPage.GetDeepItemsCount()
							);
						if (!ok) break;
					}//end if
					// next page
					aPage = aPage.GetNextPage();
					++ aIndex;
				}//loop
			}
			finally {
				// stop
				if (aEnumerator != null)
					ok = aEnumerator.OnStopEnumPages
						(this, aLevelsCount, aLevelIndex, aPagesListItemsCount) && ok;
				//end if
			}
		}//end if
		return ok;
	}

	// forward enum all b+tree pages

	public bool ForwardEnumAllBTreeLevelPages (
		IVRPLBTreeEnumerator aEnumerator,
		bool isReverse
	) {
		int aLevelsCount = this.CountBTreeLevels();
		bool ok = true;

		if (!isReverse) {

			// direct: start from root
			int aLevelIndex = 0;
			while (aLevelIndex < aLevelsCount) {//do
				// traverse b-tree pages-list at (aLevelIndex)
				ok = this.ForwardEnumBTreeLevelPagesList (
					aLevelsCount, aLevelIndex,
					aEnumerator
				);
				if (!ok) break;
				// next level
				++ aLevelIndex;
			}//end do

		} else {

			// reverse: start from leafs
			int aLevelIndex = aLevelsCount - 1;
			while (aLevelIndex >= 0L) {//do
				// traverse b-tree pages-list at (aLevelIndex)
				ok = this.ForwardEnumBTreeLevelPagesList (
					aLevelsCount, aLevelIndex,
					aEnumerator
				);
				if (!ok) break;
				// prev level
				-- aLevelIndex;
			}//end do

		}//end if
		return ok;
	}

	// macro

	public bool ForwardEnumAllBTreeLevelPages (
		IVRPLBTreeEnumerator aEnumerator
	) {
		return this.ForwardEnumAllBTreeLevelPages (aEnumerator, false);
	}

//=======================================================================================

	// recursively enum sub-pages

	private bool DeepEnumPage (
		VRPLAbstPage aPage,
		int aLevelsCount,
		int aLevelIndex,
		long aPagesListCount,
		long aPageListIndex,
		// user enum
		IVRPLBTreeEnumerator aEnumerator,
		bool isPostorder
	) {
		if (aPage == null) return true;

		bool ok = true;

		if (!isPostorder)
			// traverse aPage in pre-order
			if (aEnumerator != null)
				ok = aEnumerator.OnEnumPage (
					this,
					aLevelsCount, aLevelIndex,
					aPagesListCount, aPageListIndex,
					aPage.IsDataPage(), //aPage.GetPageType(),
					aPage.GetItemsCount(), aPage.GetDeepItemsCount()
				);
			//end if
		//end if

		if (!ok) return false;

		if (aPage.IsRefsPage()) {
			// refs-page: recurse on sub-pages
			long aItemsCount	= aPage.GetItemsCount();

			// start enumerating pages
			if (aEnumerator != null)
				ok = aEnumerator.OnStartEnumPages (
					this, aLevelsCount, aLevelIndex + 1, aItemsCount
				);
			//end if

			if (!ok) return false;

			try {
				// enumerate sub-pages
				long aIndex = 0L;
				while (aIndex < aItemsCount) {//do
					VRPLAbstPage aSubPage = aPage.GetPageRefAt (aIndex);
					// recurse on aSubPage
					ok = this.DeepEnumPage (
						aSubPage, aLevelsCount, aLevelIndex + 1,
						aItemsCount, aIndex,
						// user enum procs
						aEnumerator,
						isPostorder
					);
					// ok!
					if (!ok) break;
					++ aIndex;
				}//end do
				// ok!
			} finally {
				// stop enumerating pages
				if (aEnumerator != null)
					ok = aEnumerator.OnStopEnumPages (
						this, aLevelsCount, aLevelIndex + 1, aItemsCount
					) && ok;
				//end if
			}

		}//end if

		if (ok)
			if (isPostorder)
				// traverse aPage in post-order
				if (aEnumerator != null)
					ok = aEnumerator.OnEnumPage (
						this,
						aLevelsCount, aLevelIndex,
						aPagesListCount, aPageListIndex,
						aPage.IsDataPage(), //aPage.GetPageType(),
						aPage.GetItemsCount(), aPage.GetDeepItemsCount()
					);
				//end if
			//end if
		//end if

		return ok;
	}

	// deep enum B+Tree pages

	public bool DeepEnumBTreePages (
		IVRPLBTreeEnumerator aEnumerator,
		bool isPostorder
	) {
		bool ok = true;
		if (this.AnyRootPage()) {

			int aLevelsCount = this.CountBTreeLevels();

			// start enumerating pages
			if (aEnumerator != null)
				ok = aEnumerator.OnStartEnumPages (
					this,
					aLevelsCount, /*/aLevelIndex/*/(0), /*/aItemsCount/*/(1)
				);
			//end if

			if (!ok) return false;

			try {
				// enumerate the root-page
				ok = this.DeepEnumPage (
					this.RootPage, aLevelsCount, /*/aLevelIndex/*/(0),
					/*/aItemsCount/*/(1L), /*/aPageIndex/*/(0L),
					aEnumerator,
					isPostorder
				);
				// ok!
			} finally {
				// stop enumerating pages
				if (aEnumerator != null)
					ok = aEnumerator.OnStopEnumPages (
						this,
						aLevelsCount, /*/aLevelIndex/*/(0), /*/aItemsCount/*/(1L)
					) && ok;
				//end if
				// ok!
			}

		}//end if
		return ok;
	}

	// macro

	public bool DeepEnumBTreePages (
		IVRPLBTreeEnumerator aEnumerator
	) {
		return this.DeepEnumBTreePages (aEnumerator, false);
	}


//=======================================================================================

	// DEBUG Procs end

#endregion

//=======================================================================================
// Compact
//=======================================================================================

#region Compact

#region Compact - Low Level Procs

	// Compacting All Pages

	// compact any page type

	private void CompactPage (VRPLAbstPage aPage)
	{
		// assert: (aPage != null) !!
		while (true) { //do {//do loop

			// compute the number of data-items to fill up this data-page
			long fillupItemsCount = this.GetPageSizeOf(aPage) - aPage.GetItemsCount() ;

			// break if aPage is Full !!
			if (fillupItemsCount <= 0L) break;

			// assert: (fillupItemsCount > 0) !!

			// get the next page
			VRPLAbstPage nextPage = aPage.GetNextPage();

			// skip any empty page
			while (true) 
			{
				if (nextPage == null) break;
				if ( ! nextPage.IsEmpty() ) break;
				nextPage = nextPage.GetNextPage();
			}

			// break if aDataPage is the last data-page
			if (nextPage == null) break;

			// assert: (not this.IsPageFull (aPage)) !!
			// assert: (not aPage.IsLastPage()) !!

			long itemsToMoveFromNextPage = fillupItemsCount;
			if (fillupItemsCount > nextPage.GetItemsCount())
				// clip itemsToMoveFromNextPage if it is too large
				itemsToMoveFromNextPage = nextPage.GetItemsCount();
			//end if

			// move (itemsToMoveFromNextPage) items into aPage from nextPage
			VRPLAbstPage.MoveAnyPageItems (
				/*/dst-page/*/ aPage, /*/src-page/*/ nextPage,
				/*/items-count/*/ itemsToMoveFromNextPage
			);
			// end move

			if (aPage.IsDataPage())
				// <<Structure-Changed!!>>
				this.ChangeStructState();
			//end if

			if (nextPage.IsEmpty())
				// ELIMINA la prossima pagina se questa si svuota !!
				// cio� se tutti gli items sono stati spostati nella pagina da compattare
				this.DestroyOldPLPage (nextPage);
			//end if

			// ripeti con la prossima pagina di aPage
			// finch�
			// 	aPage is full OR
			// 	aPage is the Last data-page

		} //while (true); //end loop
		// done!
	}

	// to compact a list of pages

	private bool CompactPagesList (VRPLAbstPage aPage, IVRPLCompactBTreePagesMonitor aMonitor)
	{
		bool ok = true;
		// start compact loop
		while (true) {//do

			if (aPage == null) break;

			// check for aPage.IsLastPage()
			if (aPage.IsLastPage()) break; // break on Last page

			// full-pages do NOT Need to be Compacted
			if ( ! this.IsPageFull (aPage) )
			{
				// Compact ONLY Partially Filled pages

				// Compacting ...
				// invoke our user call-back first
				if (aMonitor != null)
					ok = aMonitor.OnCompactingPagesLevelStep (this, aPage.IsDataPage());
					// break on any exception!
				//end if
				if (!ok) break;

				// Compact ONLY Partially Filled pages
				this.CompactPage (aPage);

				// <<Structure-Changed!!>>
				//this.ChangeStructState();

			}//end if

			// skip to the next one
			aPage = aPage.GetNextPage();

		}//end do
		// done!
		return ok;
	}

#endregion

//=======================================================================================

#region Compact - High Level Procs

	public bool CompactAllPages (IVRPLCompactBTreePagesMonitor aMonitor)
	{
		bool ok = true;

		// get the first data-page
		VRPLAbstPage aPage = this.GetFirstDataPage();

		while (true) {

			if (aPage == null) break;

			// begin compacting this level

			bool aIsDataPage = aPage.IsDataPage();

			if (aMonitor != null)
				ok = aMonitor.OnCompactingPagesLevelBegin (this, aIsDataPage);
			//end if

			if (!ok) break;

			try {

				// compact pages list
				ok = this.CompactPagesList (aPage, aMonitor);
				// ok!

			} finally {

				// end compacting this level

				if (aMonitor != null)
					ok = aMonitor.OnCompactingPagesLevelEnd (this, aIsDataPage) && ok;
				//end if

			}

			// end

			if (!ok) break;

			// go up a level
			aPage = aPage.GetParentPage();

		}//loop

		// done!
		return ok;
	}

#endregion

	public bool CompactAllPages()
	{
		return this.CompactAllPages (null);
	}

//=======================================================================================

	// aliases

	public bool Compact (IVRPLCompactBTreePagesMonitor aMonitor)
	{
		return this.CompactAllPages (aMonitor);
	}

	public bool Compact() {return this.Compact (null);}

#endregion

//=======================================================================================


//=======================================================================================
// Inserting into / Removing from this Paged List
//=======================================================================================

#region Inserting into / Removing from this Paged List

//=======================================================================================
// Building data / refs pages
//=======================================================================================

#region Building data / refs pages

	// new refs pages

	private VRPLRefsPage NewRefsPage (long aSize)
	{
		return new VRPLRefsPage (aSize);
	}

	/*/
		long aRefsSize = this.GetRefsPageSize();
		if (aRefsSize < 2L)
			throw new VRPLInvalidRefsPageSizeException (this);
	/*/

	private VRPLRefsPage NewRefsPage()
	{
		// check refs-page size
		this.CheckValidRefsPageSize();
		// ok!
		return this.NewRefsPage (this.RefsPageSize);
	}

	// new data pages

	private VRPLDataPage NewDataPage (long aSize)
	{
		return new VRPLDataPage (aSize);
	}

	/*/
		//long aRefsSize = this.GetRefsPageSize();
		long aDataSize = this.GetDataPageSize();
		//if (aRefsSize < 2L)
			//throw new VRPLInvalidRefsPageSizeException (this);
		if (aDataSize < 2L)
			throw new VRPLInvalidDataPageSizeException (this);
	/*/

	private VRPLDataPage NewDataPage()
	{
		// check data-page size
		this.CheckValidDataPageSize();
		// ok!
		return this.NewDataPage (this.DataPageSize);
	}

	// to dispose a page

	private void DisposePage (VRPLAbstPage aPage)
	{
		aPage.SetParentPage (null);
		aPage.Unlink();
	}

	// recursively disposing of an entire page sub-tree (not used)

	private void DeepDisposePage (VRPLAbstPage aPage)
	{
		if (aPage == null) return;
		if (aPage.IsRefsPage()) {
			long aCount = aPage.GetItemsCount();
			long aIndex = 0L;
			while (aIndex < aCount) {
				VRPLAbstPage aSubPage = aPage.GetPageRefAt (aIndex);
				// invoke FreePageRecur on (aSubPage)
				this.DeepDisposePage (aSubPage);
				// unlink aSubPage
				aPage.SetPageRefAt (aIndex, null);
				// next
				++ aIndex;
			}//loop
		}
		// finally simply ... dispose (aPage);
		this.DisposePage (aPage);
	}

#endregion

//=======================================================================================
// Inserting into a Page
//=======================================================================================

#region Inserting into a Page

	/*/ Inserting Into a Page (MAIN PROCS) /*/

	private VRPLAbstPage CreateNewRootPage()
	{
		VRPLAbstPage aNewPage = null;
		if (this.NoRootPage())
			// no root-page: create a root data-page
			aNewPage = this.NewDataPage();
		else
			// a root-page is already there: create a refs-page
			aNewPage = this.NewRefsPage();
		//end if
		// ok!
		if (aNewPage != null) // always true!
			// also set it as the new root-page
			this.RootPage = aNewPage;
		//end if
		return (aNewPage);
	}


	// InsertIntoRefsPage [macro]

	private void InsertIntoRefsPage
		(ref VRPLAbstPage aInsRefsPage, VRPLAbstPage aCallerPeerPage, VRPLAbstPage aPageToIns)
	{
		long pindex = 0L;
		this.InsertIntoPLPage (
			ref aInsRefsPage, ref pindex,
			aCallerPeerPage,
			aPageToIns,
			/*/userData/*/ null
		);
	}


	// CreateNewPLPage

	/*/ CreateNewPLPage(aCallerPeerPage) creates a new page of the same type of [aCallerPeerPage]
		then try to insert the newly created page into the parent of [aCallerPeerPage].

		Note that this parent page may be null if [aCallerPeerPage] is the OLD-Root-Page
		in this case then a NEW Root-Page will be allocated
		and [aCallerPeerPage] and the Newly Created Page
		will be Inserted into this NEW Root-Page
		making the B+Tree growing up a level !!
	/*/

	private VRPLAbstPage CreateNewPLPage (VRPLAbstPage aCallerPeerPage)
	{
		// ASSERT: (aCallerPeerPage != null) !!
		VRPLAbstPage aNewPage = null;
		VRPLAbstPage aCallerParent = null;
		//
		if (aCallerPeerPage != null) {
			// must always be true!
			// get the parent of aCallerPeerPage we have to insert into
			aCallerParent = aCallerPeerPage.GetParentPage();
			if (aCallerPeerPage.IsDataPage())
				// create a new data page
				aNewPage = this.NewDataPage();
			else
				// create a new refs-page of page-pointers
				aNewPage = this.NewRefsPage();
			//end if
		}
		//else
			// BOMB !! // this should never happen!
			// return null;
		//end if
		// try to insert the new page
		if (aNewPage != null) {
			// insert (aNewPage) into (aCallerParent) after (aCallerPeerPage)
			// aCallerParent is the page we should insert into (may be null!)
			try {
				this.InsertIntoRefsPage (
					ref aCallerParent, // which is aCallerPeerPage.ParentPage(),
					aCallerPeerPage, // the page-ref we should look-up for
					aNewPage // the page to insert itself!
				);
				// ok!
			}
			catch (Exception) {
				this.DisposePage (aNewPage);
				// raise again
				throw;
			}
		}
		return (aNewPage); // this may be null if new or the insertion would fail
	}


	// InsertIntoPLPage

	/*/ InsertIntoPLPage(...) does all the dirty work of inserting
		user-data items into data-pages
		page-ref items into refs-pages

		if aPageToIns is null then we are inserting a new data item into a data page
	/*/

	/*/ InsertIntoPLPage returns in (aPage, pindex)
		the page & local index where the next item can be inserted
	/*/

	private void InsertIntoPLPage (
		ref VRPLAbstPage aPage, ref long pindex,
		VRPLAbstPage aCallerPage, VRPLAbstPage aPageToIns,
		object userData
	) {
		// if aPageToIns is null then we are inserting a new data item into a data page
		if (aPageToIns == null) {

			// inserting a new data item into a data page

			// pindex range checking
			if (aPage != null) {
				if (aPage.IsDataPage()) {
					// it is a data-page
					// check for a valid item index ...
					if ( ! aPage.IsInsertIndexValid (pindex) )
						//raise invalid insert index exception !!
						throw new VRPLInvalidInsertIndexException (
							this,
							/*/index:/*/ VRPLAbstPage.ComputeGlobalIndexFromDataPageLocalIndexPair (aPage, pindex),
							/*/count:/*/ this.ItemsCount
						);
						// fail
					//end if
					// ok!
				}//end if
			} else {
				// no page: pindex must be (0) !!
				if (pindex != 0L)
					// raise invalid insert index exception !!
					throw new VRPLInvalidInsertIndexException (this, /*/index:/*/ pindex, /*/count:/*/ this.ItemsCount);
					// fail
				//end if
			}//end if

			// also check the list size limit ...
			this.CheckSizeLimit();
			// ok!

		}//end if

		// ok!

		if (aPage == null) 
		{

			// the B+Tree should grow up a level: create a new root-page!
			aPage = this.CreateNewRootPage();

			if (aPage != null)
				if (aPage.IsRefsPage())

					// insert (aCallerPage) into (aPage) at index (0) after page (null)
					//this.InsertPageRefIntoRefsPage (
					aPage.InsertPageRefExt (
						0L, // insert page & index
						null, // no peer-page to link with // NullPageRef
						aCallerPage // the page to insert
					);

				//end if
			//end if

		}//end if

		if (aPage == null)
			//raise; // fail
			throw new VRPLInternalListErrorException (this);

		// ok!

		// recompute "pindex" if it is a pointers page!
		if (aPage.IsRefsPage()) {
			// insert "aPageToIns" in {"aPage"} after "aCallerPage"
			pindex = aPage.IndexOfPageRef (aCallerPage) + 1L;
			// check pindex range again
			if ( ! aPage.IsInsertIndexValid (pindex) )
				// BOMB !!
				// should never happen
				//return TVRPLTypes::kPLInsInvalidInsertIndexErr; //raise;
				throw new VRPLInternalListErrorException (this);
				// fail
			//end if
		}//end if

		{//do
			// try to optimize page insertion & avoid a page splitting...

			// try to optimize insertion if at the begin of "aPage"
			// by making the insertion at end of the previous one!
			// always do this no matter if the page is full
			{
				if (pindex <= 0L) {// (pindex == 0L)
					VRPLAbstPage prvPage = aPage.GetPrevPage();
					if (prvPage != null)
						if ( ! this.IsPageFull (prvPage) ) {
							aPage = prvPage;
							pindex = prvPage.GetItemsCount();
						}//end if
					//end if
				}//end if
			}

			// optimize insertion at end of a page only if it is full
			// by making the insertion at beginning of the next page
			{
				if (this.IsPageFull (aPage))
					if (pindex >= aPage.GetItemsCount()) {// (pindex == aPage->ItemsCount())
						VRPLAbstPage nxtPage = aPage.GetNextPage();
						if (nxtPage != null)
							if ( ! this.IsPageFull (nxtPage) ) {
								// insert at beginning of the next page
								aPage = nxtPage;
								pindex = 0L;
							}//end if
						//end if
					}//end if
				//end if
			}

		}//end do

		// try further optimizations
		{//do

			// NOTE: the aPage var could have been changed by the previos code

			// if aPage is full try to make room for the new item by moving
			// the last item of "aPage" into "nxtPage" (if any and if it is not full)
			{
				if (this.IsPageFull (aPage)) {
					VRPLAbstPage nxtPage = aPage.GetNextPage();
					if (nxtPage != null)
						if ( ! this.IsPageFull (nxtPage) ) {

							VRPLAbstPage.MoveLastItemIntoNextPage (nxtPage, aPage);

							// pindex remains the same!
							// pindex = pindex !!

						}//end if
					//end if
				}//end if
			}

			{
				if (this.IsPageFull (aPage))
					// aPage is still full: the above optimization failed
					if (pindex > 0L) {
						// try this only if we are not inserting at the top of the page
						// otherwise "pindex" could become invalid (negative)
						VRPLAbstPage prvPage = aPage.GetPrevPage();
						if (prvPage != null)
							// a previous page exists
							if ( ! this.IsPageFull (prvPage) ) {

								VRPLAbstPage.MoveFirstItemIntoPrevPage (prvPage, aPage);

								// pindex needs to be updated
								// pindex := pindex - 1;
								pindex -= 1L;

							}//end if
						//end if
					}//end if
				//end if
			}

		}//end do

		// PAGE SPLITTING
		if (this.IsPageFull (aPage)) {
			// aPage is still full: all the above optimizations failed
			// an optimized page insertion was not possible: try to split up the page!
			// do split up the page...

			// create a new *empty* page
			VRPLAbstPage aNewPage = this.CreateNewPLPage (aPage);

			// NOTE: "aNewPage" is inserted after "aPage"

			if (aNewPage != null) {
				// a new page was successfully created: move (k / 2) items from "aPage" into "aNewPage"

				VRPLAbstPage.MoveItemsForPageSplit (aNewPage, aPage);

				// recompute pindex & aPage if the insertion is not to be made in the same original page
				if (pindex > aPage.GetItemsCount()) {

					// recompute "pindex" & "aPage" to know where the insertion is to be correctly made!
					// pindex := pindex - aPage.ItemsCount();
					pindex -= aPage.GetItemsCount();

					// insert into aNewPage
					aPage = aNewPage;

				}//end if
			}
			//else
				// cannot create page to split into // failure("out of memory")
				// failure!
				// 'cuz if we cannot split aPage it will remain Full
			//end if
		}//end if

		if ( this.IsPageFull (aPage) )
			// strangely, the page is still full
			throw new VRPLInternalListErrorException (this);
			// failure("out of memory")
			//return TVRPLTypes::kPLInsOutOfMemoryErr; //raise;
		// ok!

		// SUCCESS !!

		// Actual Item Insertion

		// assert: (aPage.IsInsertIndexValid (pindex) is true) !!

		if (aPage.IsRefsPage())
			// aPage is a refs-page

			// insert (aPageToIns) into (aPage) at index (pindex) after page (aCallerPage)
			aPage.InsertPageRefExt (
				pindex, // the insert page & index
				aCallerPage, // the aPageToIns peer page we have to link to
				aPageToIns // the page to insert
			);

		else
		{
			// aPage is a data-page

			// <<Structure-Changed!!>>
			this.ChangeStructState();

			// insert that data item
			aPage.InsertUserData (pindex, userData);

		}//end if

		// SUCCESS !!

		// pindex is the position in (aPage)
		// where the next insertion could be made
		// ++ pindex; // DISABLED !!

		//ok!
		return;
	}


	// InsertIntoDataPage [macro]

	private void InsertIntoDataPage
		(ref VRPLAbstPage aPage, ref long pindex, object userData)
	{
		this.InsertIntoPLPage (
			/*/@/*/ ref aPage, /*/@/*/ ref pindex,
			/*/aCallerPage/*/ null, /*/aPageToIns/*/ null,
			/*/user-data-item/*/ userData
		);
	}

#endregion

//=======================================================================================
// Removing from a Page
//=======================================================================================

#region Removing from a Page

	// RemoveFromRefsPage [macro]

	private void RemoveFromRefsPage (ref VRPLAbstPage aDelRefsPage, VRPLAbstPage aPageToRem)
	{
		// ...
		long pindex = 0L;
		this.RemoveFromPLPage (ref aDelRefsPage, ref pindex, aPageToRem);
	}

	private void DestroyOldPLPage (VRPLAbstPage aPage)
	{
		// ASSERT: aPage->IsEmpty() must be true !!
		// get the aPage's parent-page
		VRPLAbstPage parentPage = aPage.GetParentPage();
		//
		if (parentPage != null)
			// remove (aPage) from its parent
			this.RemoveFromRefsPage (ref parentPage, aPage);
		else {
			// aPage does Not have a parent-page: it must be our Root-Page !!
			if (this.RootPage == aPage)
				// should always be true !!
				// aPage is our Root-Page
				// assert: (aPage.NextPage() == aPage.PrevPage() == null) !!
				if (aPage.GetItemsCount() <= 0L)
					// it was the root data-page: no more remaining elements in this paged list!
					// it was the ROOT DATA-PAGE
					// assert: (aPage.IsDataPage() is true) !!
					// Clear the RootPage !!
					this.RootPage = null; // NullPageRef
				else {
					// it was an empty root refs-page (that is, a refs-page with only one page ref !)
					// it was a ROOT REFS-PAGE
					// assert: (aPage.IsRefsPage() is true) !!
					// assert: (aPage.ItemsCount() == 1) !!
					// set the new root-page from the deleted one
					VRPLAbstPage newRootPage = aPage.GetPageRefAt (0L);
					newRootPage.SetParentPage (null); // NullPageRef
					this.RootPage = newRootPage; // ( aPage->PageRefAt (0L) );
				}//end if
			//else
				// aPage is not our root-page
				// BOMB!
			//end if
		}//end if
		//dispose (aPage)
		this.DisposePage (aPage);
	}


	/*/ RemoveFromPLPage : does all the dirty work of deleting
		user-data items from data-pages
		page-ref items from refs-pages
	/*/

	/*/ RemoveFromPLPage ritorna in (aPage,pindex)
		la pagina ed il local-index del prossimo item che si pu� rimuovere

		se (aPage � null) allora
			non esiste un prossimo item da rimuovere
	/*/

	/*/
		a cause della Compattazione una pagina potrebbe contenere un solo item.
		in questo caso, quando questo unico item viene rimosso allora
		la pagina diventa vuota.
		se la pagina diventa vuota allora
		viene semplicemente distrutta
	/*/

	private void RemoveFromPLPage (
		ref VRPLAbstPage aPage, ref long pindex,
		VRPLAbstPage aPgToRem
	) {

		if (aPage == null)
			// raise invalid item index !
			throw new VRPLInvalidItemIndexException (this, pindex, this.ItemsCount);
		// assert: (aPage != null) !!

		if (aPage.IsDataPage())
		{
			// aPage is a data-page

			if ( ! aPage.IsItemIndexValid (pindex) )
				// raise invalid item index !
				throw new VRPLInvalidItemIndexException (
					this,
					/*/index:/*/ VRPLAbstPage.ComputeGlobalIndexFromDataPageLocalIndexPair (aPage, pindex),
					/*/count:/*/ this.ItemsCount
				);
			// ok!

			// <<Structure-Changed!!>>
			this.ChangeStructState();

			// remove user data from aPage at pindex
			aPage.RemoveUserData (pindex);

		}
		else
		{
			// aPage is a refs-page

			// compute the index of (aPgToRem) into (aPage)
			pindex = aPage.IndexOfPageRef (aPgToRem);

			// check for a valid page item index
			if ( ! aPage.IsItemIndexValid (pindex) )
				// BOMB!
				// raise internal error !
				throw new VRPLInternalListErrorException (this);
			// ok!

			// remove the page ref from aPage at (pindex)
			aPage.RemovePageRefExt (pindex);

		}

		bool doAdjustPageItems = ( ! aPage.IsEmpty() );

		// se la pagina � vuota allora
		// non fare nulla e semplicemente distruggila

		if (doAdjustPageItems) { //(!aPage->IsEmpty()) {
		// the page is NOT empty, the page Contains Some Items

		// questo blocco non fa nulla se la pagina � la root-page !!

		long kPageMinLimit = this.HalfPageSizeOf (aPage);

		VRPLAbstPage prvPage = aPage.GetPrevPage();
		VRPLAbstPage nxtPage = aPage.GetNextPage();

		// try to avoid a page merge...

		// by borrowing an item from the next page
		if (aPage.GetItemsCount() < kPageMinLimit)
			if (nxtPage != null)
				if (nxtPage.GetItemsCount() > kPageMinLimit) {

					//move first item of (nxtPage) into (aPage)
					//* first item of (nxtPage) becomes the last item of (aPage)
					VRPLAbstPage.MoveFirstItemIntoPrevPage (/*/dest/*/aPage, /*/src/*/nxtPage);

					// pindex is left unchanged !!
					// pindex := pindex !!

				}//end if
			//end if
		//end if

		// by borrowing an item from the previous page
		if (aPage.GetItemsCount() < kPageMinLimit)
			if (prvPage != null)
				if (prvPage.GetItemsCount() > kPageMinLimit) {

					//move last item of (prvPage) into (aPage)
					//* last item of (prvPage) becames the first of (aPage)
					VRPLAbstPage.MoveLastItemIntoNextPage (/*/dest/*/aPage, /*/src/*/prvPage);

					// pindex is increased by one
					pindex += (1L);

				}//end if
			//end if
		//end if

		// try a page merge!

		if (aPage.GetItemsCount() < kPageMinLimit) {

			VRPLAbstPage destPage = null; // NullPageRef
			VRPLAbstPage pageToDel = null; // NullPageRef

			if (prvPage != null)
				if (prvPage.GetItemsCount() <= kPageMinLimit) {
					// the previous page has room for aPage.ItemsCount() items

					// move items from this page into the previous one
					destPage = prvPage;
					// and delete the source page
					pageToDel = aPage;

					// update pindex
					// pindex := pindex + prvPage.ItemsCount()
					pindex += prvPage.GetItemsCount();

				}//end if
			//end if

			if (destPage == null)
				// the previous test failed
				if (nxtPage != null)
					// but we got a next page
					if (nxtPage.GetItemsCount() <= kPageMinLimit) {
						// and it has room for aPage.ItemsCount() items

						// move items into this page from the next one
						destPage = aPage;
						// and delete the next page
						pageToDel = nxtPage;

						// pindex remains the same!
						// pindex = pindex !!

					}//end if
				//end if
			//end if

			if (destPage != null) {
				// do merge!
				// this will empty [pageToDel]

				// do merge!
				VRPLAbstPage.MoveItemsForPageMerge (destPage, pageToDel);
				// this will empty [pageToDel]

				// finally destroy the source (and now empty) page!
				this.DestroyOldPLPage (pageToDel);

				// continue with destPage
				aPage = destPage; 	// <== !!

			}//end if

		}//end if

		// the page was not empty
		}//end if

		bool canDestroyPage = aPage.CanBeDisposed();

		if (canDestroyPage) { //(aPage->IsEmpty())
			// the page is empty!

			VRPLAbstPage nextPage = aPage.GetNextPage();
			// nextPage can be null
			// if (aPage is the root-page) || (aPage is the last one)

			// finally destroy the empty page
			this.DestroyOldPLPage (aPage);

			// release aPage ptr
			// aPage = null; //NullPageRef(); // !!
			aPage = nextPage; // !!
			pindex = (0L); // !!!!!

			// the next item to delete can be found
			// on the next page (if any) at index (0)

		}//end if

		if (aPage != null)
			if ( ! aPage.IsItemIndexValid (pindex) ) {
				// we removed the last item of aPage:
				// the next item to remove
				// is the first one on the next page
				aPage = aPage.GetNextPage();
				pindex = (0L);
			}//end if
		//end if

		// done!
		//ok!
		return;
	}


	// RemoveFromDataPage [macro]

	private void RemoveFromDataPage (ref VRPLAbstPage aPage, ref long pindex)
	{
		this.RemoveFromPLPage
			(ref aPage, ref pindex, /*/NullPageRef/*/ null);
	}

#endregion

//=======================================================================================
// inserting into / removing from a data page -- extended procs
//=======================================================================================

#region inserting into / removing from a data page -- extended procs

	/*/
		WARNING: these procs should be declared "internal"

		because they are also called by the list-iterator

		and no one else should invoke them !!
	/*/

	// insert

	// package //public
	internal void InsertIntoDataPageExt (
		ref VRPLAbstPage aDataPageRef, ref long aDataPageIndex,
		object aItemData,
		long aInsGlobalIndex
	) {
		// about inserting item ...

		// try to insert the new item!
		this.InsertIntoDataPage
			(ref aDataPageRef, ref aDataPageIndex, aItemData);
		// ok!

		// except
			// cannot insert item !!
		//

		// after insert item ...
		// catch!

		// done!
	}

	// delete

	// package //public
	internal void RemoveFromDataPageExt (
		ref VRPLAbstPage aDataPageRef, ref long aDataPageIndex,
		long aGlobalIndex
	) {
		// about deleting item ...

		// try to delete next item!
		this.RemoveFromDataPage
			(ref aDataPageRef, ref aDataPageIndex);
		// ok!
		// except
			// cannot delete item !!
		//
		// ok!

		// after delete item ...
		// catch!

		// done!
	}


#endregion

//=======================================================================================

#endregion

//=======================================================================================

//=======================================================================================
// Searching an Auto Ordered List
//=======================================================================================

#region Searching an Auto Ordered List

//=======================================================================================
// Binary Search in a data page
//=======================================================================================

#region Binary Search in a data page

	// ============================
	// BINARY Search in a Data-Page
	// ============================

//=======================================================================================
// Binary Search in a data page - Adjusting Binary Search results

#region Binary Search in a data page - Adjusting Binary Search results

	/*/
		seeking begin/end of a sequence of equal items in a data-page
	/*/

	// backward search :: used in direct searches

	// Find Last DataPage NotEqual Item Index

	// old: FindDataPageEqItemsSeqBeginIndex

	private long FindLastDataPageNotEqualItemIndex (
		VRPLAbstPage aDataPage,
		long aStartingIndex,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc
	) {
		long aItemIndex = aStartingIndex; // - 1L;
		while (true) {

			if ( ! aDataPage.IsItemIndexValid (aItemIndex) ) break;

			// get item
			object aItem = aDataPage.GetItemAt (aItemIndex);

			// compare: aItemOrKeyToSearch vs aItem
			int relCmpVal = this.Compare (aCompareFunc, aKeyValue, aItem);

			if (relCmpVal != 0)
				// (aKey != aVect[i])
				break;

			//else continue
			-- aItemIndex;
		}
		return aItemIndex; // + 1L;
	}

//=======================================================================================

	// forward search :: used in reverse searches

	// Find First DataPage NotEqual Item Index

	// old: FindDataPageEqItemsSeqEndIndex

	private long FindFirstDataPageNotEqualItemIndex (
		VRPLAbstPage aDataPage,
		long aStartingIndex,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc
	) {
		long aItemIndex = aStartingIndex; // + 1L;
		while (true) {

			if ( ! aDataPage.IsItemIndexValid (aItemIndex) ) break;

			// get item
			object aItem = aDataPage.GetItemAt (aItemIndex);

			// compare: aItemOrKeyToSearch vs aItem
			int relCmpVal = this.Compare (aCompareFunc, aKeyValue, aItem);

			if (relCmpVal != 0)
				// (aKey != aVect[i])
				break;

			//else continue
			++ aItemIndex;
		}
		return aItemIndex; // - 1L;
	}

#endregion

//=======================================================================================
// Binary Search in a data page - Basic Asc/Des Procs
//=======================================================================================

#region Binary Search in a data page - Basic Asc/Des Procs

//=======================================================================================

	/*/ FindOrderedDataPageItemIndex

		- aSearchMode: can be
		== (0) :
			to find an exact match
		> (0) : >= (+1) :
			to find the nearest item index in direct-mode (from the start)
		< (0) : <= (-1) :
			to find the nearest item index in reverse-mode (from the end)
	/*/

//=======================================================================================

	/*/ FindAscendingOrderedDataPageItemIndex

		assume aDataPage items are in Ascending Order
	/*/

	// Find Ascending Ordered DataPage ItemIndex

	// old: FindDataPageItemIndexAscending

	private long FindAscendingOrderedDataPageItemIndex (
		VRPLAbstPage aDataPage,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode
		bool aFindNearestItemMode,
		bool aReverseSearchMode
	) {
		bool aFindItemMode = ! aFindNearestItemMode;
		bool aDirectSearchMode = ! aReverseSearchMode;

		// ASSERT: (this->IsAscendingOrderItems()) must be true !!
		// ASSERT: (aDataPage != NULL) !!
		long loIndex = 0L;
		long hiIndex = aDataPage.GetItemsCount() - 1L;

		long midIndex = (-1L);
		bool found = false;

		while (loIndex <= hiIndex) {

			/*/long/*/ midIndex = (loIndex + hiIndex) / 2L;

			// get middle item
			object aItem = aDataPage.GetItemAt (midIndex);

			// compare: aItemOrKeyToSearch vs aItem
			int relCmpVal = this.Compare (aCompareFunc, aKeyValue, aItem);

			if (relCmpVal == 0) {
				// (aKey == aVect[mid]): an exact match was found!
				found = true;
				break;
				//return (midIndex);
			}//end if

			// Ascending order
			if (relCmpVal < 0)
				// (aKey < aVect[mid]): search into the lower side
				hiIndex = midIndex - 1L;
			else
				// (aKey > aVect[mid]): search into the upper side
				loIndex = midIndex + 1L;
			//end if

		}//repeat

		long aIndex = (-1L);

		if (found) {

			// found!
			aIndex = (midIndex);

		} else {

			// an exact match was not found!

			if (aFindItemMode) {
				// find the (exact) item index
				if (aDirectSearchMode)
					// an exact match was not found in direct mode
					aIndex = aDataPage.GetItemsCount();
				else
					// aSearchMode == (0) : an exact match was not found
					aIndex = (hiIndex - loIndex); // aIndex = (-1L);
				//end if
			} else {
				// find the nearest item index
				//if (aSearchMode > (0))
				if (aDirectSearchMode)
					// aSearchMode >= (+1) : find the nearest item index in direct mode
					aIndex = (loIndex);
				else
				//if (aSearchMode < (0))
					// aSearchMode <= (-1) : find the nearest item index in reverse mode
					aIndex = (hiIndex);
				//end if
			}//end if

		}//end if

		if (this.AccurateOrderedSearch) {

			// use accurate binary search

			if (aDirectSearchMode)

				// direct: go bwd <<

				aIndex = this.FindLastDataPageNotEqualItemIndex (
					aDataPage,
					aIndex - 1L,
					aKeyValue,
					aCompareFunc
				) + 1L;

			else

				// reverse: go fwd >>

				aIndex = this.FindFirstDataPageNotEqualItemIndex (
					aDataPage,
					aIndex + 1L,
					aKeyValue,
					aCompareFunc
				) - 1L;

			//end if

		}//end if

		return aIndex;
	}

//=======================================================================================

	/*/ FindDescendingOrderedDataPageItemIndex

		assume aDataPage items are in Descending Order
	/*/

	// Find Descending Ordered DataPage ItemIndex

	// old: FindDataPageItemIndexDescending

	private long FindDescendingOrderedDataPageItemIndex (
		VRPLAbstPage aDataPage,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode
		bool aFindNearestItemMode,
		bool aReverseSearchMode
	) {
		bool aFindItemMode = !aFindNearestItemMode;
		bool aDirectSearchMode = !aReverseSearchMode;

		// ASSERT: (this->IsDescendingOrderItems()) must be true !!
		// ASSERT: (aDataPage != NULL) !!
		long loIndex = 0L;
		long hiIndex = aDataPage.GetItemsCount() - 1L;

		long midIndex = (-1L);
		bool found = false;

		while (loIndex <= hiIndex) {

			/*/long/*/ midIndex = (loIndex + hiIndex) / 2L;

			// get middle item
			object aItem = aDataPage.GetItemAt (midIndex);

			// compare: aItemOrKeyToSearch vs aItem
			int relCmpVal = this.Compare (aCompareFunc, aKeyValue, aItem);

			if (relCmpVal == 0) {
				// (aKey == aVect[mid]): an exact match was found!
				found = true;
				break;
				//return (midIndex);
			}//end if

			// Descending order
			if (relCmpVal > 0)
				// (aKey > aVect[mid]): search into the lower side
				hiIndex = midIndex - 1L;
			else
				// (aKey < aVect[mid]): search into the upper side
				loIndex = midIndex + 1L;
			//end if

		}//repeat

		long aIndex = (-1L);

		if (found) {

			// found!
			aIndex = (midIndex);

		} else {

			// an exact match was not found!

			if (aFindItemMode) {
				// find the (exact) item index
				if (aDirectSearchMode)
					// an exact match was not found in direct mode
					aIndex = aDataPage.GetItemsCount();
				else
					// aSearchMode == (0) : an exact match was not found
					aIndex = (hiIndex - loIndex); // aIndex = (-1L);
				//end if
			} else {
				// find the nearest item index
				//if (aSearchMode > (0))
				if (aDirectSearchMode)
					// aSearchMode >= (+1) : find the nearest item index in direct-mode
					aIndex = (loIndex);
				else
				//if (aSearchMode < (0))
					// aSearchMode <= (-1) : find the nearest item index in reverse-mode
					aIndex = (hiIndex);
				//end if
			}//end if

		}//end if

		if (this.AccurateOrderedSearch) {

			// use accurate binary search

			if (aDirectSearchMode)

				// direct: go bwd <<

				aIndex = this.FindLastDataPageNotEqualItemIndex(
					aDataPage,
					aIndex - 1L,
					aKeyValue,
					aCompareFunc
				) + 1L;

			else

				// reverse: go fwd >>

				aIndex = this.FindFirstDataPageNotEqualItemIndex(
					aDataPage,
					aIndex + 1L,
					aKeyValue,
					aCompareFunc
				) - 1L;

			//end if

		}//end if

		return aIndex;
	}

//=======================================================================================

	/*/ FindOrderedDataPageItemIndex

		performs an Ascending/Descending Order Binary Search
		based upon the [IsAscendingOrderItems()] property
	/*/

	// FindOrderedDataPageItemIndex

	private long FindOrderedDataPageItemIndex (
		VRPLAbstPage aDataPage,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode
		bool aFindNearestItemMode,
		bool aReverseSearchMode
	) {
		if (this.IsAutoOrdered()) {

			// items are Ordered

			if (this.IsAutoAscendingOrder())
				// items are in Ascending Order
				return this.FindAscendingOrderedDataPageItemIndex (
					aDataPage, aKeyValue, aCompareFunc,
					//aSearchMode
					aFindNearestItemMode,
					aReverseSearchMode
				);
			else
				// items are in Descending Order
				return this.FindDescendingOrderedDataPageItemIndex (
					aDataPage, aKeyValue, aCompareFunc,
					//aSearchMode
					aFindNearestItemMode,
					aReverseSearchMode
				);
			//end if

		} else {

			// items are not Ordered
			if (aReverseSearchMode)
				// [nearest], reverse
				return (-1L);
			else
				// [nearest], direct
				return aDataPage.GetItemsCount();
			//end if

		}//end if
	}

//=======================================================================================

	/*/
	// items are un-ordered
	if (aSearchMode > 0)
		// nearest, direct
		return aDataPage.GetItemsCount();
	else
	if (aSearchMode < 0)
		// nearest, reverse
		return (-1L);
	else
		// exact match
		return (-1L);
	//end if
	/*/

//=======================================================================================

#endregion


//=======================================================================================
// Binary Search in a data page - Looking for an actual / nearest item
//=======================================================================================

#region Binary Search in a data page - Looking for exact / nearest item

//=======================================================================================
// looking for an exact item match

	// direct // first

	// FindFirstOrderedDataPageItemIndex

	// old: FindDataPageItemIndexDirect

	private long FindFirstOrderedDataPageItemIndex (
		VRPLAbstPage aDataPage,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc
	) {
		//long aItemIndex =
		return this.FindOrderedDataPageItemIndex (
			aDataPage, aKeyValue, aCompareFunc,
			//VRPLSearchMode.kFindExactItemIndex
			false, // find item
			false // direct
		);
		/*/
		if (this.AccurateBinarySearch) {
			// use accurate binary search
			if (aDataPage.IsItemIndexValid (aItemIndex)) {
				// an exact match was found
				// vai indietro all'inizio della sequenza di elementi uguali
				aItemIndex = this.FindDataPageEqItemsSeqBeginIndex
					(aDataPage, aItemOrKeyToSearch, aCompareFunc, aItemIndex);
			}//end if
		}//end if
		return aItemIndex;
		/*/
	}

	// reverse // last

	// FindLastOrderedDataPageItemIndex

	// old: FindDataPageItemIndexReverse

	private long FindLastOrderedDataPageItemIndex (
		VRPLAbstPage aDataPage,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc
	) {
		//long aItemIndex =
		return this.FindOrderedDataPageItemIndex (
			aDataPage, aKeyValue, aCompareFunc,
			//VRPLSearchMode.kFindExactItemIndex
			false, // find item
			true // reverse
		);
		/*/
		if (this.AccurateBinarySearch) {
			// use accurate binary search
			if (aDataPage.IsItemIndexValid (aItemIndex)) {
				// an exact match was found
				// vai avanti alla fine della sequenza di elementi uguali
				aItemIndex = this.FindDataPageEqItemsSeqEndIndex
					(aDataPage, aItemOrKeyToSearch, aCompareFunc, aItemIndex);
			}//end if
		}//end if
		return aItemIndex;
		/*/
	}

//=======================================================================================
// looking for a nearest item

	// direct // first

	// FindFirstNearestOrderedDataPageItemIndex

	// old: FindNearestDataPageItemIndexDirect

	private long FindFirstNearestOrderedDataPageItemIndex (
		VRPLAbstPage aDataPage,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc
	) {
		//long aItemIndex =
		return this.FindOrderedDataPageItemIndex (
			aDataPage, aKeyValue, aCompareFunc,
			//VRPLSearchMode.kFindNearestItemIndexDirect
			true, // find nearest item
			false // direct
		);
		/*/
		if (this.AccurateBinarySearch) {

			// use accurate binary search

			if (aDataPage.IsItemIndexValid (aItemIndex)) {

				// get item
				object aItem = aDataPage.GetItemAt (aItemIndex);

				// compare: aItemOrKeyToSearch vs aItem
				int relCmpVal = this.Compare
					(aCompareFunc, aItemOrKeyToSearch, aItem);

				if (relCmpVal == 0)
					// (aKey == aVect[i])
					// trovato un elemento uguale:
					// vai indietro all'inizio della sequenza di elementi uguali
					aItemIndex = this.FindDataPageEqItemsSeqBeginIndex
						(aDataPage, aItemOrKeyToSearch, aCompareFunc, aItemIndex);
				//end if

			}//end if

		}//end if
		return aItemIndex;
		/*/
	}

	// reverse // last

	// FindLastNearestOrderedDataPageItemIndex

	// old: FindNearestDataPageItemIndexReverse

	private long FindLastNearestOrderedDataPageItemIndex (
		VRPLAbstPage aDataPage,
		object aKeyValue,
		IVRPLItemComparator aCompareFunc
	) {
		//long aItemIndex =
		return this.FindOrderedDataPageItemIndex (
			aDataPage, aKeyValue, aCompareFunc,
			//VRPLSearchMode.kFindNearestItemIndexReverse
			true, // find nearest item
			true // reverse
		);
		/*/
		if (this.AccurateBinarySearch) {

			// use accurate binary search

			if (aDataPage.IsItemIndexValid (aItemIndex)) {

				// get item
				object aItem = aDataPage.GetItemAt (aItemIndex);

				// compare: aItemOrKeyToSearch vs aItem
				int relCmpVal = this.Compare
					(aCompareFunc, aItemOrKeyToSearch, aItem);

				if (relCmpVal == 0)
					// (aKey == aVect[i])
					// trovato un elemento uguale:
					// vai avanti alla fine della sequenza di elementi uguali
					aItemIndex = this.FindDataPageEqItemsSeqEndIndex
						(aDataPage, aItemOrKeyToSearch, aCompareFunc, aItemIndex);
				//end if

			}//end if

		}//end if
		return aItemIndex;
		/*/
	}

#endregion


#endregion

//=======================================================================================



//=======================================================================================
// Binary Search in a refs page
//=======================================================================================

#region Binary Search in a refs page

//=======================================================================================

#region accessing the first / last deep data item from a generic page

	public static object GetPageFirstDeepDataItem (VRPLAbstPage aPage)
	{
		return VRPLAbstPage.GetPageFirstDeepDataItem (aPage); // aPage.GetFirstDeepDataItem();
	}

	public static object GetPageLastDeepDataItem (VRPLAbstPage aPage)
	{
		return VRPLAbstPage.GetPageLastDeepDataItem (aPage); // aPage.GetLastDeepDataItem();
	}

#endregion

//=======================================================================================

//=======================================================================================
// Binary Search in a refs page - Adjusting Raw Search Results
//=======================================================================================

#region Binary Search in a refs page - Adjusting Raw Search Results

	// Binary-Search Correction

	// go backward to the sub-page that ends with [aKeyValue]
	// used in direct searches

	// Find Last SubPage NotEqual Item Index

	// old: FindSubPageEqItemSeqBeginIndex

	private long FindLastSubPageNotEqualItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		long aStartingIndex,
		object aKeyValue, // value or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aSubPageItemIndex = aStartingIndex; // - 1L;
		while (true) {

			if ( ! aLookupPage.IsItemIndexValid (aSubPageItemIndex) ) break;

			// get the sub-page (can be a data or refs page)
			VRPLAbstPage aSubPage = aLookupPage.GetPageRefAt (aSubPageItemIndex);

			// get the LAST deep data item
			object aTestItemLast = GetPageLastDeepDataItem (aSubPage);

			// compare it with aItemOrKeyToSearch
			int relCmpValLast = this.Compare (
				aCompareFunc, aKeyValue, aTestItemLast
			);

			if (relCmpValLast != 0)
				// (aItemOrKeyToSearch != aTestItemLast) !!
				// found a sub-page that do not end with [aKeyValue]
				break;

			//else continue
			-- aSubPageItemIndex; // go bwd

		}//repeat
		return aSubPageItemIndex; // + 1L;
	}

//=======================================================================================

	// go forward to the sub-page that begins with [aKeyValue]
	// used in reverse searches

	// Find First SubPage NotEqual Item Index

	// old: FindSubPageEqItemSeqEndIndex

	private long FindFirstSubPageNotEqualItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		long aStartingIndex,
		object aKeyValue, // value or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aSubPageItemIndex = aStartingIndex; // + 1L;
		while (true) {

			if ( ! aLookupPage.IsItemIndexValid (aSubPageItemIndex) ) break;

			// get the sub-page (can be a data or refs page)
			VRPLAbstPage aSubPage = aLookupPage.GetPageRefAt (aSubPageItemIndex);

			// get the FIRST deep data item
			object aTestItemFirst = GetPageFirstDeepDataItem (aSubPage);

			// compare it with aItemOrKeyToSearch
			int relCmpValFirst = this.Compare (
				aCompareFunc, aKeyValue, aTestItemFirst
			);

			if (relCmpValFirst != 0)
				// (aItemOrKeyToSearch != aTestItemFirst) !!
				// found a sub-page that do not begin with [aKeyValue]
				break;

			//else continue
			++ aSubPageItemIndex; // go fwd

		}//repeat
		return aSubPageItemIndex; // - 1L;
	}

#endregion

//=======================================================================================


//=======================================================================================
// Binary Search in a refs page - Basic Asc/Des Procs
//=======================================================================================

#region Binary Search in a refs page - Basic Asc/Des Procs

	// Ascending Order

	// Find Ascending Ordered SubPage ItemIndex

	// FindAscendingOrderedSubPageItemIndex

	// old: FindSubPageItemIndexAscending

	private long FindAscendingOrderedSubPageItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode
		bool aFindNearestItemMode,
		bool aReverseSearchMode
	) {
		bool aFindItemMode = !aFindNearestItemMode;
		bool aDirectSearchMode = !aReverseSearchMode;

		// indexes
		long loIndex = 0L;
		long hiIndex = aLookupPage.GetItemsCount() - 1L;
		long midIndex = (-1L);
		bool found = false;
		// loop
		while (loIndex <= hiIndex) {

			/*/long/*/ midIndex = (loIndex + hiIndex) / 2L;

			VRPLAbstPage aTestPage = aLookupPage.GetPageRefAt (midIndex);

			object aTestItemFirst = GetPageFirstDeepDataItem (aTestPage);
			object aTestItemLast = GetPageLastDeepDataItem (aTestPage);

			int relCmpValFirst = this.Compare (
				aCompareFunc, aKeyValue, aTestItemFirst
			);
			int relCmpValLast = this.Compare (
				aCompareFunc, aKeyValue, aTestItemLast
			);

			// Ascending order
			if ((relCmpValFirst >= 0) && (relCmpValLast <= 0)) {
				// (aKeyValue >= aTestItemFirst) and
				// (aKeyValue <= aTestItemLast)
				// FOUND!!
				found = true;
				break;
				//return (midIndex);
				// a Sub-Page that could contain aItemOrKeyToSearch
				// was found at (midIndex) !!
			}//end if

			//else
			if (relCmpValFirst < 0)
				// (aKeyValue < aTestItemFirst)
				// search into the lower side
				hiIndex = midIndex - 1L;
				// searchIntoLowerSide = true;
			else // (relCmpValLast > 0)
				// (aKeyValue > aTestItemLast)
				// search into the upper side
				loIndex = midIndex + 1L;
				// searchIntoLowerSide = false;
			//end if

		} // repeat

		long aIndex = (-1L);

		if (found) {

			// found!
			aIndex = midIndex;

		} else {

			// a Sub-Page that could contain aItemOrKeyToSearch was not found!

			if (aFindItemMode) {

				// find item
				if (aDirectSearchMode)
					// direct
					aIndex = aLookupPage.GetItemsCount();
				else
					// aSearchMode == (0) : a Sub-Page was not found
					aIndex = (hiIndex - loIndex); //aIndex = (-1L);
				//end if

			} else {

				// find nearest item

				//if (aSearchMode > (0))
				if (aDirectSearchMode)
					// aSearchMode >= (+1) : find the nearest Sub-Page index in direct mode
					// direct
					aIndex = (loIndex);
				else
				//if (aSearchMode < (0))
					// aSearchMode <= (-1) : find the nearest Sub-Page index in reverse mode
					// reverse
					aIndex = (hiIndex);
				//end if

			}//end if

		}//end if

		if (this.AccurateOrderedSearch) {

			// use accurate binary search

			if (aDirectSearchMode)

				// direct: search bwd <<
				aIndex = this.FindLastSubPageNotEqualItemIndex (
					aLookupPage,
					aIndex - 1L,
					aKeyValue,
					aCompareFunc
				) + 1L;

			else

				// reverse: search fwd >>
				aIndex = this.FindFirstSubPageNotEqualItemIndex (
					aLookupPage,
					aIndex + 1L,
					aKeyValue,
					aCompareFunc
				) - 1L;

			//end if

		}//end if

		return aIndex;
	}

//=======================================================================================

	// Descending Order

	// Find Descending Ordered SubPage ItemIndex

	// FindDescendingOrderedSubPageItemIndex

	// old: FindSubPageItemIndexDescending

	private long FindDescendingOrderedSubPageItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode
		bool aFindNearestItemMode,
		bool aReverseSearchMode
	) {
		bool aFindItemMode = !aFindNearestItemMode;
		bool aDirectSearchMode = !aReverseSearchMode;

		// indexes
		long loIndex = 0L;
		long hiIndex = aLookupPage.GetItemsCount() - 1L;
		long midIndex = (-1L);
		bool found = false;
		// loop
		while (loIndex <= hiIndex) {

			/*/long/*/ midIndex = (loIndex + hiIndex) / 2L;

			VRPLAbstPage aTestPage = aLookupPage.GetPageRefAt (midIndex);

			object aTestItemFirst = GetPageFirstDeepDataItem (aTestPage);
			object aTestItemLast = GetPageLastDeepDataItem (aTestPage);

			int relCmpValFirst = this.Compare (
				aCompareFunc, aKeyValue, aTestItemFirst
			);
			int relCmpValLast = this.Compare (
				aCompareFunc, aKeyValue, aTestItemLast
			);

			// Descending order
			if ((relCmpValFirst <= 0) && (relCmpValLast >= 0)) {
				// (aKeyValue <= aTestItemFirst) and
				// (aKeyValue >= aTestItemLast)
				// FOUND!!
				found = true;
				break;
				//return (midIndex);
				// a Sub-Page that could contain aItemOrKeyToSearch
				// was found at (midIndex) !!
			}//end if

			//else
			if (relCmpValFirst > 0)
				// (aKeyValue > aTestItemFirst)
				// search into the lower side
				hiIndex = midIndex - 1L;
				// searchIntoLowerSide = true;
			else // (relCmpValLast < 0)
				// (aKeyValue < aTestItemLast)
				// search into the upper side
				loIndex = midIndex + 1L;
				// searchIntoLowerSide = false;
			//end if

		} // repeat

		long aIndex = (-1L);

		if (found) {

			// found!
			aIndex = midIndex;

		} else {

			// a Sub-Page that could contain aItemOrKeyToSearch was not found!

			if (aFindItemMode) {

				// find item
				if (aDirectSearchMode)
					// direct
					aIndex = aLookupPage.GetItemsCount();
				else
					// aSearchMode == (0) : a matching Sub-Page was not found
					aIndex = (hiIndex - loIndex); //aIndex = (-1L);
				//end if

			} else {

				// find nearest item

				//if (aSearchMode > (0))
				if (aDirectSearchMode)
					// direct
					// aSearchMode >= (+1) : find the nearest Sub-Page index in direct mode
					aIndex = (loIndex);
				else
				//if (aSearchMode < (0))
					// aSearchMode <= (-1) : find the nearest Sub-Page index in reverse mode
					// reverse
					aIndex = (hiIndex);
				//end if

			}//end if

		}//end if

		if (this.AccurateOrderedSearch) {

			// use accurate binary search

			if (aDirectSearchMode)

				// direct: search bwd <<
				aIndex = this.FindLastSubPageNotEqualItemIndex (
					aLookupPage,
					aIndex - 1L,
					aKeyValue,
					aCompareFunc
				) + 1L;

			else

				// reverse: search fwd >>
				aIndex = this.FindFirstSubPageNotEqualItemIndex (
					aLookupPage,
					aIndex + 1L,
					aKeyValue,
					aCompareFunc
				) - 1L;

			//end if

		}//end if

		return aIndex;
	}


//=======================================================================================

	// Find Ordered SubPage ItemIndex

	// FindOrderedSubPageItemIndex

	// old: FindSubPageItemIndex

	private long FindOrderedSubPageItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc,
		//int aSearchMode
		bool aFindNearestItemMode,
		bool aReverseSearchMode
	) {
		if (this.IsAutoOrdered()) {

			// items are Ordered

			if (this.IsAutoAscendingOrder())
				// items are in Ascending Order
				return this.FindAscendingOrderedSubPageItemIndex (
					aLookupPage, aKeyValue, aCompareFunc,
					//aSearchMode
					aFindNearestItemMode,
					aReverseSearchMode
				);
			else
				// items are in Descending Order
				return this.FindDescendingOrderedSubPageItemIndex (
					aLookupPage, aKeyValue, aCompareFunc,
					//aSearchMode
					aFindNearestItemMode,
					aReverseSearchMode
				);
			//end if

		} else {

			// items are not ordered

			if (aReverseSearchMode)
				// [nearest], reverse
				return (-1L);
			else
				// [nearest], direct
				return aLookupPage.GetItemsCount();
			//end if

		}//end if
	}

//=======================================================================================

	/*/
	// items are un-ordered
	if (aSearchMode > 0)
		// nearest, direct
		return aLookupPage.GetItemsCount();
	else
	if (aSearchMode < 0)
		// nearest, reverse
		return (-1L);
	else
		// exact match
		return (-1L);
	//end if
	/*/

//=======================================================================================

#endregion

//=======================================================================================

//=======================================================================================
// Binary Search in a refs page - Looking for an actual / nearest item match
//=======================================================================================

#region Binary Search in a refs page - Looking for an exact / nearest item match

//=======================================================================================
// looking for an actual Sub-Page index

	// direct // first

	// FindFirstOrderedSubPageItemIndex

	// old: FindSubPageItemIndexDirect

	private long FindFirstOrderedSubPageItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		//long aSubPageItemIndex =
		return this.FindOrderedSubPageItemIndex (
			aLookupPage, aKeyValue, aCompareFunc,
			//VRPLSearchMode.kFindExactItemIndex
			false, // find item
			false // direct
		);
		/*/
		if (this.AccurateBinarySearch) {

			// use accurate binary search

			if (aLookupPage.IsItemIndexValid (aSubPageItemIndex)) {

				// get the sub-page (can be a data or refs page)
				VRPLAbstPage aSubPage = aLookupPage.GetPageRefAt (aSubPageItemIndex);

				// get the First deep data item
				object aTestItemFirst = GetPageFirstDeepDataItem (aSubPage);

				// compare it with aItemOrKeyToSearch
				int relCmpValFirst = this.Compare
					(aCompareFunc, aItemOrKeyToSearch, aTestItemFirst);

				if (relCmpValFirst == 0)
					// (aItemOrKeyToSearch == aTestItemFirst) !!
					// vai indietro alla prima sotto-pagina che finisce con [aItemOrKeyToSearch]
					aSubPageItemIndex = this.FindSubPageEqItemSeqBeginIndex
						(aLookupPage, aItemOrKeyToSearch, aCompareFunc, aSubPageItemIndex);
				//end if

			}//end if

		}//end if
		return aSubPageItemIndex;
		/*/
	}

	// reverse // last

	// FindLastOrderedSubPageItemIndex

	// old: FindSubPageItemIndexReverse

	private long FindLastOrderedSubPageItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		//long aSubPageItemIndex =
		return this.FindOrderedSubPageItemIndex (
			aLookupPage, aKeyValue, aCompareFunc,
			//VRPLSearchMode.kFindExactItemIndex
			false, // find item
			true // reverse
		);
		/*/
		if (this.AccurateBinarySearch) {

			// use accurate binary search

			if (aLookupPage.IsItemIndexValid (aSubPageItemIndex)) {

				// get the sub-page (can be a data or refs page)
				VRPLAbstPage aSubPage = aLookupPage.GetPageRefAt (aSubPageItemIndex);

				// get the Last deep data item
				object aTestItemLast = GetPageLastDeepDataItem (aSubPage);

				// compare it with aItemOrKeyToSearch
				int relCmpValLast = this.Compare
					(aCompareFunc, aItemOrKeyToSearch, aTestItemLast);

				if (relCmpValLast == 0)
					// (aItemOrKeyToSearch == aTestItemLast) !!
					// vai avanti alla prima sotto-pagina che inizia con [aItemOrKeyToSearch]
					aSubPageItemIndex = this.FindSubPageEqItemSeqEndIndex
						(aLookupPage, aItemOrKeyToSearch, aCompareFunc, aSubPageItemIndex);
				//end if

			}//end if

		}//end if
		return aSubPageItemIndex;
		/*/
	}


//=======================================================================================
// looking for a nearest Sub-Page index

	// direct // first

	// FindFirstNearestOrderedSubPageItemIndex

	// old: FindNearestSubPageItemIndexDirect

	private long FindFirstNearestOrderedSubPageItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		//long aSubPageItemIndex =
		return this.FindOrderedSubPageItemIndex (
			aLookupPage, aKeyValue, aCompareFunc,
			//VRPLSearchMode.kFindNearestItemIndexDirect
			true, // find nearest item
			false // direct
		);
		/*/
		if (this.AccurateBinarySearch) {

			// use accurate binary search

			if (aLookupPage.IsItemIndexValid (aSubPageItemIndex)) {

				// get the sub-page (can be a data or refs page)
				VRPLAbstPage aSubPage = aLookupPage.GetPageRefAt (aSubPageItemIndex);

				// get the First deep data item
				object aTestItemFirst = GetPageFirstDeepDataItem (aSubPage);

				// compare it with aItemOrKeyToSearch
				int relCmpValFirst = this.Compare
					(aCompareFunc, aItemOrKeyToSearch, aTestItemFirst);

				if (relCmpValFirst == 0)
					// (aItemOrKeyToSearch == aTestItemFirst) !!
					// vai indietro alla prima sotto-pagina che finisce con [aItemOrKeyToSearch]
					aSubPageItemIndex = this.FindSubPageEqItemSeqBeginIndex
						(aLookupPage, aItemOrKeyToSearch, aCompareFunc, aSubPageItemIndex);
				//end if

			}//end if

		}//end if
		return aSubPageItemIndex;
		/*/
	}

	// reverse // last

	// FindLastNearestOrderedSubPageItemIndex

	// old: FindNearestSubPageItemIndexReverse

	private long FindLastNearestOrderedSubPageItemIndex (
		VRPLAbstPage aLookupPage, // it must be a refs-page
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		//long aSubPageItemIndex =
		return this.FindOrderedSubPageItemIndex (
			aLookupPage, aKeyValue, aCompareFunc,
			//VRPLSearchMode.kFindNearestItemIndexReverse
			true, // find nearest item
			true // reverse
		);
		/*/
		if (this.AccurateBinarySearch) {

			// use accurate binary search

			if (aLookupPage.IsItemIndexValid (aSubPageItemIndex)) {

				// get the sub-page (can be a data or refs page)
				VRPLAbstPage aSubPage = aLookupPage.GetPageRefAt (aSubPageItemIndex);

				// get the Last deep data item
				object aTestItemLast = GetPageLastDeepDataItem (aSubPage);

				// compare it with aItemOrKeyToSearch
				int relCmpValLast = this.Compare
					(aCompareFunc, aItemOrKeyToSearch, aTestItemLast);

				if (relCmpValLast == 0)
					// (aItemOrKeyToSearch == aTestItemLast) !!
					// vai avanti alla prima sotto-pagina che inizia con [aItemOrKeyToSearch]
					aSubPageItemIndex = this.FindSubPageEqItemSeqEndIndex
						(aLookupPage, aItemOrKeyToSearch, aCompareFunc, aSubPageItemIndex);
				//end if

			}//end if

		}//end if
		return aSubPageItemIndex;
		/*/
	}

//=======================================================================================

#endregion

//=======================================================================================


#endregion


//=======================================================================================
// Deep Searching an Auto Ordered List - Deep Searching the whole B+Tree
//=======================================================================================

#region Deep Searching an Auto Ordered List - Deep Searching the whole B+Tree

//=======================================================================================

#region Deep Searching an Auto Ordered List - Deep Searching the whole B+Tree - Deep Search Utils

	// =================
	// Deep Search Utils
	// =================

	private static long SumSubPagesDeepCounters (VRPLAbstPage aLookupPage, long aCount)
	{
		// aLookupPage.IsRefsPage() must be true !!
		long aSum = 0L;
		long aIndex = 0L;
		while (aIndex < aCount) {
			// get the sub-page to count
			VRPLAbstPage aSubPage = aLookupPage.GetPageRefAt (aIndex);

			// accumulate deep-counts
			aSum += aSubPage.GetDeepItemsCount();

			// next
			++ aIndex;
		}//repeat
		return aSum;
	}

#endregion

//=======================================================================================


//=======================================================================================
// Finding the Nearest Item Index
//=======================================================================================

	// DIRECT Deep Search Procs in (ASCending | DEScending) Order

	// DIRECT Deep Search - Putting all together

#region Find First Nearest Ordered Deep Item Index

	/*/ FindFirstNearestOrderedDeepItemIndex

		the following returns the index of the nearest item
		it returns this->ItemsCount()
			if that item cannot be found
	/*/

	// FindFirstNearestOrderedDeepItemIndex

	// old: FindNearestItemIndexDirectRaw

	private long FindFirstNearestOrderedDeepItemIndex (
		ref VRPLAbstPage aLookupPage, ref long aDataPageIndex,
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aGlobalItemIndex = 0L;

		aDataPageIndex = 0L;
		aLookupPage = this.RootPage;

		while (true) {

			if (aLookupPage == null)
				break;
			if (aLookupPage.IsDataPage())
				break;

			// "aLookupPage" must be a refs-page

			long aTotalDeepCount = 0L;

			VRPLAbstPage aSubPageItem = null;

			long aSubPageItemIndex = this.FindFirstNearestOrderedSubPageItemIndex (
				aLookupPage, aKeyValue, aCompareFunc
			);
			// [aSubPageItemIndex] is (aLookupPage->ItemsCount())
			// if a nearest sub-page was not found

			// totalize sub-pages deep-counts until aSubPageItemIndex
			aTotalDeepCount = SumSubPagesDeepCounters (aLookupPage, aSubPageItemIndex);
			//end

			if (aLookupPage.IsItemIndexValid (aSubPageItemIndex))
				// it is a valid sub-page item index: get that sub-page
				aSubPageItem = aLookupPage.GetPageRefAt (aSubPageItemIndex);
			//end if

			aGlobalItemIndex += aTotalDeepCount;

			// go down a level - if aSubPageItem is not null
			aLookupPage = aSubPageItem;

		} // repeat

		if (aLookupPage != null) {
			// it must be a data-page
			aDataPageIndex = this.FindFirstNearestOrderedDataPageItemIndex (
				aLookupPage, aKeyValue, aCompareFunc
			);
			// add the data-page local-index to the global-index
			aGlobalItemIndex += aDataPageIndex;
		}//end if
		return (aGlobalItemIndex);
		// also return (aLookupPage, aDataPageIndex);
	}

#endregion

//=======================================================================================

	// FindFirstNearestOrderedItemIndex

	// old: FindNearestItemIndexDirect

	public long FindFirstNearestOrderedItemIndex (
		ref VRPLAbstPage aDataPage, ref long aLocalIndex,
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aIndex = this.FindFirstNearestOrderedDeepItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue, aCompareFunc
		);
		if (aDataPage == null) {
			aDataPage = this.GetLastDataPage();
			aLocalIndex = 0L;
			if (aDataPage != null)
				aLocalIndex = aDataPage.GetItemsCount();
			//end if
		}//end if
		return aIndex;
	}

//=======================================================================================

	public long FindFirstNearestOrderedItemIndex (
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		VRPLAbstPage aDummyPage = null; long aDummyIndex = (-1L);
		return this.FindFirstNearestOrderedDeepItemIndex (
			ref aDummyPage, ref aDummyIndex,
			aKeyValue, aCompareFunc
		);
	}

//=======================================================================================
// Finding the Nearest Item Index
//=======================================================================================

	// REVERSE Deep Search Procs in (ASCending / DEScending) Order

	// REVERSE Deep Search - Putting all together

#region Find Last Nearest Ordered Deep Item Index

	/*/ FindLastNearestOrderedDeepItemIndex

		the following returns the index of the nearest item in the paged-list
		it returns (-1)
			if that item cannot be found
	/*/

	// FindLastNearestOrderedDeepItemIndex

	// old: FindNearestItemIndexReverseRaw

	private long FindLastNearestOrderedDeepItemIndex (
		ref VRPLAbstPage aLookupPage, ref long aDataPageIndex,
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aGlobalItemIndex = 0L;

		aLookupPage = this.RootPage;
		aDataPageIndex = (-1L);

		while (true) {

			if (aLookupPage == null)
				break;
			if (aLookupPage.IsDataPage())
				break;

			// "aLookupPage" must be a refs-page

			long aTotalDeepCount = 0L;

			VRPLAbstPage aSubPageItem = null;

			long aSubPageItemIndex = this.FindLastNearestOrderedSubPageItemIndex (
				aLookupPage, aKeyValue, aCompareFunc
			);
			// [aSubPageItemIndex] is (-1) if a nearest sub-page was not found

			// totalize sub-pages deep-counts until aSubPageItemIndex
			aTotalDeepCount = SumSubPagesDeepCounters (aLookupPage, aSubPageItemIndex);
			//end

			if (aLookupPage.IsItemIndexValid (aSubPageItemIndex))
				// it is a valid sub-page item index: get that sub-page
				aSubPageItem = aLookupPage.GetPageRefAt (aSubPageItemIndex);
			//end if

			aGlobalItemIndex += aTotalDeepCount;

			// go down a level - if aLookupPage is not null
			aLookupPage = aSubPageItem;

		} // repeat

		if (aLookupPage != null) {
			// it must be a data-page
			aDataPageIndex = this.FindLastNearestOrderedDataPageItemIndex
				(aLookupPage, aKeyValue, aCompareFunc);
			// add the data-page local-index to the global-index
			aGlobalItemIndex += aDataPageIndex;
		} else {
			// a nearest item cannot be found in reverse mode
			aGlobalItemIndex = (-1L);
		}//end if
		return (aGlobalItemIndex);
		// also return (aLookupPage, aDataPageIndex);
	}

#endregion

//=======================================================================================

	// FindLastNearestOrderedItemIndex

	// old: FindNearestItemIndexReverse

	public long FindLastNearestOrderedItemIndex (
		ref VRPLAbstPage aDataPage, ref long aLocalIndex,
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aIndex = this.FindLastNearestOrderedDeepItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue, aCompareFunc
		);
		if (aDataPage == null) {
			aDataPage = this.GetFirstDataPage();
			aLocalIndex = (-1L);
		}
		return aIndex;
	}

//=======================================================================================

	public long FindLastNearestOrderedItemIndex (
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		VRPLAbstPage aDummyPage = null; long aDummyIndex = (-1L);
		return this.FindLastNearestOrderedDeepItemIndex (
			ref aDummyPage, ref aDummyIndex,
			aKeyValue, aCompareFunc
		);
	}


//=======================================================================================


//=======================================================================================
// Finding the Actual Item Index
//=======================================================================================

//=======================================================================================
// direct deep search
//=======================================================================================

	// Finding the Actual Item Index in direct mode - Putting all together

#region Find First Ordered Deep Item Index

	// FindFirstOrderedDeepItemIndex

	// old: FindItemIndexDirectRaw

	private long FindFirstOrderedDeepItemIndex (
		ref VRPLAbstPage aLookupPage, ref long aDataPageIndex,
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aGlobalItemIndex = 0L;

		aLookupPage = this.RootPage;
		aDataPageIndex = (-1L);

		while (true) {

			if (aLookupPage == null)
				break;
			//end if
			if (aLookupPage.IsDataPage())
				break;
			//end if

			// "aLookupPage" must be a refs-page

			long aTotalDeepCount = 0L;

			VRPLAbstPage aSubPageItem = null;

			long aSubPageItemIndex = this.FindFirstOrderedSubPageItemIndex (
				aLookupPage, aKeyValue, aCompareFunc
			);
			// [aSubPageItemIndex] is (-1) if a sub-page containing [aItemOrKeyToSearch] was not found

			// totalize sub-pages deep-counts until aSubPageItemIndex
			aTotalDeepCount = SumSubPagesDeepCounters (aLookupPage, aSubPageItemIndex);
			//end

			if (aLookupPage.IsItemIndexValid (aSubPageItemIndex))
				// it is a valid sub-page item index: get that sub-page
				aSubPageItem = aLookupPage.GetPageRefAt (aSubPageItemIndex);
			//end if

			aGlobalItemIndex += aTotalDeepCount;

			aLookupPage = aSubPageItem;

		} // repeat

		if (aLookupPage != null) {
			// it must be a data-page
			aDataPageIndex = this.FindFirstOrderedDataPageItemIndex (
				aLookupPage, aKeyValue, aCompareFunc
			);
			//if (aDataPageIndex >= 0L)
			if ( aLookupPage.IsItemIndexValid (aDataPageIndex) )
				// OK! found!
				// add the data-page local-index to the global-index
				aGlobalItemIndex += aDataPageIndex;
			else {
				// not found
				// invalid local index: aDataPageIndex is (-1) !!
				if (aLookupPage.IsLastPage())
					// it is the last data-page : keep it !!
					aDataPageIndex = aLookupPage.GetItemsCount();
				else {
					// no page, no index
					aLookupPage = null;
					aDataPageIndex = 0L;
				}
				aGlobalItemIndex = this.ItemsCount; // not found!
			}//end if
			// there was a data-page
		} else {
			// "aLookupPage" is null
			aDataPageIndex = 0L; // this value should be discarded
			aGlobalItemIndex = this.ItemsCount; // not found!
			// no data-page
		}//end if

		return (aGlobalItemIndex);
		// also return (aLookupPage, aDataPageIndex);
	}

#endregion

//=======================================================================================

	/*/ the following in the case of unsuccessful search
		ALWAYS returns
			- the last data-page
			- its last valid local-index + 1
	/*/

	// FindFirstOrderedItemIndex

	// old: FindItemIndexDirect

	public long FindFirstOrderedItemIndex (
		ref VRPLAbstPage aDataPage, ref long aLocalIndex,
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aIndex = this.FindFirstOrderedDeepItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue, aCompareFunc
		);
		if (aDataPage == null) {
			aDataPage = this.GetLastDataPage();
			aLocalIndex = 0L;
			if (aDataPage != null)
				aLocalIndex = aDataPage.GetItemsCount();
			//end if
		}//end if
		return aIndex;
	}

//=======================================================================================

	public long FindFirstOrderedItemIndex (
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		VRPLAbstPage aDummyPage = null; long aDummyIndex = (-1L);
		return this.FindFirstOrderedDeepItemIndex (
			ref aDummyPage, ref aDummyIndex,
			aKeyValue, aCompareFunc
		);
	}


//=======================================================================================
// reverse deep search
//=======================================================================================

	// Finding the Actual Item Index in reverse mode - Putting all together

#region Find Last Ordered Deep Item Index

	// FindLastOrderedDeepItemIndex

	// old: FindItemIndexReverseRaw

	private long FindLastOrderedDeepItemIndex (
		ref VRPLAbstPage aLookupPage, ref long aDataPageIndex,
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aGlobalItemIndex = 0L;

		aLookupPage = this.RootPage;
		aDataPageIndex = (-1L);

		while (true) {

			if (aLookupPage == null)
				break;
			//end if
			if (aLookupPage.IsDataPage())
				break;
			//end if

			// "aLookupPage" must be a refs-page

			long aTotalDeepCount = 0L;
			VRPLAbstPage aSubPageItem = null;

			long aSubPageItemIndex = this.FindLastOrderedSubPageItemIndex (
				aLookupPage, aKeyValue, aCompareFunc
			);
			// [aSubPageItemIndex] is (-1) if a sub-page containing [aItemOrKeyToSearch] was not found

			// totalize sub-pages deep-counts until aSubPageItemIndex
			aTotalDeepCount = SumSubPagesDeepCounters (aLookupPage, aSubPageItemIndex);
			//end

			if (aLookupPage.IsItemIndexValid (aSubPageItemIndex))
				// it is a valid sub-page item index: get that sub-page
				aSubPageItem = aLookupPage.GetPageRefAt (aSubPageItemIndex);
			//end if

			aGlobalItemIndex += aTotalDeepCount;

			aLookupPage = aSubPageItem;

		} // repeat

		if (aLookupPage != null) {
			// it must be a data-page
			aDataPageIndex = this.FindLastOrderedDataPageItemIndex (
				aLookupPage, aKeyValue, aCompareFunc
			);
			//if (aDataPageIndex >= 0L)
			if ( aLookupPage.IsItemIndexValid (aDataPageIndex) )
				// OK! found!
				// add the data-page local-index to the global-index
				aGlobalItemIndex += aDataPageIndex;
			else {
				// NOT found
				// aDataPageIndex is (-1) !!
				if (aLookupPage.IsFirstPage())
					{;} // keep it: it was the first data-page
				else {
					// no page, no index
					aLookupPage = null;
				}
				aGlobalItemIndex = (-1L); // not found!
			}//end if
			// there was a data-page
		} else
			// "aLookupPage" is null
			// aDataPageIndex is (-1) !!
			aGlobalItemIndex = (-1L); // not found!
			// no data-page
		//end if

		return (aGlobalItemIndex);
		// also return (aLookupPage, aDataPageIndex);
	}

#endregion

//=======================================================================================

	/*/ the following in the case of unsuccessful search
		ALWAYS returns
			- the first data-page
			- its first valid local-index - 1 : (-1) !!
	/*/

	// FindLastOrderedItemIndex

	// old: FindItemIndexReverse

	public long FindLastOrderedItemIndex (
		ref VRPLAbstPage aDataPage, ref long aLocalIndex,
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		long aIndex = this.FindLastOrderedDeepItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue, aCompareFunc
		);
		if (aDataPage == null) {
			aDataPage = this.GetFirstDataPage();
			aLocalIndex = (-1L);
		}
		return aIndex;
	}

//=======================================================================================

	public long FindLastOrderedItemIndex (
		object aKeyValue, // item or key to search
		IVRPLItemComparator aCompareFunc
	) {
		VRPLAbstPage aDummyPage = null; long aDummyIndex = (-1L);
		return this.FindLastOrderedDeepItemIndex (
			ref aDummyPage, ref aDummyIndex,
			aKeyValue, aCompareFunc
		);
	}


//=======================================================================================

#endregion

//=======================================================================================


#endregion

//=======================================================================================




//=======================================================================================
// High-Level User Procs
//=======================================================================================

#region High-Level User Procs

//=======================================================================================
// Inserting Items into the list
//=======================================================================================

#region Inserting Items into the list

//=======================================================================================
// to Insert an Item at a given Index

#region to Insert an Item at a given Index

	/*/ InsertItemAtIndex (index, value)

		place your comments here ...
	/*/


	/*/
		if (this.UseFastAccess) {
			// use fast access
			this.FastInsert (aGlobalIndex, aItemData);
			// done!
			return;
		}//end if
	/*/
	// else normal access


	public void InsertItemAtIndex (long aGlobalIndex, object aItemData)
	{
		// cannot insert anywhere if this list is ordered !!
		if (this.IsAutoOrdered())
		{
			this.CheckInsertOrderedItemAtIndex (aGlobalIndex, aItemData);
			// ok!
		}

		VRPLAbstPage aDataPageRef = null; // NullPageRef
		long aDataPageIndex = (-1L);
		// get (data-page-ref, data-page-index) from global-index
		this.AccessDataPageLocalIndexPairFromGlobalIndex (
			ref aDataPageRef, ref aDataPageIndex,
			aGlobalIndex
		);

		if ( ! IsPageInsertIndexValid (aDataPageRef, aDataPageIndex) )
			// raise invalid insert index!
			throw new VRPLInvalidInsertIndexException (this, aGlobalIndex, this.ItemsCount);
			// failure!
		//end if
		// ok!

		// insert!
		this.InsertIntoDataPageExt
			(ref aDataPageRef, ref aDataPageIndex, aItemData, aGlobalIndex);
		// success!

		// list changed!
		this.RaiseListChangedEvent();

		// done!
	}

	// insert macros

	// insert item first

	public void InsertItemFirst (object aItemData)
	{
		this.InsertItemAtIndex (0L, aItemData);
	}

	// insert item last

	public void InsertItemLast (object aItemData)
	{
		this.InsertItemAtIndex (this.ItemsCount, aItemData);
	}

//=======================================================================================

	public void Insert (long aGlobalIndex, object aItemData)
	{
		this.InsertItemAtIndex (aGlobalIndex, aItemData);
	}

	public void AddItem (object aItemData)
	{
		this.InsertItemAtIndex (this.Size, aItemData);
	}


#endregion

//=======================================================================================
// Inserting an item in an auto ordered list

#region Inserting an item in an auto ordered list

	/*/
		InsertOrderedItem (aItemData, wantAddAsFirst)

		insert (aItemData) in an auto-ordered list

		the (wantAddAsFirst) parameter makes sense only
		if the list may have duplicate items

		if (wantAddAsFirst is true) then
			the new item becomes the first of a serie of duplicates
		if (wantAddAsFirst is false) then
			the new item becomes the last of a serie of duplicates
	/*/

	public long InsertOrderedItem (object aItemData, bool wantAddAsFirst)
	{
		if ( ! this.IsAutoOrdered() )
			// the paged-list is un-ordered: cannot make an ordered insertion !
			throw new VRPLUnorderedListException (this);
		//end if
		// ok!

		long aGlobalIndex = (-1L);
		// (data-page, local-index) pair
		VRPLAbstPage aDataPageRef = null; //NullPageRef
		long aDataPageIndex = -1L;

		// get (data-page-ref, data-page-index) & global-index from item-key-value
		if (wantAddAsFirst) {
			// use a DIRECT Search
			aGlobalIndex = this.FindFirstNearestOrderedItemIndex (
				ref aDataPageRef, ref aDataPageIndex,
				aItemData,
				this.ItemToItemComparator //this->CompareItemWithItemFunc()
			);
		} 
		else 
		{
			// use a REVERSE Search
			aGlobalIndex = this.FindLastNearestOrderedItemIndex (
				ref aDataPageRef, ref aDataPageIndex,
				aItemData,
				this.ItemToItemComparator //this->CompareItemWithItemFunc()
			);
			// make aDataPageIndex a valid insert index
			// aDataPageIndex += (1L); // do it after
		}//end if

		// check for duplicate items
		if ( ! this.IsAllowDuplicateItems() ) {
			// duplicates are not allowed:
			// check for duplicates !!

			if (aDataPageRef != null)
				if (aDataPageRef.IsItemIndexValid (aDataPageIndex)) {
					// it is a valid page-local-item-index: get the reference to the data-item
					//void * storedDataItem = this->DataPageItem (aDataPageRef, aDataPageIndex);
					object storedDataItem = aDataPageRef.GetItemAt (aDataPageIndex);
					// compare item-to-insert vs stored-item
					int cmpResult = this.Compare (
						this.ItemToItemComparator, //this->CompareItemWithItemFunc(),
						aItemData, storedDataItem
					);
					if (cmpResult == 0) {
						// a duplicate was found at (aGlobalIndex) !!
						if ( this.IsDoNotAllowDuplicateItems() )
							// duplicate items not allowed !!
							// Cannot Insert <<Duplicate Items Not Allowed>>
							throw new VRPListDoNotAllowDuplicatesException (this, aGlobalIndex, aItemData);
						// fail
						if ( this.IsIgnoreDuplicateItems() )
							// always true!
							// duplicates are ignored ...
							return aGlobalIndex;
						// exit
						// else continue ...
						// duplicates are allowed
						//end
					}//end if
					// ok!
				}//end if
			//end if

		}//end if
		// ok!

		if (!wantAddAsFirst) {
			// make aDataPageIndex a valid insert index
			aDataPageIndex += (1L);
			aGlobalIndex += (1L);
		}//end if

		// check for a valid insert index
		if ( ! IsPageInsertIndexValid (aDataPageRef, aDataPageIndex) )
			// should never happen
			throw new VRPLInvalidInsertIndexException (this, aGlobalIndex, this.ItemsCount);
		//end if

		// insert!
		this.InsertIntoDataPageExt
			(ref aDataPageRef, ref aDataPageIndex, aItemData, aGlobalIndex);
		// success!

		// list changed!
		this.RaiseListChangedEvent();

		return aGlobalIndex;
	}


	// insert ordered item macros

	// first

	public long InsertOrderedItemFirst (object aItemData)
	{
		return this.InsertOrderedItem (aItemData, true);
	}

	// last

	public long InsertOrderedItemLast (object aItemData)
	{
		return this.InsertOrderedItem (aItemData, false);
	}

//=======================================================================================

	public long InsertOrdered (object aItemData, bool wantAddAsFirst)
	{
		return this.InsertOrderedItem (aItemData, wantAddAsFirst);
	}

	public long InsertOrderedFirst (object aItemData)
	{
		return this.InsertOrderedItem (aItemData, true);
	}

	public long InsertOrderedLast (object aItemData)
	{
		return this.InsertOrderedItem (aItemData, false);
	}

	// to add an ordered item as last

	public long AddOrdered (object aItemData)
	{
		return this.InsertOrderedItem (aItemData, false);
	}


#endregion


//=======================================================================================
// generic add item

#region generic add item

	// last

	public long GenericAddItemLast (object aItemData)
	{
		if (this.IsAutoOrdered())
			return this.InsertOrderedItemLast (aItemData);
		else 
		{
			this.InsertItemLast (aItemData);
			return ( this.ItemsCount - 1L );
		}
	}

	// first

	public long GenericAddItemFirst (object aItemData)
	{
		if (this.IsAutoOrdered())
			return this.InsertOrderedItemFirst (aItemData);
		else 
		{
			this.InsertItemFirst (aItemData);
			return (0L);
		}
	}

	// GenericAddItem (first / last)

	public long GenericAddItem (object aItemData, bool wantAddAsFirst)
	{
		if (wantAddAsFirst)
			return this.GenericAddItemFirst (aItemData);
		else
			return this.GenericAddItemLast (aItemData);
		//end if
	}

	// GenericAddItem (last)

	public long GenericAddItem (object aItemData)
	{
		return this.GenericAddItem (aItemData, false);
	}

#endregion


#endregion

//=======================================================================================
// Deleting Items from the list
//=======================================================================================

#region Deleting Items from the list

//=======================================================================================
// to Delete an Item at a given index

#region to Delete an Item at a given index

	// delete

	/*/
		if (this.UseFastAccess)
			// use fast access
			return this.FastDelete (aGlobalIndex);
		//end if
	/*/
	// else normal access


	public object DeleteItemAtIndex (long aGlobalIndex)
	{
		VRPLAbstPage aDataPageRef = null; // NullPageRef
		long aDataPageIndex = (-1L);
		// get (data-page-ref, data-page-index) from global-index
		this.AccessDataPageLocalIndexPairFromGlobalIndex (
			ref aDataPageRef, ref aDataPageIndex,
			aGlobalIndex
		);

		// range checking ...
		if (aDataPageRef == null)
			// the B+Tree should be empty
			// invalid delete index
			throw new VRPLInvalidItemIndexException (this, aGlobalIndex, this.ItemsCount);

		if ( ! aDataPageRef.IsItemIndexValid (aDataPageIndex) )
			// should never happen
			// invalid delete index
			throw new VRPLInvalidItemIndexException (this, aGlobalIndex, this.ItemsCount);
		// ok!

		// get the old item to returned back
		object aOldDataItem = aDataPageRef.GetItemAt (aDataPageIndex);

		// delete!
		this.RemoveFromDataPageExt
			(ref aDataPageRef, ref aDataPageIndex, aGlobalIndex);
		// success!

		// raise list changed!
		this.RaiseListChangedEvent();

		// done!
		return aOldDataItem;
	}


	// alias

	public object Delete (long aGlobalIndex)
	{
		return this.DeleteItemAtIndex (aGlobalIndex);
	}


#endregion

//=======================================================================================
// to delete many items at once at a given index

#region to delete many items at once at a given index

	// delete range

	/*/ // test
		if (this.UseFastAccess) {
			// use fast access
			this.FastDeleteRange (aGlobalIndex, aItemsCount);
			// done
			return;
		}//end if
	/*/
	// else use normal access


	public void DeleteItemsAtIndex (long aGlobalIndex, long aItemsCount)
	{
		//long aDelCount = (0L);

		VRPLAbstPage aDataPageRef = null; // NullPageRef
		long aDataPageIndex = (-1L);
		// get (data-page-ref, data-page-index) from global-index
		this.AccessDataPageLocalIndexPairFromGlobalIndex (
			ref aDataPageRef, ref aDataPageIndex,
			aGlobalIndex
		);
		// delete loop
		while (aItemsCount > 0L)
		{
			if (aDataPageRef == null)
				// the B+Tree should be empty
				// invalid delete index
				throw new VRPLInvalidItemIndexException (this, aGlobalIndex, this.ItemsCount);
			if ( ! aDataPageRef.IsItemIndexValid (aDataPageIndex) )
				// should never happen
				// invalid delete index
				throw new VRPLInvalidItemIndexException (this, aGlobalIndex, this.ItemsCount); //return TVRPLTypes::kPLDelInvalidDeleteIndexErr;

			// delete next item!
			this.RemoveFromDataPageExt
				(ref aDataPageRef, ref aDataPageIndex, aGlobalIndex);
			// success!

			// raise list changed event!
			this.RaiseListChangedEvent();

			//++ aDelCount;

			-- aItemsCount;
		}//loop

		// done!
		return; // (aDelCount);
	}

//=======================================================================================

	public void DeleteItemsRange (long aRangeIndex, long aRangeCount)
	{
		// exit if nothing to delete
		// if (aRangeCount <= 0L) return;
		// items range check
		// this.CheckValidItemsRange (aRangeIndex, aRangeCount);
		// insert range check
		this.CheckValidInsertRange (aRangeIndex, aRangeCount);
		// delete items range
		this.DeleteItemsAtIndex (aRangeIndex, aRangeCount);
	}

	// alias

	public void DeleteRange (long aRangeIndex, long aRangeCount)
	{
		this.DeleteItemsRange (aRangeIndex, aRangeCount);
	}

//=======================================================================================


#endregion

//=======================================================================================
// to clear the whole list

#region to clear the whole list

	public void DeleteAllItems()
	{
		//if ( ! this.IsEmpty() )
		this.DeleteItemsAtIndex (0L, this.ItemsCount);
		//end if
	}

	public void Clear()
	{
		//this.DeleteItemsAtIndex (0L, this.ItemsCount);
		this.DeleteAllItems();
	}

#endregion


#endregion


//=======================================================================================
// Relocating Items from a pos to another
//=======================================================================================

#region Relocating Items from a pos to another

//=======================================================================================
// to relocate a single item
//=======================================================================================

#region to relocate a single item

//=======================================================================================

#region to relocate an item from index to index

	// to relocate an item from index to index

	// can we relocate an item from index to index ?

	public bool CanRelocateItems()
	{
		return this.IsUnordered();
	}

	public bool CanRelocateItem (long aOldIndex)
	{
		return
			( this.CanRelocateItems() ) &&
			this.IsItemIndexValid (aOldIndex) //&&
			//(this.ItemsCount >= 2L)
		;
	}

	public bool CanRelocateItem (long aNewIndex, long aOldIndex)
	{
		return
			( this.CanRelocateItems() ) &&
			(
				this.IsItemIndexValid (aOldIndex) &&
				this.IsItemIndexValid (aNewIndex)
			) //&&
			//(this.ItemsCount >= 2L)
		;
	}

	public void RelocateItem (long aNewIndex, long aOldIndex)
	{
		// range checking ...
		this.CheckValidItemIndex (aOldIndex);
		// ok!
		this.CheckValidItemIndex (aNewIndex);
		// ok!

		// cannot insert anywhere if this list is ordered !!
		this.CheckUnorderedList();
		//end if

		// get the data-item to be relocated -- also performs range checking
		object aDataItem = this.GetItemAtIndex (aOldIndex);

		if (aOldIndex > aNewIndex) {
			// move up
			this.InsertItemAtIndex (aNewIndex, aDataItem);
			// ok!
			this.DeleteItemAtIndex (aOldIndex + 1L);
		}
		else
		if (aOldIndex < aNewIndex) {
			// move down
			this.InsertItemAtIndex (aNewIndex + 1L, aDataItem);
			// ok!
			this.DeleteItemAtIndex (aOldIndex);
		}
		else {
			// do nothing
			;
		}

		// done!
		return;
	}

#endregion

//=======================================================================================

#region to cycle an item up/down

	// can we cycle an item up/down ?

	public bool CanCycleItemUp (long aIndex)
	{
		return this.CanRelocateItem (aIndex);
			//this.IsItemIndexValid (aIndex) && (this.ItemsCount >= 2L)
		//;
	}

	public bool CanCycleItemDown (long aIndex)
	{
		return this.CanRelocateItem (aIndex);
			//this.IsItemIndexValid (aIndex) && (this.ItemsCount >= 2L)
		//;
	}

	// to cycle an item up

	public long CycleItemUp (long aIndex)
	{
		// get the object to be relocated - just to perform some range checking
		//object aDataItem = this.GetItemAtIndex (aIndex);
		this.CheckValidItemIndex (aIndex);
		// ok!
		//if (this.ItemsCount >= 2L) {
			long aNewIndex = 0L;
			//int retval;
			if (aIndex > 0L)
				aNewIndex = aIndex - 1L;
			else
				// assert: (aIndex == 0) !!
				aNewIndex = this.ItemsCount - 1L;
			//end if
			// relocate!
			this.RelocateItem (aNewIndex, aIndex);
			// ok!
			// the item was relocated!
			return aNewIndex;
		//}//end if
		// else ...
		//return aIndex;
	}

	// to cycle an item down

	public long CycleItemDown (long aIndex)
	{
		// get the object to be relocated - just to perform some range checking
		//object aDataItem = this.GetItemAtIndex (aIndex);
		this.CheckValidItemIndex (aIndex);
		// ok!
		//if (this.ItemsCount >= 2L) {
			long lastItemIndex = (this.ItemsCount - 1L);
			long aNewIndex = 0L;
			if (aIndex < lastItemIndex)
				aNewIndex = aIndex + 1L;
			else
				// assert: (aIndex == lastItemIndex)
				aNewIndex = (0L);
			//end if
			// relocate!
			this.RelocateItem (aNewIndex, aIndex);
			// ok!
			// the item was relocated!
			return aNewIndex;
		//}//end if
		// else ...
		//return aIndex;
	}

#endregion

//=======================================================================================

#region to move an item up/down

	// can we move an item up/down ?

	public bool CanMoveItemUp (long aIndex)
	{
		return this.CanCycleItemUp (aIndex) && (aIndex > 0L);
	}
	public bool CanMoveItemDown (long aIndex)
	{
		return this.CanCycleItemDown (aIndex) && (aIndex < (this.ItemsCount - 1L));
	}

	// to move an item up

	public long MoveItemUp (long aIndex)
	{
		// get the object to be relocated - just to perform some range checking
		//object aDataItem = this.GetItemAtIndex (aIndex);
		this.CheckValidItemIndex (aIndex);
		// ok!
		// do NOT Move if it is the first item
		if (aIndex <= 0L) return aIndex;
		// do NOT Cycle items
		return this.CycleItemUp (aIndex);
	}

	// to move an item down

	public long MoveItemDown (long aIndex)
	{
		// get the object to be relocated - just to perform some range checking
		//object aDataItem = this.GetItemAtIndex (aIndex);
		this.CheckValidItemIndex (aIndex);
		// ok!
		// do NOT Move if it is the last item
		if (aIndex >= (this.ItemsCount - 1L)) return aIndex;
		// do NOT Cycle items
		return this.CycleItemDown (aIndex);
	}

#endregion

//=======================================================================================

#region to bubble an item

	// to bubble cycle an item

	public long BubbleCycleItem (long aIndex, long aOffset)
	{
		// range check
		this.CheckValidItemIndex (aIndex);

		// get the list items count
		long aTotalItemsCount = this.ItemsCount;

		// compute the destination index
		long aNewIndex = aIndex + aOffset;
		// make it a valid index
		aNewIndex = aNewIndex % aTotalItemsCount;
		// make "aDstIndex" a valid item index
		if (aNewIndex < 0L)
			aNewIndex = aTotalItemsCount + aNewIndex;
		//end if

		// relocate item
		this.RelocateItem (aNewIndex, aIndex);
		// ok!
		return aNewIndex;
	}

	// to bubble move an item

	public long BubbleMoveItem (long aIndex, long aOffset)
	{
		// range check
		this.CheckValidItemIndex (aIndex);
		// clip offset
		long aClippedOffset = aOffset;
		if (aOffset < 0L)
		{
			long aMinUpOffset = - aIndex;
			if (aOffset < aMinUpOffset)
				aClippedOffset = aMinUpOffset;
			//end if
		}
		else
		if (aOffset > 0L)
		{
			long aLastItemIndex = this.ItemsCount - 1L;
			long aMaxDownOffset = (aLastItemIndex - aIndex);
			if (aOffset > aMaxDownOffset)
				aClippedOffset = aMaxDownOffset;
			//end if
		}
		// bubble item!
		return this.BubbleCycleItem (aIndex, aClippedOffset);
	}

#endregion

//=======================================================================================

#region to bubble an item inside a given range

	// to bubble cycle an item inside a given range

	public long BubbleCycleItem (
		long aRangeIndex, long aRangeCount,
		long aIndex,
		long aOffset
	) {
		// items range check
		this.CheckValidItemsRange (aRangeIndex, aRangeCount);

		// item index range check
		VRLongRangeCheck.CheckValidItemIndex (aIndex, aRangeIndex, aRangeCount);

		// compute the destination index
		long aNewIndex = aIndex + aOffset;

		// make aNewIndex a relative one
		long aRelNewIndex = aNewIndex - aRangeIndex;

		// make it a valid index
		aRelNewIndex = aRelNewIndex % aRangeCount;
		if (aRelNewIndex < 0L)
			aRelNewIndex = aRangeCount + aRelNewIndex;
		//end if

		// make aNewIndex an absolute one
		aNewIndex = aRelNewIndex + aRangeIndex;

		// relocate item
		this.RelocateItem (aNewIndex, aIndex);

		// ok!
		return aNewIndex;
	}

	// to bubble move an item inside a given range

	public long BubbleMoveItem (
		long aRangeIndex, long aRangeCount,
		long aIndex,
		long aOffset
	) {
		// clip offset
		long aClippedOffset = aOffset;
		if (aOffset < 0L)
		{
			// up
			long aMinUpOffset = - ( aIndex - aRangeIndex );
			if (aOffset < aMinUpOffset)
				aClippedOffset = aMinUpOffset;
			//end if
		}
		else
		if (aOffset > 0L)
		{
			// down
			long aLastRangeItemIndex = aRangeIndex + aRangeCount - 1L;
			long aMaxDownOffset = (aLastRangeItemIndex - aIndex);
			if (aOffset > aMaxDownOffset)
				aClippedOffset = aMaxDownOffset;
			//end if
		}
		// bubble item!
		return this.BubbleCycleItem (aRangeIndex, aRangeCount, aIndex, aClippedOffset);
	}

#region to bubble an item inside a given range rel

	/*/
		here the source index is relative to the given items range
		the returned destination index is also relative
	/*/

	// to bubble cycle an item inside a given range (rel)

	public long BubbleCycleItemRel (
		long aRangeIndex, long aRangeCount,
		long aRelSrcIndex,
		long aOffset
	) {
		long aAbsSrcIndex = aRelSrcIndex + aRangeIndex;
		// bubble cycle!
		long aAbsDstIndex = this.BubbleCycleItem (
			aRangeIndex, aRangeCount,
			aAbsSrcIndex, aOffset
		);
		long aRelDstIndex = aAbsDstIndex - aRangeIndex;
		return aRelDstIndex;
	}

	// to bubble move an item inside a given range (rel)

	public long BubbleMoveItemRel (
		long aRangeIndex, long aRangeCount,
		long aRelSrcIndex,
		long aOffset
	) {
		long aAbsSrcIndex = aRelSrcIndex + aRangeIndex;
		// bubble cycle!
		long aAbsDstIndex = this.BubbleMoveItem (
			aRangeIndex, aRangeCount,
			aAbsSrcIndex, aOffset
		);
		long aRelDstIndex = aAbsDstIndex - aRangeIndex;
		return aRelDstIndex;
	}

#endregion


#endregion

//=======================================================================================

#endregion

//=======================================================================================

//=======================================================================================
// to relocate a range of items
//=======================================================================================

#region to relocate a range of items

#region to relocate a range of items from a old index to a new index

	// to relocate a range of items

	public bool CanRelocateItems (long aIndex, long aCount)
	{
		return
			// check for an auto-ordered list
			this.CanRelocateItems() &&
			// check range
			this.IsValidInsertRange (aIndex, aCount) // IsValidItemsRange
		;
	}

	public bool CanRelocateItems (long aDstIndex, long aSrcIndex, long aItemsCount)
	{
		return
			// check for an auto-ordered list
			(this.CanRelocateItems()) &&
			// check range
			this.IsValidInsertRange (aSrcIndex, aItemsCount) && // IsValidItemsRange
			// check dest index
			this.IsItemIndexValid (aDstIndex)
		;
	}

	// to relocate a range of items

	public void RelocateItems (long aDstIndex, long aSrcIndex, long aItemsCount)
	{
		// check dest
		this.CheckValidItemIndex (aDstIndex);

		// check source range
		this.CheckValidInsertRange (aSrcIndex, aItemsCount); // CheckValidItemsRange
		// ok!
		if (aItemsCount <= 0L) return; // exit if nothing to relocate !!

		// check for an unordered list
		this.CheckUnorderedList();
		// ok!

		long aLastSrcIndex = (aSrcIndex + aItemsCount - 1L);

		// perform relocation
		if (aDstIndex < aSrcIndex) {
			// relocate up
			long aInsertedCount = 0L;
			try {
				long aCount = aItemsCount;
				long aIndex = aSrcIndex;
				while (aCount > 0L) {
					// get source item
					long aSourceItemIndex = aIndex + aInsertedCount;
					object aItem = this [aSourceItemIndex];
					// insert it to dest index
					long aInsIndex = aDstIndex + aInsertedCount;
					this.InsertItemAtIndex (aInsIndex, aItem);
					// next
					++ aInsertedCount;
					++ aIndex;
					-- aCount;
				}
			}
			catch (Exception) {
				// rollback ...
				this.DeleteItemsAtIndex (aDstIndex, aInsertedCount);
				throw; // raise again
			}
			// ok!
			// delete source items
			long aDelIndex = aSrcIndex + aInsertedCount;
			this.DeleteItemsAtIndex (aDelIndex, aInsertedCount);
			// ok!
		}
		else
		if (aDstIndex > aLastSrcIndex) {
			// relocate down
			long aInsertedCount = 0L;
			try {
				long aCount = aItemsCount;
				long aIndex = aSrcIndex;
				while (aCount > 0L) {
					// get source item
					long aSourceItemIndex = aIndex;
					object aItem = this [aSourceItemIndex];
					// insert it to dest index
					long aInsIndex = aDstIndex + aInsertedCount + 1L;
					this.InsertItemAtIndex (aInsIndex, aItem);
					// next
					++ aInsertedCount;
					++ aIndex;
					-- aCount;
				}
			}
			catch (Exception) {
				// rollback ...
				this.DeleteItemsAtIndex (aDstIndex + 1L, aInsertedCount);
				throw; // raise again
			}
			// ok!
			// delete source items
			long aDelIndex = aSrcIndex;
			this.DeleteItemsAtIndex (aDelIndex, aInsertedCount);
			// ok!
		}
		else
			// do nothing and just ...
			return;
		// end if
	}


#endregion

//=======================================================================================

#region to cycle a range of items up/down

	// to cycle a range of items up

	public bool CanCycleItemsUp (long aIndex, long aCount)
	{
		return this.CanRelocateItems (aIndex, aCount);
	}

	public long CycleItemsUp (long aIndex, long aCount)
	{
		this.CheckValidItemsRange (aIndex, aCount);
		// ok!
		long aRetVal;
		long aNewIndex = 0L;
		if (aIndex > 0L) {
			aNewIndex = aIndex - 1L;
			aRetVal = aIndex - 1L;
		} else {
			aNewIndex = this.ItemsCount - 1L;
			aRetVal = this.ItemsCount - aCount;
		}// end if
		// relocate!
		this.RelocateItems (aNewIndex, aIndex, aCount);
		// done!
		return aRetVal;
	}

	// to cycle a range of items down

	public bool CanCycleItemsDown (long aIndex, long aCount)
	{
		return this.CanRelocateItems (aIndex, aCount);
	}

	public long CycleItemsDown (long aIndex, long aCount)
	{
		this.CheckValidItemsRange (aIndex, aCount);
		// ok!
		long lastRngItemIndex = (aIndex + aCount - 1L);
		long lastItemIndex = (this.ItemsCount - 1L);
		//
		long aRetVal;
		long aNewIndex;
		if (lastRngItemIndex < lastItemIndex) {
			aNewIndex = aIndex + aCount;
			aRetVal = aIndex + 1L;
		} else {
			// assert: (lastRngItemIndex == lastItemIndex)
			aNewIndex = (0L);
			aRetVal = (0L);
		}//end if
		// relocate!
		this.RelocateItems (aNewIndex, aIndex, aCount);
		// done!
		return aRetVal;
	}



#endregion

//=======================================================================================

#region to move a range of items up/down

	// to move a range of items up

	public bool CanMoveItemsUp (long aIndex, long aCount)
	{
		return
			this.CanCycleItemsUp (aIndex, aCount) &&
			(aIndex > (0L))
		;
	}

	public long MoveItemsUp (long aIndex, long aCount)
	{
		this.CheckValidItemsRange (aIndex, aCount);
		// ok!
		// do NOT Cycle items
		if (aIndex <= (0L)) return aIndex;
		// move
		return this.CycleItemsUp (aIndex, aCount);
	}

	// to move a range of items down

	public bool CanMoveItemsDown (long aIndex, long aCount)
	{
		long lastItemIndex = (this.ItemsCount - 1L);
		long lastRngItemIndex = (aIndex + aCount - 1L);
		return
			this.CanCycleItemsDown (aIndex, aCount) &&
			(lastRngItemIndex < lastItemIndex)
		;
	}

	public long MoveItemsDown (long aIndex, long aCount)
	{
		this.CheckValidItemsRange (aIndex, aCount);
		// ok!
		long lastItemIndex = (this.ItemsCount - 1L);
		long lastRngItemIndex = (aIndex + aCount - 1L);
		//
		// ok!
		// do NOT Cycle items
		if (lastRngItemIndex >= lastItemIndex) return aIndex;
		// move
		return this.CycleItemsDown (aIndex, aCount);
	}

#endregion

//=======================================================================================

#region to bubble a range of items

	// to bubble cycle a range of items

	/*/ usage:

			if (aList.IsValidItemsRange (aSrcIndex, aSrcCount))

				aList.BubbleCycleItems (aOffset, aSrcIndex, aSrcCount)

			else
				<<invalid items range: do not perform relocation>>

	/*/

	public long BubbleCycleItems (long aSrcIndex, long aSrcCount, long aOffset)
	{
		// range check
		this.CheckValidItemsRange (aSrcIndex, aSrcCount);
		// ok!

		// get the list items count
		long aTotalItemsCount = this.ItemsCount;

		// avoid a div/0 exception
		//if (aTotalItemsCount <= 0L) return (aSrcIndex + aOffset);

		// compute the destination index
		long aDstIndex;
		if (aOffset > 0L)
			// relocate items down
			aDstIndex = aSrcIndex + aOffset + aSrcCount - 1L;
		else
			// relocate items up
			aDstIndex = aSrcIndex + aOffset;
		//end if
		// make it a valid index
		aDstIndex = aDstIndex % aTotalItemsCount;
		// make "aDstIndex" a valid item index
		if (aDstIndex < 0L)
			aDstIndex = aTotalItemsCount + aDstIndex;
		//end if

		// compute the returned index value
		long aRetValue = aDstIndex;
		if (aSrcIndex < aDstIndex)
			// range was moved down
			aRetValue = aDstIndex - (aSrcCount - 1L);
		//end if

		// relocate all items
		this.RelocateItems (aDstIndex, aSrcIndex, aSrcCount);
		// done!
		return aRetValue;
	}

	// to bubble move a range of items

	public long BubbleMoveItems (long aSrcIndex, long aSrcCount, long aOffset)
	{
		// range check
		//this.CheckValidItemsRange (aSrcIndex, aSrcCount);
		// ok!
		// clip offset
		long aClippedOffset = aOffset;
		if (aOffset < 0L) {
			// move up
			long aMinUpOffset = - aSrcIndex;
			if (aOffset < aMinUpOffset)
				aClippedOffset = aMinUpOffset;
			//end if
		}
		else
		if (aOffset > 0L) {
			// move down
			long aLastItemIndex = this.ItemsCount - 1L;
			long aLastSrcIndex = (aSrcIndex + aSrcCount - 1L);
			//
			long aMaxDownOffset = aLastItemIndex - aLastSrcIndex;
			if (aOffset > aMaxDownOffset)
				aClippedOffset = aMaxDownOffset;
			//end if
		}
		// bubble
		return this.BubbleCycleItems (aSrcIndex, aSrcCount, aClippedOffset);
	}

#endregion

//=======================================================================================

#region to bubble a range of items in a range

	// to bubble cycle a range of items in a range

	public long BubbleCycleItems (
		long aRangeIndex, long aRangeCount,
		long aSrcIndex, long aSrcCount,
		long aOffset
	) {
		// items range check
		this.CheckValidItemsRange (aRangeIndex, aRangeCount);
		// ok!

		// source items range check
		VRLongRangeCheck.CheckValidItemsRange (aSrcIndex, aSrcCount, aRangeIndex, aRangeCount);
		// ok!

		// compute the destination index
		long aDstIndex;
		if (aOffset > 0L)
			// (+) relocate items down
			aDstIndex = aSrcIndex + aOffset + aSrcCount - 1L;
		else
			// (-) relocate items up
			aDstIndex = aSrcIndex + aOffset;
		//end if

		// make it a valid items range index ...
		// make aDstIndex relative to the items range
		long aRelDstIndex = aDstIndex - aRangeIndex;
		// make the relative index a valid items range index ...
		aRelDstIndex = aRelDstIndex % aRangeCount;
		if (aRelDstIndex < 0L)
			aRelDstIndex = aRangeCount + aRelDstIndex;
		// make aRelDstIndex an absolute item index
		aDstIndex = aRelDstIndex + aRangeIndex;

		// compute the returned index value
		long aRetValue = aDstIndex;
		if (aSrcIndex < aDstIndex)
			// range was moved down
			aRetValue = aDstIndex - (aSrcCount - 1L);
		//end if

		// relocate all items
		this.RelocateItems (aDstIndex, aSrcIndex, aSrcCount);

		// done!
		return aRetValue;
	}

	// to bubble move a range of items in a range

	public long BubbleMoveItems (
		long aRangeIndex, long aRangeCount,
		long aSrcIndex, long aSrcCount,
		long aOffset
	) {
		// clip offset
		long aClippedOffset = aOffset;
		if (aOffset < 0L)
		{
			// move up
			long aMinUpOffset = - (aSrcIndex - aRangeIndex);
			if (aOffset < aMinUpOffset)
				aClippedOffset = aMinUpOffset;
			//end if
		}
		else
		if (aOffset > 0L)
		{
			// move down
			long aLastItemIndex = (aRangeIndex + aRangeCount - 1L);
			long aLastSrcIndex = (aSrcIndex + aSrcCount - 1L);
			long aMaxDownOffset = aLastItemIndex - aLastSrcIndex;
			if (aOffset > aMaxDownOffset)
				aClippedOffset = aMaxDownOffset;
			//end if
		}
		// bubble
		return this.BubbleCycleItems (
			aRangeIndex, aRangeCount,
			aSrcIndex, aSrcCount,
			aClippedOffset
		);
	}

#region to bubble a relative range of items in a range

	/*/
		here the source index is relative to the given items range
		the returned destination index is also relative
	/*/

	// to bubble cycle a relative range of items in a range

	public long BubbleCycleItemsRel (
		long aRangeIndex, long aRangeCount,
		long aRelSrcIndex, long aSrcCount,
		long aOffset
	) {
		long aAbsSrcIndex = aRelSrcIndex + aRangeIndex;
		// bubble cycle!
		long aAbsDstIndex = this.BubbleCycleItems (
			aRangeIndex, aRangeCount,
			aAbsSrcIndex, aSrcCount,
			aOffset
		);
		long aRelDstIndex = aAbsDstIndex - aRangeIndex;
		return aRelDstIndex;
	}

	// to bubble move a relative range of items in a range

	public long BubbleMoveItemsRel (
		long aRangeIndex, long aRangeCount,
		long aRelSrcIndex, long aSrcCount,
		long aOffset
	) {
		long aAbsSrcIndex = aRelSrcIndex + aRangeIndex;
		// bubble move!
		long aAbsDstIndex = this.BubbleMoveItems (
			aRangeIndex, aRangeCount,
			aAbsSrcIndex, aSrcCount,
			aOffset
		);
		long aRelDstIndex = aAbsDstIndex - aRangeIndex;
		return aRelDstIndex;
	}

#endregion


#endregion

//=======================================================================================

#region to rotate items

	// to rotate items in range

	public void RotateItemsInRange (
		long aRangeIndex,
		long aRangeCount,
		long aDistance
	) {
		// insert range check
		this.CheckValidInsertRange (aRangeIndex, aRangeCount);

		// do nothing if there are no items to rotate
		if (aRangeCount <= 1L) return;

		// norm dist
		long aXDistance = aDistance % aRangeCount;

		long aBubbleIndex;
		long aBubbleCount;
		long aBubbleOffset;

		if (aXDistance > 0L)
		{
			aBubbleIndex = aRangeCount - aXDistance;
			aBubbleCount = aXDistance;
			aBubbleOffset = (+1L);
		}
		else
		if (aXDistance < 0L)
		{
			aBubbleIndex = (0L);
			aBubbleCount = - aXDistance;
			aBubbleOffset = (-1L);
		}
		else
			// (aXDistance == 0L) !!
			// do nothing and ...
			return;
		//end if

		// bubble cycle items
		this.BubbleCycleItemsRel (
			aRangeIndex, aRangeCount,
			aBubbleIndex, aBubbleCount,
			aBubbleOffset //aXDistance
		);
		// done!
	}

	// to rotate all list items

	public void RotateItems (long aDistance)
	{
		// do nothing for an empty list
		//if (this.IsEmpty()) return;
		// rotate all!
		this.RotateItemsInRange ((0L), this.Size, aDistance);
		// done!
	}

#endregion

//=======================================================================================

#endregion

//=======================================================================================

#endregion

//=======================================================================================
// Finding Items in an auto ordered list
//=======================================================================================

//=======================================================================================

#region Finding Items Indexes in an auto ordered list

	// find nearest item index by (value|key)

	/*/
		locating a nearest item by value/key

		direct search	: start searching from the first item - index(0)
		reverse search : start searching from the last item - index(Count - 1)
	/*/

	// direct search

	// value

	public long FindFirstNearestOrderedItemIndexValue (object aItemData)
	{
		return this.FindFirstNearestOrderedItemIndex (aItemData, this.ItemToItemComparator);
	}

	// key

	public long FindFirstNearestOrderedItemIndexKey (object aItemKey)
	{
		return this.FindFirstNearestOrderedItemIndex (aItemKey, this.KeyToItemComparator);
	}

	// reverse search

	// value

	public long FindLastNearestOrderedItemIndexValue (object aItemData)
	{
		return this.FindLastNearestOrderedItemIndex (aItemData, this.ItemToItemComparator);
	}

	// key

	public long FindLastNearestOrderedItemIndexKey (object aItemKey)
	{
		return this.FindLastNearestOrderedItemIndex (aItemKey, this.KeyToItemComparator);
	}

//=======================================================================================

	// find the (actual) item index by (value|key)

	/*/
		locating an exact item by value/key

		if you do Not have duplicate items
			then you can indifferently use direct/reverse searches
			because in this case they yeld the same results
	/*/

	// direct search

	// value

	public long FindFirstOrderedItemIndexValue (object aItemData)
	{
		return this.FindFirstOrderedItemIndex (aItemData, this.ItemToItemComparator);
	}

	// key

	public long FindFirstOrderedItemIndexKey (object aItemKey)
	{
		return this.FindFirstOrderedItemIndex (aItemKey, this.KeyToItemComparator);
	}


	// reverse search

	// value

	public long FindLastOrderedItemIndexValue (object aItemData)
	{
		return this.FindLastOrderedItemIndex (aItemData, this.ItemToItemComparator);
	}

	// key

	public long FindLastOrderedItemIndexKey (object aItemKey)
	{
		return this.FindLastOrderedItemIndex (aItemKey, this.KeyToItemComparator);
	}

#endregion

//=======================================================================================

#region Finding Items Iterators on an auto ordered list

//=======================================================================================
// the following "Find[Nearest]Item[Dir,Rev]" procs will return an item's iterator
//=======================================================================================

	private static VRPagedListIterator CreateNewIterator (VRPagedListIterator aIterator)
	{
		if (aIterator == null)
			return new VRPagedListIterator();
		else
			return aIterator;
		//end if
	}

//=======================================================================================

	// the following will return an item's iterator

	// find item iterator

	// direct

	public VRPagedListIterator FindFirstOrderedItemIterator (
		VRPagedListIterator aIterator,
		object aKeyValue,
		IVRPLItemComparator aComparator
	) {
		aIterator = CreateNewIterator (aIterator);
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = this.FindFirstOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		aIterator.InternalList = this;
		aIterator.InternalIndex = aIndex;
		aIterator.Page = aDataPage;
		aIterator.LocalIndex = aLocalIndex;
		aIterator.SyncWithListStructState();
		return aIterator;
	}

	// reverse

	public VRPagedListIterator FindLastOrderedItemIterator (
		VRPagedListIterator aIterator,
		object aKeyValue,
		IVRPLItemComparator aComparator
	) {
		aIterator = CreateNewIterator (aIterator);
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = this.FindLastOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		aIterator.InternalList = this;
		aIterator.InternalIndex = aIndex;
		aIterator.Page = aDataPage;
		aIterator.LocalIndex = aLocalIndex;
		aIterator.SyncWithListStructState();
		return aIterator;
	}

	// find nearest item iterator

	// direct

	public VRPagedListIterator FindFirstNearestOrderedItemIterator (
		VRPagedListIterator aIterator,
		object aKeyValue,
		IVRPLItemComparator aComparator
	) {
		aIterator = CreateNewIterator (aIterator);
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = this.FindFirstNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		aIterator.InternalList = this;
		aIterator.InternalIndex = aIndex;
		aIterator.Page = aDataPage;
		aIterator.LocalIndex = aLocalIndex;
		aIterator.SyncWithListStructState();
		return aIterator;
	}

	// reverse

	public VRPagedListIterator FindLastNearestOrderedItemIterator (
		VRPagedListIterator aIterator,
		object aKeyValue,
		IVRPLItemComparator aComparator
	) {
		aIterator = CreateNewIterator (aIterator);
		VRPLAbstPage aDataPage = null; long aLocalIndex = (-1L);
		long aIndex = this.FindLastNearestOrderedItemIndex (
			ref aDataPage, ref aLocalIndex,
			aKeyValue,
			aComparator
		);
		aIterator.InternalList = this;
		aIterator.InternalIndex = aIndex;
		aIterator.Page = aDataPage;
		aIterator.LocalIndex = aLocalIndex;
		aIterator.SyncWithListStructState();
		return aIterator;
	}


//=======================================================================================

#endregion

//=======================================================================================

#endregion


//=======================================================================================

//=======================================================================================

		// ... ... ...
		// ... ... ...
		// ... ... ...

		// more ?

//=======================================================================================

} // end of VRPagedList class

//=======================================================================================


}//namespace

// that's all folks ...
